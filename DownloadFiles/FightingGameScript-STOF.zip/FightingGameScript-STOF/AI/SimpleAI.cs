﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine.AI;
using UnityEngine;

public class SimpleAI : MonoBehaviour
{
    Transform FightBox;
    Vector3 RandomPos;
    SimpleAI ClosestTarget;
    bool InFightBox;

    NavMeshAgent Agent;
    Animator Anim;

    public int MyTeam;
    public int LastHit;
    public bool Dead;

    public int Health;

    public GameObject DeathEffect;

    float AttackTimer, DeathTimer;

    private void Start()
    {
        FightBox = GameObject.FindGameObjectWithTag("AIFightBox").transform;
        ClosestTarget = null;

        ChangeRandomPos();

        Agent = GetComponent<NavMeshAgent>();
        Anim = GetComponent<Animator>();
        Health = 3;

        DeathTimer = 6;
        Dead = false;
    }

    private void FixedUpdate()
    {
        if(!Dead)
        {
            if (Health <= 0)
            {
                Die();
            }
            else
            {
                Anim.SetBool("Dead", false);
            }

            if (FightBox != null)
            {
                if (!InFightBox)
                {
                    ClosestTarget = null;

                    Agent.SetDestination(RandomPos);

                    if(Agent.velocity == Vector3.zero)
                    {
                        ChangeRandomPos();
                    }
                }
                else
                {
                    AttackTimer -= Time.deltaTime;

                    if (ClosestTarget == null)
                    {
                        ClosestTarget = FindClosestTarget();
                        Agent.SetDestination(FightBox.position);
                    }
                    else
                    {
                        Agent.SetDestination(ClosestTarget.transform.position);

                        if (Agent.velocity == Vector3.zero)
                        {
                            Vector3 LookDir = new Vector3(ClosestTarget.transform.position.x, transform.position.y, ClosestTarget.transform.position.z);
                            transform.LookAt(LookDir);

                            if (AttackTimer <= 0)
                            {
                                ChangeRandomPos();

                                Attack();
                                Anim.SetBool("InAttack", true);
                                AttackTimer = 4;
                            }
                            else
                            {
                                Anim.SetBool("InAttack", false);
                            }
                        }
                    }
                }
            }
            else
            {
                FightBox = GameObject.FindGameObjectWithTag("AIFightBox").transform;
            }
        }
        else
        {
            DeathTimer -= Time.deltaTime;

            if(DeathTimer <= 0)
            {
                Destroy(gameObject);
            }
        }
        if(ClosestTarget != null && ClosestTarget.Dead)
        {
            ClosestTarget = null;
        }

        CharacterAnim();
    }

    void Attack()
    {
        Debug.DrawRay(transform.position, transform.forward * 2, Color.red);

        if(Physics.Raycast(transform.position, transform.forward, out RaycastHit HitInfo, 2f))
        {
            SimpleAI HitAI = HitInfo.transform.GetComponent<SimpleAI>();
            CharacterCombatControl HitCC = HitInfo.transform.GetComponent<CharacterCombatControl>();

            if(HitAI != null)
            {
                HitAI.Health -= 1;
                HitAI.LastHit = MyTeam;
            }
            if(HitCC != null)
            {
                HitCC.TakeDamage(1);
            }
        }
    }

    public void Die()
    {
        Dead = true;
        FindObjectOfType<GameController>().AddScore(1, LastHit);
        FindObjectOfType<GameController>().RemoveActiveAI(MyTeam);

        GetComponent<Collider>().enabled = false;

        Quaternion Rot = Quaternion.Euler(-90, 0, 0);
        Instantiate(DeathEffect, transform.position - new Vector3(0, 0.5f, 0), Rot);

        Agent.SetDestination(transform.position);

        Anim.SetBool("Dead", true);
    }

    void CharacterAnim()
    {
        if(Agent.velocity != Vector3.zero)
        {
            Anim.SetBool("Walking", true);
        }
        else
        {
            Anim.SetBool("Walking", false);

        }
    }

    SimpleAI FindClosestTarget()
    {
        SimpleAI[] AllAIs = FindObjectsOfType<SimpleAI>();
        SimpleAI ReturnValue = null;
        float LastBest = Mathf.Infinity;

        foreach(SimpleAI AI in AllAIs)
        {
            float Dis = Vector3.Distance(transform.position, AI.transform.position);

            if(Dis < LastBest && AI != gameObject && AI.MyTeam != MyTeam && !AI.Dead && AI.InFightBox)
            {
                LastBest = Dis;
                ReturnValue = AI;
            }
        }

        return ReturnValue;
    }

    void ChangeRandomPos()
    {
        float BoxScale = FightBox.GetComponent<BoxCollider>().size.x / 2;
        RandomPos = FightBox.transform.position + new Vector3(Random.Range(-BoxScale, BoxScale), 0, 0);
    }

    private void OnTriggerEnter(Collider other)
    {
        if(other.CompareTag("AIFightBox"))
        {
            InFightBox = true;
        }
    }

    private void OnTriggerExit(Collider other)
    {
        if (other.CompareTag("AIFightBox"))
        {
            ChangeRandomPos();
            InFightBox = false;
        }
    }
}
