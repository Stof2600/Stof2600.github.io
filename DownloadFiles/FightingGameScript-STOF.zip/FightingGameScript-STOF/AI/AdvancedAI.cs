﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine.AI;
using UnityEngine;

public class AdvancedAI : MonoBehaviour
{
    public bool ActAsDummy;
    public int MaxAILevel = 2;
    public int AILevel, AICounterLevel = 1;
    /*
     * AI LVL 0
     * random block direction
     * random attack selection & direction
     * no combos
     * no special moves
     * 
     * AI LVL 1
     * smart block direction
     * random attack selection
     * smart attack direction
     * no combos
     * bash
     * 
     * AI LVL 2
     * smart block dir
     * smart attack dir
     * smart attack selection
     * no combos
     * bash, random parry chance, dodge
     */

    PlayerController PC;
    CharacterCombatControl CCC;

    public float StopDistance = 1.5f;
    public float MaxDistance = 5;
    float DisToTarget;

    public CharacterCombatControl ClosestTarget;

    public int ActiveBlockDir, WantedBlockDir;

    bool DidLevelUpdate;
    bool DidCounter, WaitForBash;
    int DodgeDir;

    float AttackTimer, SwapBlockTimer, LastBashTime;
    float ReactionTime = 0.7f;

    #region NavMeshStuff
    NavMeshPath Path;
    float PathTimer;
    #endregion

    void Start()
    {
        PC = GetComponent<PlayerController>();
        CCC = GetComponent<CharacterCombatControl>();
        Path = new NavMeshPath();

        AttackTimer = 5;
        SwapBlockTimer = 0;
    }

    void Update()
    {

        if(CCC.Target != null)
        {
            CheckEnemyLevel();
        }
        else
        {
            DidLevelUpdate = false;
        }

        if (!PC.IsAI)
        {
            return;
        }

        if (!ActAsDummy)
        {
            PCConnector();

            if (PC.LockonTarget != null)
            {
                if (DisToTarget <= StopDistance)
                {
                    AIControl();
                }
            }
        }
    }

    void PCConnector()
    {
        if(CCC.Dead)
        {
            ClosestTarget = null;
            PC.MoveInput = Vector2.zero;
            PC.LockonButton = false;
            PC.LightButton = false;
            PC.HeavyButton = false;
            PC.SpecialButton = false;
            return;
        }

        if (ClosestTarget == null || ClosestTarget.Dead)
        {
            ClosestTarget = PullTargets();
        }
        else
        {
            DisToTarget = Vector3.Distance(transform.position, ClosestTarget.transform.position);

            if(transform.position.y > ClosestTarget.transform.position.y + 0.5 && DisToTarget < MaxDistance)
            {
                transform.LookAt(new Vector3(0, transform.position.y, 0));
                PC.MoveInput = new Vector2(0, 1);
                return;
            }

            PathTimer += Time.deltaTime;

            if (Path.corners.Length > 0)
            {
                float DisToPoint = Vector3.Distance(transform.position, Path.corners[1]);
                if(DisToPoint < 1.5f)
                {
                    PathTimer = 0.5f;
                }
            }
            else if(Physics.Linecast(transform.position, ClosestTarget.transform.position, out RaycastHit hitInfo))
            {
                if(hitInfo.transform == ClosestTarget.transform)
                {
                    transform.LookAt(new Vector3(hitInfo.transform.position.x, transform.position.y, hitInfo.transform.position.z));
                    ToTargetMove(hitInfo.transform.position);
                }
                else
                {
                    ToTargetMove(transform.position - transform.forward);
                }
            }

            if (PathTimer >= 0.5f)
            {
                NavMesh.CalculatePath(transform.position, ClosestTarget.transform.position, NavMesh.AllAreas, Path);
                ClosestTarget = PullTargets();
                PathTimer = 0;
            }


            if(PC.OnGround && PC.SpecialButton)
            {
                PC.SpecialButton = false;
            }

            if (DisToTarget > MaxDistance && Path.corners.Length > 0)
            {
                transform.LookAt(new Vector3(Path.corners[1].x, transform.position.y, Path.corners[1].z));
                ToTargetMove(Path.corners[1]);

                if (PC.LockonTarget == null)
                {
                    PC.LockonButton = false;
                }
                else
                {
                    PC.LockonButton = true;
                }
            }
            else
            {
                CombatMovement();
            }
        }
    }

    void ToTargetMove(Vector3 Target)
    {
        Debug.DrawLine(transform.position, Target, Color.green);

        if(!PC.OnGround && WaitForBash)
        {
            PC.SpecialButton = true;
            PC.MoveInput = new Vector2(0, 1);
            WaitForBash = false;
            LastBashTime = 7;
            return;
        }

        if(!DidCounter && PC.OnGround)
        {
            PC.MoveInput = new Vector2(0, 1);
        }
        else if(DidCounter && !PC.JumpButton && !PC.Jump && PC.OnGround && DisToTarget > StopDistance)
        {
            PC.MoveInput = new Vector2(0, 1);
        }

        if(DidCounter && !PC.OnGround && PC.MoveInput == Vector2.zero)
        {
            switch (DodgeDir)
            {
                case 0:
                    PC.MoveInput = new Vector2(0, -1);
                    break;
                case 1:
                    PC.MoveInput = new Vector2(1, 0);
                    break;
                case 2:
                    PC.MoveInput = new Vector2(-1, 0);
                    break;
            }
        }

        if(PC.JumpButton)
        {
            PC.JumpButton = false;
        }
    }
    void CombatMovement()
    {
        if (PC.LockonTarget == null || CCC.Target == null)
        {
            PC.LockonButton = true;
        }
        else
        {
            PC.LockonButton = false;

            PC.ActiveBlockDir = ActiveBlockDir;

            if(CCC.InAttack || CCC.DidBash || CCC.Stunned)
            {
                PC.LightButton = false;
                PC.HeavyButton = false;
                PC.SpecialButton = false;
            }

            if (DisToTarget > StopDistance || !PC.OnGround)
            {
                ToTargetMove(PC.LockonTarget.position);
                PC.JumpButton = false;

                if(!PC.OnGround && !DidCounter)
                {
                    PC.SpecialButton = true;
                }
            }
            else
            {
                PC.MoveInput = Vector2.zero;
            }
        }
    }

    void AIControl()
    {
        if(AILevel > 0)
        {
            SmartBlock();
        }
        else
        {
            SwapBlockTimer -= Time.deltaTime;

            if (SwapBlockTimer <= 0)
            {
                ActiveBlockDir = Random.Range(0, 3);
                CCC.InputDir(ActiveBlockDir);

                SwapBlockTimer = Random.Range(0.5f, 2f);
            }
        }

        if(AILevel > 0)
        {
            if(AILevel > 1)
            {
                Counter();
            }

            Attack(3);
        }
        else
        {
            Attack(2);
        }

    }

    void SmartBlock()
    {

        if (CCC.Target.MyAttackDir == AttackDir.Right)
        {
            WantedBlockDir = 2;
        }
        else if (CCC.Target.MyAttackDir == AttackDir.Left)
        {
            WantedBlockDir = 1;
        }
        else
        {
            WantedBlockDir = 0;
        }

        if (ActiveBlockDir != WantedBlockDir && SwapBlockTimer < ReactionTime)
        {
            SwapBlockTimer += Time.deltaTime;
        }
        else if (ActiveBlockDir != WantedBlockDir && SwapBlockTimer >= ReactionTime)
        {
            ActiveBlockDir = WantedBlockDir;
            CCC.InputDir(ActiveBlockDir);

            SwapBlockTimer = 0;
        }
        else
        {
            SwapBlockTimer = 0;
        }
    }
    void Counter()
    {
        for (int i = 0; i < CCC.IncomingAttacks.Length; i++)
        {
            if (CCC.IncomingAttacks[i].Timer > 0 && CCC.IncomingAttacks[i].Timer >= CCC.IncomingAttacks[i].StartupTime && !DidCounter)
            {
                // AI has 1 in 4 chance to od nothing
                int DefenceChoice = Random.Range(0, 4);

                if (DefenceChoice == 0) //AI parry
                {
                    ActiveBlockDir = WantedBlockDir;
                    CCC.InputDir(ActiveBlockDir);
                    PC.HeavyButton = true;
                }
                else if (DefenceChoice == 1 && CCC.CurrentStamina >= PC.jumpStaminaCost) //AI Dodge
                {
                    DodgeDir = (int)CCC.IncomingAttacks[i].Dir;

                    PC.JumpButton = true;
                    print(PC.MoveInput + ":DIR:" + DodgeDir);
                }
                else if (DefenceChoice == 2) //AI Punish
                {
                    PC.LightButton = true;
                }

                DidCounter = true;
            }
        }

    }
    void Attack(int AttackCount)
    {
        AttackTimer -= Time.deltaTime;

        if(LastBashTime >= 0)
        {
            LastBashTime -= Time.deltaTime;
        }

        if (AttackTimer <= 0)
        {
            if (ActiveBlockDir == WantedBlockDir && AILevel >= 1)
            {
                int D = Random.Range(0, 3);
                ActiveBlockDir = D;
                CCC.InputDir(ActiveBlockDir);
            }
            else if((AILevel >= 1 && ActiveBlockDir != WantedBlockDir) || AILevel < 1)
            {
                int R = Random.Range(0, AttackCount);

                if (R == 2 && CCC.CurrentStamina >= PC.jumpStaminaCost + CCC.BashCost && LastBashTime <= 0)
                {
                    PC.JumpButton = true;
                    WaitForBash = true;
                }
                else if (R == 1 && CCC.CurrentStamina >= 15)
                {
                    PC.HeavyButton = true;
                }
                else if (R == 0 && CCC.CurrentStamina >= 1)
                {
                    PC.LightButton = true;
                }

                AttackTimer = Random.Range(1f, 2.5f);
                DidCounter = false;
            }
        }
    }

    void CheckEnemyLevel()
    {
        if(CCC.Target.Dead && AICounterLevel < MaxAILevel && !DidLevelUpdate)
        {
            AICounterLevel += 1;
            print(transform.name + " LEVELUP:" + AICounterLevel + "[TARGET]:" + CCC.Target.name);
            DidLevelUpdate = true;
        }
        else if(CCC.Dead && AICounterLevel > 0 && !DidLevelUpdate)
        {
            AICounterLevel -= 1;
            print(transform.name + " LEVELDOWN:" + AICounterLevel);
            DidLevelUpdate = true;
        }

        if(CCC.Target.GetComponent<AdvancedAI>())
        {
            AdvancedAI EnemyAI = CCC.Target.GetComponent<AdvancedAI>();

            AILevel = EnemyAI.AICounterLevel;
        }
    }

    CharacterCombatControl PullTargets()
    {
        CharacterCombatControl ReturnValue = null;
        CharacterCombatControl[] PosibleTargets = FindObjectsOfType<CharacterCombatControl>();

        float LastDis = Mathf.Infinity;

        foreach(CharacterCombatControl c in PosibleTargets)
        {
            float TargetDis = Vector3.Distance(transform.position, c.transform.position);

            if(TargetDis < LastDis && c.transform != transform && c.Team != CCC.Team && !c.Dead)
            {
                LastDis = TargetDis;
                ReturnValue = c;
            }
        }

        NavMesh.CalculatePath(transform.position, ReturnValue.transform.position, NavMesh.AllAreas, Path);
        return ReturnValue;
    }
}
