﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BreakableWall : MonoBehaviour
{
    [Header("REQUIREMENTS")]
    public float ForceBreak, DamageBreak;
    public bool WallDestroyed;
    public int EntityDamage = 3;
    [Header("OPTIONAL")]
    public GameObject BreakEffect;
    public Material BrokenMat;
    Collider MyCol;
    MeshRenderer MR;

    private void Start()
    {
        MyCol = GetComponent<Collider>();
        MR = GetComponent<MeshRenderer>();
    }

    public void CompareDamage(int Amount)
    {
        if(Amount >= DamageBreak)
        {
            BreakWall();
        }
    }

    private void OnTriggerEnter(Collider other)
    {
        print("HitWall " + other.GetComponent<Rigidbody>().velocity.magnitude);

        if (other.GetComponent<Rigidbody>() && other.GetComponent<Rigidbody>().velocity.magnitude > ForceBreak)
        {
            BreakWall();

            CharacterCombatControl CCC = other.GetComponent<CharacterCombatControl>();

            if(CCC != null && CCC.Stunned)
            {
                CCC.TakeDamage(EntityDamage);
            }
        }
        else
        {
            MyCol.isTrigger = false;
        }
    }

    private void OnCollisionExit(Collision collision)
    {
        MyCol.isTrigger = true;
    }

    void BreakWall()
    {
        WallDestroyed = true;
        MyCol.enabled = false;

        if (BreakEffect != null)
        {
            GameObject NewEffect = Instantiate(BreakEffect, transform.position, transform.rotation);
            NewEffect.GetComponentInChildren<ParticleSystemRenderer>().material = MR.material;
        }
        if (BrokenMat != null)
        {
            MR.material = BrokenMat;
        }
    }
}
