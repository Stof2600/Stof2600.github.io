﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Projectile : MonoBehaviour
{
    public AttackDir AttachedAttackDir;
    public int Damage;
    public float Speed;
    public float Gravity;
    public float DespawnTime = 5;
    public bool DoMove;

    Vector3 OldPos;

    // Update is called once per frame
    void Update()
    {
        if(DoMove)
        {
            OldPos = transform.position;
            transform.position += transform.forward * Speed * Time.deltaTime + transform.up * -Gravity * Time.deltaTime;

            if (Physics.Linecast(OldPos, transform.position, out RaycastHit HitInfo))
            {
                CharacterCombatControl CCC = HitInfo.transform.GetComponent<CharacterCombatControl>();
                BreakableWall BW = HitInfo.transform.GetComponent<BreakableWall>();

                if (BW != null)
                {
                    BW.CompareDamage(Damage);
                }

                if (CCC != null)
                {
                    if (CCC.MyAttackDir != AttachedAttackDir)
                    {
                        CCC.TakeDamage(Damage);
                    }
                }

                DoMove = false;
                transform.rotation = Quaternion.LookRotation(-HitInfo.normal);

                transform.position = HitInfo.point;
                transform.SetParent(HitInfo.transform);
                StartCoroutine(ProjectileDespawn());
            }
        }
    }

    IEnumerator ProjectileDespawn()
    {
        yield return new WaitForSeconds(DespawnTime);

        Destroy(gameObject);
    }
}
