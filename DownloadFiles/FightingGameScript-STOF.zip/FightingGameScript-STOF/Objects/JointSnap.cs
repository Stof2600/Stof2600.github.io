﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class JointSnap : MonoBehaviour
{
    public Joint MyJoint;
    public float BreakForce;

    private void OnTriggerEnter(Collider other)
    {
        if(other.GetComponent<Rigidbody>() && other.GetComponent<Rigidbody>().velocity.magnitude >= BreakForce)
        {
            Destroy(MyJoint);
            Destroy(GetComponent<JointSnap>());
        }

        print(other.GetComponent<Rigidbody>().velocity.magnitude);
    }
}
