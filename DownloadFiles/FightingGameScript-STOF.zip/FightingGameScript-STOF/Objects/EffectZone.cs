﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EffectZone : MonoBehaviour
{
    public enum EffectType
    { 
        Healing,
        StaminaRegain,
        SpeedIncrease,
        AttackIncrease
    }

    public List<CharacterCombatControl> EffectedPlayers = new List<CharacterCombatControl>();
    public EffectType Type;
    public Transform ZoneSprite;

    public Sprite[] ZoneSprites;
    public int ZoneTakenSlot;

    float Timer, StartTime = 5;
    bool Contested;


    private void Start()
    {
        Timer = StartTime;

        int R = Random.Range(0, 4);
        switch (R)
        {
            case 0:
                Type = EffectType.Healing;
                break;
            case 1:
                Type = EffectType.StaminaRegain;
                break;
            case 2:
                Type = EffectType.SpeedIncrease;
                break;
            case 3:
                Type = EffectType.AttackIncrease;
                break;
        }

        ZoneSprite.GetComponent<SpriteRenderer>().sprite = ZoneSprites[(int)Type];
    }

    private void FixedUpdate()
    {
        if(EffectedPlayers.Count > 0)
        {
            if(EffectedPlayers.Count > 1)
            {
                int TeamCheck = EffectedPlayers[0].Team;
                int TeamCount = 0;

                foreach(CharacterCombatControl CCC in EffectedPlayers)
                {
                    if(CCC.Team == TeamCheck)
                    {
                        TeamCount += 1;
                    }
                }

                if(TeamCount == EffectedPlayers.Count)
                {
                    Contested = false;
                }
                else
                {
                    Contested = true;
                }
            }

            if(!Contested)
            {
                Timer -= Time.deltaTime;
            }

            if(Timer <= 0)
            {
                foreach(CharacterCombatControl CCC in EffectedPlayers)
                {
                    switch (Type)
                    {
                        case EffectType.Healing:
                            CCC.CurrentHealth += CCC.MaxHealth / 2;
                            break;
                        case EffectType.StaminaRegain:
                            CCC.CurrentStamina = CCC.MaxStamina;
                            break;
                        case EffectType.SpeedIncrease:
                            if(CCC.SpeedMulti + 0.25f <= 2)
                            {
                                CCC.SpeedMulti += 0.25f;
                            }
                            else if (CCC.SpeedMulti + 0.25f > 2)
                            {
                                CCC.SpeedMulti = 2;
                            }
                            break;
                        case EffectType.AttackIncrease:
                            if (CCC.DefaultDmgMulti + 0.25f <= 2)
                            {
                                CCC.DefaultDmgMulti += 0.25f;
                            }
                            else if(CCC.DefaultDmgMulti + 0.25f > 2)
                            {
                                CCC.DefaultDmgMulti = 2;
                            }
                            break;
                    }
                }

                FindObjectOfType<GameController>().ZoneTaken[ZoneTakenSlot] = false;
                Destroy(gameObject);
            }
        }
        else
        {
            if(Timer < StartTime)
            {
                Timer += Time.deltaTime;
            }
        }

        float SpriteSize = (Timer * -1);
        ZoneSprite.localScale = new Vector3(SpriteSize, SpriteSize, SpriteSize);
    }
}
