﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CharacterAttackList : MonoBehaviour
{
    public int CharacterID;
    public CharacterMoveset[] MoveSets;

    Attack FindAttack(AttackDir Direction, int Type, float LAFT, string LAN, bool Grounded)
    {
        Attack ReturnValue = null;

        for (int i = 0; i < MoveSets[CharacterID].CharacterAttacks.Count; i++)
        {
            if((MoveSets[CharacterID].CharacterAttacks[i].Dir == Direction || MoveSets[CharacterID].CharacterAttacks[i].Dir == AttackDir.Mixed 
                || (MoveSets[CharacterID].CharacterAttacks[i].Dir == AttackDir.LeftRightSplit && (Direction == AttackDir.Right || Direction == AttackDir.Left)))
                && MoveSets[CharacterID].CharacterAttacks[i].AttackType == Type && !MoveSets[CharacterID].CharacterAttacks[i].FollowUpAttack 
                && MoveSets[CharacterID].CharacterAttacks[i].RequiresGround == Grounded)
            {
                ReturnValue = MoveSets[CharacterID].CharacterAttacks[i];
            }
        }

        if(LAFT >= 0)
        {
            for (int i = 0; i < MoveSets[CharacterID].CharacterAttacks.Count; i++)
            {
                if ((MoveSets[CharacterID].CharacterAttacks[i].Dir == Direction || MoveSets[CharacterID].CharacterAttacks[i].Dir == AttackDir.Mixed  //extra long if statement
                    || (MoveSets[CharacterID].CharacterAttacks[i].Dir == AttackDir.LeftRightSplit && (Direction == AttackDir.Right || Direction == AttackDir.Left))) 
                    && MoveSets[CharacterID].CharacterAttacks[i].AttackType == Type && MoveSets[CharacterID].CharacterAttacks[i].FollowUpAttack && LAN == MoveSets[CharacterID].CharacterAttacks[i].OriginAttackName
                    && MoveSets[CharacterID].CharacterAttacks[i].RequiresGround == Grounded)
                {
                    ReturnValue = MoveSets[CharacterID].CharacterAttacks[i];
                }
            }
        }


        return ReturnValue;
    }

    public void RewriteAttack(AttackDir Dir, int Type, Attack Output, float LAFT, string LAN, bool Grounded)
    {
        Attack Read = FindAttack(Dir, Type, LAFT, LAN, Grounded);

        if(Read != null)
        {
            Output.AttackName = Read.AttackName;
            Output.AttackType = Read.AttackType;
            Output.Dir = Read.Dir;
            Output.Dmg = Read.Dmg;
            Output.Range = Read.Range;
            Output.TargetPoint = Read.TargetPoint;
            Output.StaminaCost = Read.StaminaCost;

            Output.Unblockable = Read.Unblockable;
            Output.DoStun = Read.DoStun;
            Output.UseTracking = Read.UseTracking;
            Output.RequiresGround = Read.RequiresGround;
            Output.AllowFeint = Read.AllowFeint;
            Output.FollowUpAttack = Read.FollowUpAttack;
            Output.OriginAttackName = Read.OriginAttackName;
            Output.UseDmgMulti = Read.UseDmgMulti;
            Output.UseAmmo = Read.UseAmmo;
            Output.UseProjectile = Read.UseProjectile;
            Output.Projectile = Read.Projectile;

            Output.StartupTime = Read.StartupTime;
            Output.ActiveTime = Read.ActiveTime + Read.StartupTime;
            Output.ExitTime = Read.ExitTime + Read.ActiveTime + Read.StartupTime;
            Output.FollowUpTime = Read.FollowUpTime;
            Output.ProjectileTime = Read.ProjectileTime;

            Output.Timer = Read.Timer;

            Output.Blocked = Read.Blocked;
            Output.Paried = Read.Paried;
            Output.DidFeint = Read.DidFeint;
            Output.HitTarget = Read.HitTarget;
            Output.DidCollisionCheck = Read.DidCollisionCheck;
        }
    }

    public void GetMaxAmmoValue(CharacterCombatControl Self)
    {
        Self.MaxAmmo = MoveSets[CharacterID].CharacterMaxAmmo;
        Self.AutoReload = MoveSets[CharacterID].AutoReload;
        Self.ReloadAll = MoveSets[CharacterID].ReloadAll;
        Self.ReloadTime = MoveSets[CharacterID].ReloadTime;
        Self.AmmoObjects = MoveSets[CharacterID].AmmoObjects;
    }
}

[System.Serializable]
public class CharacterMoveset
{
    public string CharacterName;
    public int CharacterMaxAmmo;
    public bool AutoReload, ReloadAll;
    public float ReloadTime;
    public GameObject[] AmmoObjects;
    public List<Attack> CharacterAttacks = new List<Attack>();
}
