﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine.UI;
using UnityEngine;

public class QuickSettingsMenu : MonoBehaviour
{
    public GameObject QuickMenu;

    bool MenuActive;

    PlayerController PC;
    CharacterCombatControl CCC;

    Vector2 CurrentButton;
    public Button[] ButtonsRowOne = new Button[5];
    public Button[] ButtonsRowTwo = new Button[5];
    public Button[] ButtonsRowCheats = new Button[5];

    int CurrentRowLength;

    public Text DeadZoneText, CamSensiText;

    public GameObject CheatMenu;
    public Text[] CheatButtonSwitch = new Text[3];

    int LastCheatInput, CheatInputCount;
    bool FailedCheat, CheatsUnlocked;
    //1 = special button 2 = light attack 3 = heavy attack 4 = lockon button
    int[] HealthCheatCode = { 3, 2, 1, 1, 2, 3 };
    int[] StaminaCheatCode = { 1, 2, 1, 2, 3, 2 };
    int[] AmmoCheatcode = { 2, 2, 1, 2, 2, 3};
    bool[] CheatsActive = { false, false, false };
    bool InfStamUnlocked, TryingInfStam;
    bool InfHealthUnlocked, TryingInfHealth;
    bool InfAmmoUnlocked, TryingInfAmmo;

    float InputTimer;

    private void Start()
    {
        PC = GetComponent<PlayerController>();
        CCC = GetComponent<CharacterCombatControl>();

        StartupTextValues();
        CheatsUnlocked = false;
    }

    void Update()
    {
        if(!MenuActive)
        {
            QuickMenu.SetActive(false);
            PC.InMenu = false;
        }
        else
        {
            Cursor.lockState = CursorLockMode.None;
            Cursor.visible = true;

            QuickMenu.SetActive(true);
            PC.InMenu = true;

            CheckSelectedButton();
            SelectButton();

            ReadCheatButtons();
            UnlockCheats();
        }

        if(PC.SelectButton)
        {
            if(MenuActive)
            {
                MenuActive = false;
            }
            else
            {
                MenuActive = true;
            }
        }

        CheatControl();
    }

    void SelectButton()
    {
        if(CurrentButton.x == 0)
        {
            CurrentRowLength = ButtonsRowOne.Length - 1;

            for(int i = 0; i < ButtonsRowOne.Length; i++)
            {
                if (i == CurrentButton.y) 
                {
                    ColorBlock ButtonColors = ButtonsRowOne[i].colors;
                    ButtonColors.normalColor = Color.green;

                    ButtonsRowOne[i].colors = ButtonColors;

                    if(PC.JumpButton)
                    {
                        ButtonsRowOne[i].onClick.Invoke();
                    }
                }
                else
                {
                    ColorBlock ButtonColors = ButtonsRowOne[i].colors;
                    ButtonColors.normalColor = Color.white;

                    ButtonsRowOne[i].colors = ButtonColors;
                }


                ColorBlock ButtonColorsTwo = ButtonsRowTwo[i].colors;
                ButtonColorsTwo.normalColor = Color.white;

                ButtonsRowTwo[i].colors = ButtonColorsTwo;
            }
        }
        else if(CurrentButton.x == 1)
        {
            CurrentRowLength = ButtonsRowTwo.Length - 1;

            for (int i = 0; i < ButtonsRowTwo.Length; i++)
            {
                if (i == CurrentButton.y)
                {
                    ColorBlock ButtonColorsTwo = ButtonsRowTwo[i].colors;
                    ButtonColorsTwo.normalColor = Color.green;

                    ButtonsRowTwo[i].colors = ButtonColorsTwo;

                    if (PC.JumpButton)
                    {
                        ButtonsRowTwo[i].onClick.Invoke();
                    }
                }
                else
                {
                    ColorBlock ButtonColorsTwo = ButtonsRowTwo[i].colors;
                    ButtonColorsTwo.normalColor = Color.white;

                    ButtonsRowTwo[i].colors = ButtonColorsTwo;
                }

                ColorBlock ButtonColors = ButtonsRowOne[i].colors;
                ButtonColors.normalColor = Color.white;

                ButtonsRowOne[i].colors = ButtonColors;

            }
        }
        else if(CurrentButton.x == 2 && CheatsUnlocked)
        {
            CurrentRowLength = ButtonsRowCheats.Length - 1;

            foreach (Button b in ButtonsRowOne)
            {
                ColorBlock ButtonColors = b.colors;
                ButtonColors.normalColor = Color.white;

                b.colors = ButtonColors;
            }
            foreach(Button b in ButtonsRowTwo)
            {
                ColorBlock ButtonColors = b.colors;
                ButtonColors.normalColor = Color.white;

                b.colors = ButtonColors;
            }

            for (int i = 0; i < ButtonsRowCheats.Length; i++)
            {
                if (i == CurrentButton.y)
                {
                    ColorBlock ButtonColors = ButtonsRowCheats[i].colors;
                    ButtonColors.normalColor = Color.green;

                    ButtonsRowCheats[i].colors = ButtonColors;

                    if (PC.JumpButton)
                    {
                        ButtonsRowCheats[i].onClick.Invoke();
                    }
                }
                else
                {
                    ColorBlock ButtonColors = ButtonsRowCheats[i].colors;
                    ButtonColors.normalColor = Color.white;

                    ButtonsRowCheats[i].colors = ButtonColors;
                }
            }
        }
    }
    void CheckSelectedButton()
    {
        if(PC.MoveInput == Vector2.zero)
        {
            InputTimer = 0;
        }
        else if(InputTimer > 0)
        {
            InputTimer -= Time.deltaTime;
        }
        else if(InputTimer <= 0)
        {
            if(PC.MoveInput.x > 0)
            {
                CurrentButton.x += 1;
            }
            else if(PC.MoveInput.x < 0)
            {
                CurrentButton.x -= 1;
            }
            else if(PC.MoveInput.y > 0)
            {
                CurrentButton.y -= 1;
            }
            else if (PC.MoveInput.y < 0)
            {
                CurrentButton.y += 1;
            }

            if(CurrentButton.x > 1 && !CheatsUnlocked)
            {
                CurrentButton.x = 0;
            }
            else if(CurrentButton.x > 2 && CheatsUnlocked)
            {
                CurrentButton.x = 0;
            }
            else if(CurrentButton.x < 0)
            {
                CurrentButton.x = 1;
            }

            if(CurrentButton.y < 0)
            {
                CurrentButton.y = CurrentRowLength;
            }
            else if(CurrentButton.y > CurrentRowLength)
            {
                CurrentButton.y = 0;
            }

            InputTimer = 0.5f;
        }
    }

    public void ChangeDeadZone(int Amount)
    {
        if(Amount > 0 && PC.BlockDirDeadzone < 1f)
        {
            PC.BlockDirDeadzone += 0.1f;
        }
        else if(Amount < 0 && PC.BlockDirDeadzone > 0.1f)
        {
            PC.BlockDirDeadzone -= 0.1f;
        }

        DeadZoneText.text = "GUARD DEADZONE\n" + PC.BlockDirDeadzone.ToString("0.0");
    }
    public void ChangeSensi(int Amount)
    {
        if (Amount > 0 && PC.MouseSensi < 25f)
        {
            PC.MouseSensi += 1;
        }
        else if (Amount < 0 && PC.MouseSensi > 1)
        {
            PC.MouseSensi -= 1;
        }

        CamSensiText.text = "CAMERA SENSI\n" + PC.MouseSensi;
    }

    void ReadCheatButtons()
    {
        if(PC.SpecialButton)
        {
            if(CheatInputCount <= 0)
            {
                TryingInfStam = true;
            }

            LastCheatInput = 1;
        }
        else if(PC.LightButton)
        {
            if (CheatInputCount <= 0)
            {
                TryingInfAmmo = true;
            }

            LastCheatInput = 2;
        }
        else if(PC.HeavyButton)
        {
            if (CheatInputCount <= 0)
            {
                TryingInfHealth = true;
            }

            LastCheatInput = 3;
        }
    }
    void UnlockCheats()
    {
        if(TryingInfStam)
        {
            if(LastCheatInput != 0 && LastCheatInput == StaminaCheatCode[CheatInputCount])
            {
                LastCheatInput = 0;
                CheatInputCount += 1;
            }
            else if(LastCheatInput != 0 && LastCheatInput != StaminaCheatCode[CheatInputCount])
            {
                TryingInfStam = false;
                FailedCheat = true;
            }
            else if(CheatInputCount >= StaminaCheatCode.Length)
            {
                print("UnlockedStaminaCheat");
                InfStamUnlocked = true;

                TryingInfStam = false;
                FailedCheat = true;
            }
        }
        if(TryingInfHealth)
        {
            if (LastCheatInput != 0 && LastCheatInput == HealthCheatCode[CheatInputCount])
            {
                LastCheatInput = 0;
                CheatInputCount += 1;
            }
            else if (LastCheatInput != 0 && LastCheatInput != HealthCheatCode[CheatInputCount])
            {
                TryingInfHealth = false;
                FailedCheat = true;
            }
            else if (CheatInputCount >= HealthCheatCode.Length)
            {
                print("UnlockedHealthCheat");
                InfHealthUnlocked = true;

                TryingInfHealth = false;
                FailedCheat = true;
            }
        }
        if (TryingInfAmmo)
        {
            if (LastCheatInput != 0 && LastCheatInput == AmmoCheatcode[CheatInputCount])
            {
                LastCheatInput = 0;
                CheatInputCount += 1;
            }
            else if (LastCheatInput != 0 && LastCheatInput != AmmoCheatcode[CheatInputCount])
            {
                TryingInfAmmo = false;
                FailedCheat = true;
            }
            else if (CheatInputCount >= AmmoCheatcode.Length)
            {
                print("UnlockedHealthCheat");
                InfAmmoUnlocked = true;

                TryingInfAmmo = false;
                FailedCheat = true;
            }
        }

        if (FailedCheat || CheatInputCount > 6)
        {
            LastCheatInput = 0;
            CheatInputCount = 0;
            FailedCheat = false;
        }
    }
    void CheatControl()
    {
        if (CheatsActive[0] && InfHealthUnlocked)
        {
            CCC.CurrentHealth = CCC.MaxHealth;
        }
        if(!InfHealthUnlocked)
        {
            CheatButtonSwitch[0].gameObject.SetActive(false);
        }
        else
        {
            CheatButtonSwitch[0].gameObject.SetActive(true);
        }

        if (CheatsActive[1] && InfStamUnlocked)
        {
            CCC.CurrentStamina = CCC.MaxStamina;
        }
        if (!InfStamUnlocked)
        {
            CheatButtonSwitch[1].gameObject.SetActive(false);
        }
        else
        {
            CheatButtonSwitch[1].gameObject.SetActive(true);
        }

        if (CheatsActive[2] && InfAmmoUnlocked)
        {
            CCC.CurrentAmmo = CCC.MaxAmmo;
        }
        if (!InfAmmoUnlocked)
        {
            CheatButtonSwitch[2].gameObject.SetActive(false);
        }
        else
        {
            CheatButtonSwitch[2].gameObject.SetActive(true);
        }

        if(!CheatsUnlocked && (InfAmmoUnlocked || InfHealthUnlocked || InfStamUnlocked))
        {
            CheatsUnlocked = true;
            CheatMenu.SetActive(true);
        }
        else if(!CheatsUnlocked)
        {
            CheatMenu.SetActive(false);
        }

        for (int i = 0; i < CheatsActive.Length; i++)
        {
            if(CheatsActive[i])
            {
                CheatButtonSwitch[i].text = "I";
            }
            else
            {
                CheatButtonSwitch[i].text = "O";
            }
        }
    }

    public void SetCheatStatus(int CheatIndex)
    {
        if(CheatsActive[CheatIndex])
        {
            CheatsActive[CheatIndex] = false;
        }
        else
        {
            CheatsActive[CheatIndex] = true;
        }
    }

    void StartupTextValues()
    {
        DeadZoneText.text = "GUARD DEADZONE\n" + PC.BlockDirDeadzone.ToString("0.0");
        CamSensiText.text = "CAMERA SENSI\n" + PC.MouseSensi;
    }
}
