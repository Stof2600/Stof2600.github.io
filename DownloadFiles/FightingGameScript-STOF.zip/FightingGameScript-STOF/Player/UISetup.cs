﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class UISetup : MonoBehaviour
{
    public int PlayerCount, MyPlayer;
    public Camera PlayerCam;

    public RectTransform[] ScaledObjects;
    public Vector3[] ObjectPosOneP;
    public Vector3[] ObjectPosTwoP;
    public Vector3[] ObjectPosFourP;

    private void Start()
    {
        ResetUI();
    }

    void SinglePlayerSetup()
    {
        PlayerCam.rect = new Rect(0, 0, 1, 1);
        PlayerCam.fieldOfView = 75;

        ReSizeObjects(1);
        ScaledObjects[3].gameObject.SetActive(true);
    }

    void TwoPlayerSetup()
    {
        switch (MyPlayer)
        {
            case 1:
                PlayerCam.rect = new Rect(0, 0.5f, 1, 0.5f);
                break;
            case 2:
                PlayerCam.rect = new Rect(0, 0, 1, 0.5f);
                break;
        }
        PlayerCam.fieldOfView = 60;

        ReSizeObjects(0.7f);
        ScaledObjects[3].gameObject.SetActive(true);
    }

    void FourPlayerSetup()
    {
        switch (MyPlayer)
        {
            case 1:
                PlayerCam.rect = new Rect(0, 0.5f, 0.5f, 0.5f);
                break;
            case 2:
                PlayerCam.rect = new Rect(0, 0, 0.5f, 0.5f);
                break;
            case 3:
                PlayerCam.rect = new Rect(0.5f, 0.5f, 0.5f, 0.5f);
                break;
            case 4:
                PlayerCam.rect = new Rect(0.5f, 0, 0.5f, 0.5f);
                break;
        }

        PlayerCam.fieldOfView = 65;

        ReSizeObjects(0.7f);
        ScaledObjects[3].gameObject.SetActive(false);
    }

    void ReSizeObjects(float NewScale)
    {
        foreach (RectTransform t in ScaledObjects)
        {
            t.localScale = new Vector3(NewScale, NewScale, NewScale);

            if (t.name == "EnemyStatOverlay")
            {
                t.localScale = new Vector3(-NewScale, NewScale, NewScale);
            }
        }

        for (int i = 0; i < ScaledObjects.Length; i++)
        {
            if (PlayerCount == 1)
            {
                ScaledObjects[i].localPosition = ObjectPosOneP[i];
            }
            else if (PlayerCount == 2)
            {
                ScaledObjects[i].localPosition = ObjectPosTwoP[i];
            }
        }
    }

    public void ResetUI()
    {
        if (PlayerCount == 1)
        {
            SinglePlayerSetup();
        }
        else if (PlayerCount == 2)
        {
            TwoPlayerSetup();
        }
        else if (PlayerCount > 2)
        {
            FourPlayerSetup();
        }
    }
}
