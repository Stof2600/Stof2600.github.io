﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine.UI;
using UnityEngine;

public class CharacterCombatControl : MonoBehaviour
{
    public int CurrentHealth, MaxHealth;
    public float CurrentStamina, MaxStamina;
    public int CurrentAmmo, MaxAmmo;

    public int Team;
    public float RespawnTime = 3;

    public AttackDir MyAttackDir;

    GameController GC;
    CharacterAttackList AttackList;

    public Attack[] IncomingAttacks = new Attack[3];
    public Attack CurrentAttack;

    public CharacterCombatControl Target;
    public Transform ModelHolder, UnblockableEffect;
    public MeshRenderer ShadowMesh;

    public CapsuleCollider CapCol;

    Material LocalMat;

    public float DefaultDmgMulti;
    public float DmgMulti;
    public float BashForceMulti;
    public float SpeedMulti;

    public bool DoAttack, DoHeavyAttack, DoSpecialAttack, DoBash, InAttack, Dead;
    public bool LockMovement;

    public bool DidParry, DidBlock, DidBash;
    public float BlockTimer;
    float CounterTimer;

    public bool OnGround, Stunned, ShortStun, Knockback;
    public float MaxStunTime = 1f, ShortStunTime = 0.4f, MaxKnockbackTime = 0.5f, StaminaRegenTime = 1;
    float StunTimer, KnockbackTimer, StaminaRegenTimer;

    public bool DisplayDamage;

    float DeathTimer;

    public RespawnPoint SpawnPoint;
    public bool CanRespawn, ForceRespawn;

    int[] IATCheck = new int[3]; //Incoming Attack Timer Check
    int[] IASCheck = new int[3]; //Incoming Attack Stuck Check

    string LastAttackName;
    float LastAttackTimer;

    public CharacterCombatControl LastPlayerHit;
    public GameObject DeathEffect, ClashEffect;
    bool PlayedClashEffect;

    #region StaminaValues
    [Header ("Stamina Costs")]
    public float BashCost = 12;
    [Header("Stamina Regain")]
    public float DefaultStaminaRegain;
    #endregion

    #region RangedWeaponValues
    [Header("Ranged Weapon Values")]
    public bool AutoReload;
    public bool DoReload;
    public bool ReloadAll;
    public float ReloadTime;
    float ReloadTimer;
    public GameObject[] AmmoObjects;
    #endregion

    #region UIValues
    [Header ("UI Values")]
    public bool UseUI;
    public bool ForceOverlay;
    public GameObject IncomingAttackOverlay;
    public GameObject EnemyStatOverlay;
    public Image[] CrossGuardArrows = new Image[3];
    public Image[] CrossAttackArrows = new Image[3];
    public Slider HealthBar, EnemyHealthBar;
    public Text HealthText, EnemyHealthText;
    public Transform GuardStaminaFill, GuardStaminaLine; Image GuardStaminaImage;
    public Transform StaminaFill, EnemyStaminaFill;
    public Transform StaminaLine, EnemyStaminaLine;
    public Text ScoreDisplay;
    public Text AmmoText, EnemyAmmoText;
    public float StaminaLineMax = 360;

    public GameObject[] BulletBackSlot = new GameObject[20];
    public GameObject[] BulletFillSlot = new GameObject[20];

    public GameObject[] NMYBulletBackSlot = new GameObject[20];
    public GameObject[] NMYBulletFillSlot = new GameObject[20];
    #endregion

    private void Start()
    {
        GC = FindObjectOfType<GameController>();
        AttackList = GetComponent<CharacterAttackList>();
        AttackList.GetMaxAmmoValue(GetComponent<CharacterCombatControl>());

        CapCol = GetComponent<CapsuleCollider>();

        DmgMulti = DefaultDmgMulti;

        if(UseUI)
        {
            UnloadBulletSlots();
        }

        UnblockableEffect.gameObject.SetActive(false);
        UnblockableEffect.localPosition = Vector3.zero;

        CurrentHealth = MaxHealth;
        CurrentStamina = MaxStamina;
        CurrentAmmo = MaxAmmo;

        LocalMat = new Material(ShadowMesh.material);
        ShadowMesh.material = LocalMat;

        GuardStaminaImage = GuardStaminaFill.GetComponent<Image>();

        if(!GC.DeathMatchGameMode && Team > 1)
        {
            if(Team == 2)
            {
                Team = 0;
            }
            else
            {
                Team = 1;
            }
        }
    }

    void Update()
    {
        GroundCheck();

        if(!Dead && !ForceRespawn)
        {
            if (CurrentHealth <= 0)
            {
                Die();
            }

            UpdateAttacks();

            if (Stunned || ShortStun)
            {
                StunTimer += Time.deltaTime;

                if(ShortStun)
                {
                    Stunned = true;

                    if (StunTimer >= ShortStunTime)
                    {
                        StunTimer = 0;
                        ShortStun = false;
                        Stunned = false;
                    }
                }

                if (StunTimer >= MaxStunTime)
                {
                    StunTimer = 0;
                    Stunned = false;
                }
            }
            if (Knockback)
            {
                KnockbackTimer += Time.deltaTime;

                if (KnockbackTimer >= MaxKnockbackTime)
                {
                    KnockbackTimer = 0;
                    Knockback = false;
                }
            }
            if (DidParry)
            {
                LastAttackName = "Parry";
                LastAttackTimer = 0.3f;

                CounterTimer += Time.deltaTime;
                DmgMulti = DefaultDmgMulti + 0.5f;
                if (CounterTimer >= 1.5f)
                {
                    DmgMulti = DefaultDmgMulti;
                    CounterTimer = 0;
                    DidParry = false;
                }
            }
            if (DidBlock)
            {
                BlockTimer += Time.deltaTime;
                if (BlockTimer >= 0.2f)
                {
                    BlockTimer = 0;
                    DidBlock = false;
                }
            }

            AttackChecks();
            RangedWeaponUpdate();

            if (CurrentStamina < MaxStamina && StaminaRegenTimer >= StaminaRegenTime)
            {
                CurrentStamina += DefaultStaminaRegain * Time.deltaTime;
            }
            else if (CurrentStamina > MaxStamina)
            {
                CurrentStamina = MaxStamina;
            }
            else if(StaminaRegenTimer <= StaminaRegenTime)
            {
                StaminaRegenTimer += Time.deltaTime;
            }

            if(InAttack && CurrentAttack.Unblockable)
            {
                SetShadowColor(1, 0.6f, 0);
            }
            else if((InAttack && CurrentAttack.DoStun) || DidBash || DoBash)
            {
                SetShadowColor(0.5f, 0, 0.5f);
            }
            else
            {
                switch(Team)
                {
                    case 0:
                        SetShadowColor(0, 0, 1);
                        break;
                    case 1:
                        SetShadowColor(1, 0, 0);
                        break;
                    case 2:
                        SetShadowColor(0, 1, 0);
                        break;
                    case 3:
                        SetShadowColor(1, 1, 0);
                        break;
                }
            }
        }
        else
        {
            DeathTimer += Time.deltaTime;

            if((DeathTimer >= RespawnTime || ForceRespawn) && CanRespawn && SpawnPoint != null)
            {
                Respawn();
                ForceRespawn = false;
            }
            else if(!CanRespawn)
            {
                SpawnPoint = FindSpawnPoint();
            }
        }

        if (UseUI)
        {
            UIControl();
        }
    }

    void UpdateAttacks()
    {
        for (int i = 0; i < IncomingAttacks.Length; i++)
        {
            if(IncomingAttacks[i].Timer > 0)
            {
                if (IATCheck[i] < IncomingAttacks[i].Timer || IATCheck[i] > IncomingAttacks[i].Timer)
                {
                    IATCheck[i] = IncomingAttacks[i].Timer;
                    IASCheck[i] = 0;
                }
                else if (IATCheck[i] == IncomingAttacks[i].Timer)
                {
                    if (IASCheck[i] >= 3)
                    {
                        IncomingAttacks[i] = new Attack();
                    }

                    IASCheck[i] += 1;
                }
            }
            else
            {
                IATCheck[i] = 0;
                IASCheck[i] = 0;
            }


            if(!InAttack && !Stunned && IncomingAttacks[i].Timer <= IncomingAttacks[i].ActiveTime)
            {
                if (IncomingAttacks[i].Dir == AttackDir.Top && MyAttackDir == AttackDir.Top || DidBlock)
                {
                    if (DoHeavyAttack && IncomingAttacks[i].Dmg > 0 && IncomingAttacks[i].Timer >= IncomingAttacks[i].StartupTime)
                    {
                        DidParry = true;
                        IncomingAttacks[i].Paried = true;
                    }

                    if (!IncomingAttacks[i].Unblockable)
                    {
                        IncomingAttacks[i].Blocked = true;
                    }
                }
                else if (IncomingAttacks[i].Dir == AttackDir.Right && MyAttackDir == AttackDir.Left || DidBlock)
                {
                    if (DoHeavyAttack && IncomingAttacks[i].Dmg > 0 && IncomingAttacks[i].Timer >= IncomingAttacks[i].StartupTime)
                    {
                        DidParry = true;
                        IncomingAttacks[i].Paried = true;
                    }

                    if(!IncomingAttacks[i].Unblockable)
                    {
                        IncomingAttacks[i].Blocked = true;
                    }
                }
                else if (IncomingAttacks[i].Dir == AttackDir.Left && MyAttackDir == AttackDir.Right || DidBlock)
                {
                    if (DoHeavyAttack && IncomingAttacks[i].Dmg > 0 && IncomingAttacks[i].Timer >= IncomingAttacks[i].StartupTime)
                    {
                        DidParry = true;
                        IncomingAttacks[i].Paried = true;
                    }

                    if (!IncomingAttacks[i].Unblockable)
                    {
                        IncomingAttacks[i].Blocked = true;
                    }
                }

                if(IncomingAttacks[i].Blocked)
                {
                    if (IncomingAttacks[i].Dir == AttackDir.Top && MyAttackDir != AttackDir.Top && !DidBlock)
                    {
                        IncomingAttacks[i].Blocked = false;
                    }
                    else if (IncomingAttacks[i].Dir == AttackDir.Right && MyAttackDir != AttackDir.Left && !DidBlock)
                    {
                        IncomingAttacks[i].Blocked = false;
                    }
                    else if (IncomingAttacks[i].Dir == AttackDir.Left && MyAttackDir != AttackDir.Right && !DidBlock)
                    {
                        IncomingAttacks[i].Blocked = false;
                    }
                }
            }
            else if(InAttack && IncomingAttacks[i].Blocked)
            {
                IncomingAttacks[i].Blocked = false;
            }

            if (IncomingAttacks[i].Timer >= IncomingAttacks[i].ExitTime || (IncomingAttacks[i].Blocked && IncomingAttacks[i].DidCollisionCheck))
            {
                IncomingAttacks[i] = new Attack();
            }
        }

        switch(MyAttackDir)
        {
            case AttackDir.Top:
                Debug.DrawRay(transform.position, transform.up * 10, Color.red);
                break;
            case AttackDir.Right:
                Debug.DrawRay(transform.position, transform.right * 10, Color.blue);
                break;
            case AttackDir.Left:
                Debug.DrawRay(transform.position, -transform.right * 10, Color.green);
                break;
        }
    }

    void AttackChecks()
    {
        if(LastAttackTimer >= 0)
        {
            LastAttackTimer -= Time.deltaTime;
        }

        if ((DoAttack || (DoHeavyAttack && !DidParry) || DoSpecialAttack) && (!InAttack || (CurrentAttack.AllowFeint && CurrentAttack.Timer < CurrentAttack.ActiveTime)) && !Stunned)
        {
            bool CheckForFeint = false;

            if(InAttack && CurrentAttack.AllowFeint)
            {
                CurrentAttack.DidFeint = true;
                CurrentAttack = new Attack();
                CheckForFeint = true;
            }

            if (DoAttack)
            {
                AttackList.RewriteAttack(MyAttackDir, 0, CurrentAttack, LastAttackTimer, LastAttackName, OnGround);
            }
            else if (DoHeavyAttack)
            {
                AttackList.RewriteAttack(MyAttackDir, 1, CurrentAttack, LastAttackTimer, LastAttackName, OnGround);
            }
            else if (DoSpecialAttack)
            {
                AttackList.RewriteAttack(MyAttackDir, 2, CurrentAttack, LastAttackTimer, LastAttackName, OnGround);
            }

            if ((CurrentAttack.Dir == AttackDir.Mixed || CurrentAttack.Dir == AttackDir.LeftRightSplit) && Target != null)
            {
                CurrentAttack.Dir = MyAttackDir;
            }
            else if((CurrentAttack.Dir == AttackDir.Mixed || CurrentAttack.Dir == AttackDir.LeftRightSplit) && Target == null)
            {
                CurrentAttack.Dir = AttackDir.Top;
            }

            //add exit frames for better collision check
            //add 8 minimum
            CurrentAttack.ExitTime += 8;

            if(CheckForFeint)
            {
                CurrentAttack.Dmg = (int)(CurrentAttack.Dmg * DmgMulti * 0.75f);
            }

            if ((((CurrentAttack.UseAmmo || CurrentAttack.RequiresAmmo) && CurrentAmmo > 0) || !CurrentAttack.UseAmmo) && CurrentStamina >= CurrentAttack.StaminaCost && ((CurrentAttack.RequiresGround && OnGround) || !CurrentAttack.RequiresGround))
            {
                if (CurrentAttack.UseDmgMulti)
                {
                    CurrentAttack.Dmg = (int)(CurrentAttack.Dmg * DmgMulti);
                }

                if(!CurrentAttack.UseProjectile)
                {
                    if (Target != null)
                    {
                        Target.AddIncomingAttack(CurrentAttack);
                    }
                    else if (Physics.Raycast(transform.position, transform.forward, out RaycastHit HitInfo, CurrentAttack.Range) && HitInfo.transform.GetComponent<CharacterCombatControl>())
                    {
                        HitInfo.transform.GetComponent<CharacterCombatControl>().AddIncomingAttack(CurrentAttack);
                    }
                }

                LockMovement = false;
                DropStamina(CurrentAttack.StaminaCost);
                InAttack = true;
            }
            else
            {
                CreateEmptyAttack();
                return;
            }
        }
        else if (InAttack)
        {
            if(GC.DMWinningTeam > -1 && Team != GC.DMWinningTeam)
            {
                CurrentAttack.Dmg = 0;
            }
            else if (GC.TWWinningTeam > -1 && Team != GC.TWWinningTeam)
            {
                CurrentAttack.Dmg = 0;
            }

            CurrentAttack.Timer += 1;
            if(Stunned)
            {
                InAttack = false;
            }

            if (CurrentAttack.Paried)
            {
                Stunned = true;
            }

            if(CurrentAttack.Unblockable && CurrentAttack.TargetPoint != null)
            {
                UnblockableEffect.gameObject.SetActive(true);
                UnblockableEffect.position = CurrentAttack.TargetPoint.position;
            }

            if (Target != null && CurrentAttack.UseTracking)
            {
                Quaternion NewRot = Quaternion.LookRotation(Target.transform.position - transform.position);
                NewRot.eulerAngles = new Vector3(0, NewRot.eulerAngles.y, 0);

                transform.rotation = Quaternion.RotateTowards(transform.rotation, NewRot, 50 * Time.deltaTime);
            }

            if(!CurrentAttack.UseProjectile)
            {
                if (CurrentAttack.Timer > CurrentAttack.StartupTime && !CurrentAttack.DidCollisionCheck && !Stunned)
                {
                    if(CurrentAttack.TargetPoint != null)
                    {
                        Debug.DrawLine(transform.position, CurrentAttack.TargetPoint.position);
                    }

                    if (CurrentAttack.TargetPoint != null && Physics.Linecast(transform.position, CurrentAttack.TargetPoint.position, out RaycastHit LineHitInfo))
                    {
                        CharacterCombatControl EnemyCC = LineHitInfo.transform.GetComponent<CharacterCombatControl>();
                        BreakableWall Wall = LineHitInfo.transform.GetComponent<BreakableWall>();
                        SimpleAI WeakAICheck = LineHitInfo.transform.GetComponent<SimpleAI>();

                        if(EnemyCC == null && Wall == null && WeakAICheck == null && !PlayedClashEffect)
                        {
                            Instantiate(ClashEffect, LineHitInfo.point, transform.rotation);
                            PlayedClashEffect = true;
                        }

                        if (Wall != null)
                        {
                            Wall.CompareDamage(CurrentAttack.Dmg);
                        }

                        if(WeakAICheck != null)
                        {
                            WeakAICheck.Die();
                        }

                        if (EnemyCC != null)
                        {
                            if (CurrentAttack.Unblockable || !CurrentAttack.Blocked)
                            {
                                if(EnemyCC.Team != Team)
                                {
                                    EnemyCC.TakeDamage(CurrentAttack.Dmg);
                                    EnemyCC.LastPlayerHit = GetComponent<CharacterCombatControl>();
                                }
                                else
                                {
                                    EnemyCC.TakeDamage(CurrentAttack.Dmg / 4);
                                }

                                if(CurrentAttack.DoStun)
                                {
                                    EnemyCC.Stunned = true;
                                }

                                if (EnemyCC.CurrentHealth <= 0)
                                {
                                    Target = null;
                                }
                            }
                            else if(CurrentAttack.Blocked)
                            {
                                EnemyCC.DidBlock = true;
                                EnemyCC.BlockTimer = 0;

                                Instantiate(ClashEffect, LineHitInfo.point, transform.rotation);
                                PlayedClashEffect = true;
                                ShortStun = true;
                            }

                            CurrentAttack.HitTarget = true;
                            CurrentAttack.DidCollisionCheck = true;
                        }
                    }
                    else if (CurrentAttack.TargetPoint == null && Physics.Raycast(transform.position, transform.forward, out RaycastHit HitInfo, CurrentAttack.Range))
                    {
                        CharacterCombatControl EnemyCC = HitInfo.transform.GetComponent<CharacterCombatControl>();
                        BreakableWall Wall = HitInfo.transform.GetComponent<BreakableWall>();
                        SimpleAI WeakAICheck = HitInfo.transform.GetComponent<SimpleAI>();

                        if (Wall != null)
                        {
                            Wall.CompareDamage(CurrentAttack.Dmg);
                        }

                        if (WeakAICheck != null)
                        {
                            WeakAICheck.Die();
                        }

                        if (EnemyCC != null)
                        {
                            if (CurrentAttack.Unblockable || !CurrentAttack.Blocked)
                            {
                                EnemyCC.TakeDamage(CurrentAttack.Dmg);

                                if (CurrentAttack.DoStun)
                                {
                                    EnemyCC.Stunned = true;
                                }

                                if (EnemyCC.CurrentHealth <= 0)
                                {
                                    Target = null;
                                }
                            }
                            else if (CurrentAttack.Blocked)
                            {
                                EnemyCC.DidBlock = true;
                                EnemyCC.BlockTimer = 0;

                                Instantiate(ClashEffect, HitInfo.point, transform.rotation);
                                PlayedClashEffect = true;
                                ShortStun = true;
                            }

                            CurrentAttack.HitTarget = true;
                            CurrentAttack.DidCollisionCheck = true;
                        }
                    }
                }
            }
            else
            {
                if(CurrentAttack.Timer >= CurrentAttack.ProjectileTime && !CurrentAttack.DidCollisionCheck)
                {
                    GameObject NewProj = Instantiate(CurrentAttack.Projectile, CurrentAttack.TargetPoint.position, ModelHolder.rotation);
                    Projectile NewProjScript = NewProj.GetComponent<Projectile>();
                    NewProjScript.Damage = CurrentAttack.Dmg;
                    NewProjScript.AttachedAttackDir = CurrentAttack.Dir;

                    if(Target != null)
                    {
                        NewProj.transform.LookAt(Target.transform.position);
                    }

                    NewProjScript.DoMove = true;
                    CurrentAttack.DidCollisionCheck = true;
                }
            }


            if (CurrentAttack.Timer >= CurrentAttack.ExitTime)
            {
                if(!CurrentAttack.DidCollisionCheck)
                {
                    CurrentAttack.DidCollisionCheck = true;
                }

                if(CurrentAttack.UseAmmo)
                {
                    CurrentAmmo -= 1;
                }

                InAttack = false;
                DoAttack = false;

                LastAttackName = CurrentAttack.AttackName;
                LastAttackTimer = CurrentAttack.FollowUpTime;

                CreateEmptyAttack();
            }

            if(OnGround)
            {
                LockMovement = true;
            }
        }
        else
        {
            LockMovement = false;

            UnblockableEffect.gameObject.SetActive(false);
            UnblockableEffect.localPosition = Vector3.zero;
            PlayedClashEffect = false;
        }



        if (DoBash && !DidBash && !OnGround)
        {
            CheckForBash();
        }
        else if (!DoBash && OnGround && DidBash)
        {
            DidBash = false;
        }
    }

    void RangedWeaponUpdate()
    {
        if((AutoReload || DoReload) && CurrentAmmo < MaxAmmo)
        {
            if(DoReload && (!OnGround || DoAttack || DoHeavyAttack || DoSpecialAttack || Stunned || Knockback))
            {
                DoReload = false;
            }

            ReloadTimer += Time.deltaTime;

            if(ReloadTimer >= ReloadTime)
            {
                if(ReloadAll)
                {
                    CurrentAmmo = MaxAmmo;
                }
                else
                {
                    CurrentAmmo += 1;
                }

                ReloadTimer = 0;
            }
        }
        else if(CurrentAmmo >= MaxAmmo)
        {
            DoReload = false;
            CurrentAmmo = MaxAmmo;
        }

        if(AmmoObjects.Length > 0 && !InAttack)
        {
            for (int i = 0; i < AmmoObjects.Length; i++)
            {
                if(i >= CurrentAmmo)
                {
                    AmmoObjects[i].SetActive(false);
                }
                if(i < CurrentAmmo)
                {
                    AmmoObjects[i].SetActive(true);
                }
            }
        }
    }

    public void AddIncomingAttack(Attack AttackInfo)
    {
        switch (AttackInfo.Dir)
        {
            case AttackDir.Top:
                IncomingAttacks[0] = AttackInfo;
                break;
            case AttackDir.Right:
                IncomingAttacks[1] = AttackInfo;
                break;
            case AttackDir.Left:
                IncomingAttacks[2] = AttackInfo;
                break;
        }
    }

    void CheckForBash()
    {
        if(Physics.Raycast(transform.position, transform.forward, out RaycastHit HitInfo, 0.8f) && CurrentStamina >= BashCost && !HitInfo.transform.GetComponent<CharacterCombatControl>().Knockback)
        {
            Rigidbody TargetRB = HitInfo.transform.GetComponent<Rigidbody>();
            CharacterCombatControl TargetCC = HitInfo.transform.GetComponent<CharacterCombatControl>();

            if(TargetRB != null)
            {
                TargetRB.AddForce(transform.forward * 15 * BashForceMulti, ForceMode.Impulse);
                transform.GetComponent<Rigidbody>().velocity = Vector3.zero;
            }
            if(TargetCC != null)
            {
                TargetCC.Stunned = true;
                TargetCC.Knockback = transform;
                TargetCC.LastPlayerHit = GetComponent<CharacterCombatControl>();
            }

            DropStamina(BashCost);
            DidBash = true;
        }
    }

    void UIControl()
    {
        for (int i = 0; i < CrossGuardArrows.Length; i++)
        {
            if(i == ((int)MyAttackDir))
            {
                if(InAttack)
                {
                    CrossGuardArrows[i].color = Color.red;
                }
                else
                {
                    CrossGuardArrows[i].color = Color.blue;
                }

            }
            else
            {
                CrossGuardArrows[i].color = Color.black;
            }
        }

        for (int i = 0; i < CrossAttackArrows.Length; i++)
        {
            if(Target != null || IncomingAttacks[i].Timer > 0)
            {
                ForceOverlay = true;
            }

            if(ForceOverlay)
            {
                if (IncomingAttacks[i].Timer > 0)
                {
                    IncomingAttackOverlay.SetActive(true);

                    if (IncomingAttacks[i].Timer <= IncomingAttacks[i].StartupTime)
                    {
                        CrossAttackArrows[i].gameObject.SetActive(true);

                        if (IncomingAttacks[i].Unblockable)
                        {
                            CrossAttackArrows[i].color = new Color(1, 0.6f, 0);
                        }
                        else
                        {
                            CrossAttackArrows[i].color = Color.red;
                        }

                    }
                    else if (IncomingAttacks[i].Timer <= IncomingAttacks[i].ActiveTime)
                    {
                        CrossAttackArrows[i].gameObject.SetActive(true);
                        CrossAttackArrows[i].color = Color.white;
                    }
                    else if (IncomingAttacks[i].Timer <= IncomingAttacks[i].ExitTime)
                    {

                        if (IncomingAttacks[i].DidCollisionCheck)
                        {
                            if (!IncomingAttacks[i].HitTarget)
                            {
                                CrossAttackArrows[i].gameObject.SetActive(true);
                                CrossAttackArrows[i].color = Color.grey;
                            }
                            if (IncomingAttacks[i].Paried)
                            {
                                CrossAttackArrows[i].gameObject.SetActive(true);
                                CrossAttackArrows[i].color = Color.green;
                            }
                            else if (IncomingAttacks[i].Blocked)
                            {
                                CrossAttackArrows[i].gameObject.SetActive(true);
                                CrossAttackArrows[i].color = Color.blue;
                            }
                            else
                            {
                                CrossAttackArrows[i].gameObject.SetActive(true);
                                CrossAttackArrows[i].color = Color.black;
                            }
                        }

                    }
                }
                else
                {
                    if (Target != null && i == (int)Target.MyAttackDir && !Target.Stunned)
                    {
                        CrossAttackArrows[(int)Target.MyAttackDir].gameObject.SetActive(true);
                        CrossAttackArrows[(int)Target.MyAttackDir].color = Color.grey;
                    }
                    else
                    {
                        CrossAttackArrows[i].gameObject.SetActive(false);
                    }
                }
            }
            else
            {
                CrossAttackArrows[i].gameObject.SetActive(false);
            }
        }

        if (Target != null)
        {
            EnemyStatOverlay.SetActive(true);

            EnemyHealthBar.maxValue = Target.MaxHealth;
            EnemyHealthBar.value = Target.CurrentHealth;

            EnemyHealthText.text = Target.CurrentHealth + "/" + Target.MaxHealth;

            float EnemyStaminaValue = Target.CurrentStamina / Target.MaxStamina;
            EnemyStaminaFill.localScale = new Vector3(EnemyStaminaValue, EnemyStaminaValue, 0);
            EnemyStaminaLine.localEulerAngles = new Vector3(0, 0, StaminaLineMax * EnemyStaminaValue);

            EnemyAmmoText.text = Target.CurrentAmmo.ToString("00") + "/" + Target.MaxAmmo.ToString("00");

            for (int i = 0; i < NMYBulletBackSlot.Length; i++)
            {
                if (i >= Target.MaxAmmo)
                {
                    NMYBulletBackSlot[i].SetActive(false);
                }
                else
                {
                    NMYBulletBackSlot[i].SetActive(true);
                }

                if(i >= Target.CurrentAmmo)
                {
                    NMYBulletFillSlot[i].SetActive(false);
                }
                else
                {
                    NMYBulletFillSlot[i].SetActive(true);
                }
            }
        }
        else
        {
            ForceOverlay = false;
            EnemyStatOverlay.SetActive(false);
        }

        HealthBar.maxValue = MaxHealth;
        HealthBar.value = CurrentHealth;

        HealthText.text = CurrentHealth.ToString("000") + "/" + MaxHealth.ToString("000");

        float StaminaValue = CurrentStamina / MaxStamina;
        StaminaFill.localScale = new Vector3(StaminaValue, StaminaValue, 0);
        StaminaLine.localEulerAngles = new Vector3(0, 0, StaminaLineMax * StaminaValue);

        GuardStaminaFill.localScale = new Vector3(StaminaValue, StaminaValue, 0);
        GuardStaminaLine.localEulerAngles = new Vector3(0, 0, StaminaLineMax * StaminaValue);
        GuardStaminaImage.color = Color.Lerp(new Color(1, 0, 0), new Color(0, 0.5843138f, 1), StaminaValue);

        if (GC.TurfWarGameMode)
        {
            float DisplayCurrentScore;

            if (Team == 0)
            {
                DisplayCurrentScore = GC.CurrentScore;
            }
            else
            {
                DisplayCurrentScore = -GC.CurrentScore;
            }
            ScoreDisplay.text = "SCORE\n" + DisplayCurrentScore.ToString("000") + " : " + GC.TWWinScore.ToString("000");

        }
        else if(GC.DeathMatchGameMode)
        {
            string DMScoreOut = "SCORE\n";

            for (int i = 0; i < GC.TeamScores.Length; i++)
            {
                if(GC.TeamScores[i] >= 0)
                {
                    DMScoreOut += GC.TeamScores[i].ToString("00");

                    if(i < GC.TeamScores.Length - 1 && GC.TeamScores[i + 1] >= 0)
                    {
                        DMScoreOut += " : ";
                    }
                }
            }

            ScoreDisplay.text = DMScoreOut;
        }


        AmmoText.text = CurrentAmmo.ToString("00") + "/" + MaxAmmo.ToString("00");

        for (int i = 0; i < BulletFillSlot.Length; i++)
        {
            if (i >= CurrentAmmo)
            {
                BulletFillSlot[i].SetActive(false);
            }
            else
            {
                BulletFillSlot[i].SetActive(true);
            }

        }
    }

    public void InputDir(int Input)
    {
        if(!InAttack || CurrentAttack.AllowFeint)
        {
            switch (Input)
            {
                case 0:
                    MyAttackDir = AttackDir.Top;
                    break;
                case 1:
                    MyAttackDir = AttackDir.Right;
                    break;
                case 2:
                    MyAttackDir = AttackDir.Left;
                    break;
                default:
                    MyAttackDir = AttackDir.Top;
                    break;
            }
        }
    }

    public void TakeDamage(int Amount)
    {
        CurrentAttack.Blocked = true;

        if(!Stunned)
        {
            ShortStun = true;
        }

        DisplayDamage = true;
        CurrentHealth -= Amount;
    }
    public void DropStamina(float Amount)
    {
        CurrentStamina -= Amount;
        StaminaRegenTimer = 0;
    }

    void CreateEmptyAttack()
    {
        CurrentAttack = new Attack();
    }

    private void OnTriggerEnter(Collider other)
    {
        if(other.gameObject.CompareTag("DeathBarrier"))
        {
            CurrentHealth = 0;
            Die();
        }
        if(other.GetComponent<EffectZone>())
        {
            other.GetComponent<EffectZone>().EffectedPlayers.Add(GetComponent<CharacterCombatControl>());
        }
    }
    private void OnTriggerExit(Collider other)
    {
        if (other.GetComponent<EffectZone>())
        {
            other.GetComponent<EffectZone>().EffectedPlayers.Remove(GetComponent<CharacterCombatControl>());
        }
    }

    void GroundCheck()
    {
        Collider[] Hits = Physics.OverlapSphere(transform.position - new Vector3(0, CapCol.height / 2f, 0), 0.25f);
        Collider GroundHit = null;

        foreach(Collider hit in Hits)
        {
            if(!hit.CompareTag("LockOnTarget") && !hit.GetComponent<Collider>().isTrigger)
            {
                GroundHit = hit;
            }
        }

        if (GroundHit != null)
        {
            OnGround = true;
        }
        else
        {
            OnGround = false;
        }
    }

    void Die()
    {
        Dead = true;
        DeathTimer = 0;

        CanRespawn = false;
        SpawnPoint = null;

        Quaternion Rot = Quaternion.Euler(-90, 0, 0);
        Instantiate(DeathEffect, transform.position - new Vector3(0, 0.5f, 0), Rot, transform);

        //GetComponent<Rigidbody>().isKinematic = true;
        CapCol.enabled = false;

        if(LastPlayerHit != null)
        {
            GC.AddScore(10, LastPlayerHit.Team);
            LastPlayerHit = null;
        }
    }
    RespawnPoint FindSpawnPoint()
    {
        RespawnPoint SP = null;

        GameObject[] AllRespawnPoints = GameObject.FindGameObjectsWithTag("RespawnPoint");
        List<RespawnPoint> AvailablePoints = new List<RespawnPoint>();

        foreach (GameObject g in AllRespawnPoints)
        {
            RespawnPoint Point = g.GetComponent<RespawnPoint>();

            if (Point != null && Point.Team == Team && Point.CanUse)
            {
                AvailablePoints.Add(Point);
            }
        }

        if (AvailablePoints.Count > 0)
        {
            int R = Random.Range(0, AvailablePoints.Count);

            SP = AvailablePoints[R];
            SP.PlayersConnected.Add(transform);
        }

        return SP;
    }
    void Respawn()
    {
        GetComponent<Rigidbody>().velocity = Vector3.zero;
        transform.position = SpawnPoint.transform.position;
        transform.rotation = SpawnPoint.transform.rotation;
        SpawnPoint.CanUse = false;

        ResetCharacterValues();
        Dead = false;
    }

    void SetShadowColor(float Red, float Green, float Blue)
    {
        LocalMat.color = new Color(Red, Green, Blue);
    }

    public void ResetCharacterValues()
    {
        CurrentHealth = MaxHealth;
        CurrentStamina = MaxStamina;
        CurrentAmmo = MaxAmmo;

        DmgMulti = DefaultDmgMulti;

        DoAttack = false;
        DoHeavyAttack = false;
        DoSpecialAttack = false;
        DoBash = false;
        InAttack = false;

        LockMovement = false;
        Stunned = false;
        Knockback = false;

        DidParry = false;
        DidBash = false;

        ReloadTimer = 0;
        CounterTimer = 0;
        StunTimer = 0;
        KnockbackTimer = 0;

        Target = null;

        IncomingAttacks[0] = new Attack();
        IncomingAttacks[1] = new Attack();
        IncomingAttacks[2] = new Attack();

        CreateEmptyAttack();

        if(CapCol != null)
        {
            CapCol.enabled = true;
        }

        GetComponent<Rigidbody>().isKinematic = false;
    }

    void UnloadBulletSlots()
    {
        for (int i = 0; i < BulletBackSlot.Length; i++)
        {
            if (i >= MaxAmmo)
            {
                BulletBackSlot[i].SetActive(false);
                BulletFillSlot[i].SetActive(false);
            }
        }
    }
}

[System.Serializable]
public class Attack
{
    [Header ("BasicInfo")]
    public string AttackName;
    public int AttackType;

    public AttackDir Dir;
    public int Dmg;
    public float Range;
    public Transform TargetPoint;
    public float StaminaCost;

    public bool Unblockable;
    public bool DoStun;
    public bool UseTracking;
    public bool RequiresGround;
    public bool AllowFeint;
    public bool FollowUpAttack;
    public string OriginAttackName;
    public bool UseDmgMulti;
    public bool UseAmmo; //if the attack uses ammo
    public bool RequiresAmmo; //if you need to have ammo to do the attack (doesn't actually use it)
    public bool UseProjectile;
    public GameObject Projectile;
    [Header("Timers")]
    public int StartupTime;
    public int ActiveTime;
    public int ExitTime;

    public float FollowUpTime;

    public int ProjectileTime;

    public int Timer;

    [Header("InGameValues")]
    public bool Blocked;
    public bool Paried;
    public bool DidFeint;
    public bool HitTarget;

    public bool DidCollisionCheck;
}

public enum AttackDir
{
    Top,
    Right,
    Left,
    Mixed,
    LeftRightSplit
}

