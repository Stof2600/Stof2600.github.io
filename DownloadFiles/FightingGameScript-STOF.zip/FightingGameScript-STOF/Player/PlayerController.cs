﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine.UI;
using UnityEngine;

public class PlayerController : MonoBehaviour
{

    [Header ("Basic Values")]
    public Rigidbody PlayerRB;
    Vector2 PlayerInput;
    public bool Jump, OnGround;

    public Transform ModelHolder;

    public float CurrentSpeed;
    public float WalkSpeed = 20, RunSpeed = 25, BackWalkSpeed = 8, JumpSpeed = 50;
    public float jumpStaminaCost = 10, SprintStaminaCost = 0.1f;
    public float VelMag;

    public int PlayerOrder;

    public PhysicMaterial DefaultPhysics, FreezePhysics;
    public LayerMask IgnoreCollisions;

    GameController GC;

    #region CombatValues
    [Header ("Combat Values")]
    [Range(0.3f, 1)]
    public float BlockDirDeadzone = 0.6f;
    Vector2 BlockDir;
    public int ActiveBlockDir; //0=top 1=right 2=left
    public float MaxTargetDistance = 25;
    CharacterCombatControl CCC;
    #endregion

    #region CameraValues
    [Header("Camera Values")]
    public Transform CameraJoint;
    public Camera PlayerCam;
    public float MouseSensi = 1;
    public float MouseLockValue = 50;
    Vector2 CamInput;
    Vector3 DefaultCamLocal;
    #endregion

    #region UIValues
    [Header("UI Values")]
    public GameObject CombatOverlay;
    public bool InMenu;
    bool DidPause;
    #endregion

    #region LockonValues
    [Header ("Lockon Values")]
    public Transform LockonTarget;
    public bool LockedOn;
    #endregion

    #region InputDriverConnector
    [Header ("Input Driver Connector")]
    public bool ControllerInput;
    public bool IsAI;
    public Vector2 MoveInput, MouseInput;
    public bool LockonButton, SwapTargetButton;
    public bool JumpButton, SprintButton;
    public bool LightButton, HeavyButton, SpecialButton;
    public bool ReloadButton;
    public bool PauseButton, SelectButton;
    #endregion

    void Start()
    {
        if(PlayerRB == null)
        {
            PlayerRB = GetComponent<Rigidbody>();
        }

        CCC = GetComponent<CharacterCombatControl>();
        GC = FindObjectOfType<GameController>();

        ModelHolder.SetParent(null, true);

        Cursor.lockState = CursorLockMode.Locked;

        CamInput.y = 0;
        CamInput.x = transform.eulerAngles.y;

        DefaultCamLocal = PlayerCam.transform.localPosition;
    }

    void Update()
    {
        OnGround = CCC.OnGround;

        if(!CCC.Dead && !IsAI)
        {
            BasicPlayerMovement();

            if (!InMenu)
            {
                ButtonInputs();
                CameraControl();
            }

            if (LockedOn)
            {
                CombatControls();
            }
            else
            {
                CCC.Target = null;
                CCC.DoBash = false;
            }

            ModelAnimation();
            UIControl();
        }
        else if(!CCC.Dead && IsAI)
        {
            BasicPlayerMovement();

            if (!InMenu)
            {
                ButtonInputs();

                if(LockedOn && !CCC.LockMovement)
                {
                    transform.LookAt(new Vector3(LockonTarget.position.x, transform.position.y, LockonTarget.position.z));
                }
            }

            if (LockedOn)
            {
                CombatControls();
            }
            else
            {
                CCC.Target = null;
                CCC.DoBash = false;
            }

            ModelAnimation();

            CameraJoint.gameObject.SetActive(false);
        }
        else
        {
            LockonTarget = null;
            LockedOn = false;

            ModelHolder.position = transform.position;
            CameraJoint.parent = null;
        }
    }

    void BasicPlayerMovement()
    {
        if(!InMenu)
        {
            // /6 = regular time :: * 10 = deltatime
            PlayerInput.x = MoveInput.x / 6;
            PlayerInput.y = MoveInput.y / 6;
        }
        else
        {
            PlayerInput = Vector2.zero;
        }


        if(!CCC.Stunned && !CCC.Knockback && !CCC.LockMovement)
        {
            float SpeedLimiter = CCC.SpeedMulti;
            if(MoveInput.x != 0 && MoveInput.y != 0)
            {
                SpeedLimiter *= 0.70f;
            }

            PlayerRB.velocity = transform.forward * PlayerInput.y * CurrentSpeed * SpeedLimiter + transform.right * PlayerInput.x * CurrentSpeed * SpeedLimiter + transform.up * PlayerRB.velocity.y;

            if (Jump && OnGround && CCC.CurrentStamina >= jumpStaminaCost)
            {
                CCC.DropStamina(jumpStaminaCost);
                PlayerRB.AddForce(transform.up * 3, ForceMode.Impulse);
                Jump = false;
            }
            else
            {
                Jump = false;
            }
        }
        else if(CCC.LockMovement || (CCC.Stunned && !CCC.Knockback))
        {
            PlayerRB.velocity = transform.forward * 0 + transform.right * 0 + transform.up * PlayerRB.velocity.y;
        }

        if(OnGround)
        {
            CurrentSpeed = WalkSpeed;
        }
        else
        {
            CurrentSpeed = JumpSpeed;
        }

        VelMag = PlayerRB.velocity.magnitude;

        if (MoveInput == Vector2.zero && OnGround)
        {
            CCC.CapCol.material = FreezePhysics;
        }
        else if(MoveInput != Vector2.zero && WallCheck())
        {
            if(!OnGround)
            {
                PlayerRB.velocity = transform.up * -9.1f;
            }

            CCC.CapCol.material = FreezePhysics;
        }
        else
        {
            CCC.CapCol.material = DefaultPhysics;
        }
    }

    void CombatControls()
    {
        BlockDir.x = MouseInput.x;
        BlockDir.y = MouseInput.y;

        if(ControllerInput)
        {
            BlockDir.y *= -1;
        }

        if(BlockDir.y > BlockDirDeadzone)
        {
            ActiveBlockDir = 0;
        }
        else if(BlockDir.y < BlockDirDeadzone)
        {
            if(BlockDir.x > BlockDirDeadzone)
            {
                ActiveBlockDir = 1;
            }
            else if(BlockDir.x < -BlockDirDeadzone)
            {
                ActiveBlockDir = 2;
            }
        }

        if(!OnGround && PlayerInput.y > 0 && SpecialButton)
        {
            CCC.DoBash = true;
        }
        else if(OnGround)
        {
            CCC.DoBash = false;

            if(PlayerInput.y < 0)
            {
                CurrentSpeed = BackWalkSpeed;
            }
            else
            {
                CurrentSpeed = WalkSpeed;
            }
        }

        CCC.InputDir(ActiveBlockDir);
        CCC.Target = LockonTarget.GetComponent<CharacterCombatControl>();

        if(LockonTarget.GetComponent<CharacterCombatControl>().CurrentHealth <= 0)
        {
            LockonTarget = null;
            LockedOn = false;
        }
    }

    void CameraControl()
    {
        if(CameraJoint.parent != transform)
        {
            CameraJoint.parent = transform;
            CameraJoint.localPosition = new Vector3(0, 0.5f, 0);
        }

        CameraCollision();

        if(!LockedOn)
        {
            CamInput.x += MouseInput.x * 10 * MouseSensi * Time.deltaTime;
            CamInput.y += MouseInput.y * 10 * MouseSensi * Time.deltaTime;

            CamInput.y = Mathf.Clamp(CamInput.y, -MouseLockValue, MouseLockValue);

            transform.localEulerAngles = new Vector3(0, CamInput.x, 0);
            CameraJoint.localEulerAngles = new Vector3(CamInput.y, 0, 0);
        }
        else
        {
            if(!CCC.LockMovement)
            {
                transform.LookAt(new Vector3(LockonTarget.position.x, transform.position.y, LockonTarget.position.z));
                CamInput.x = transform.localEulerAngles.y;
            }

            CameraJoint.LookAt(LockonTarget.position);
            CamInput.y = CameraJoint.localEulerAngles.x;
        }
    }
    void CameraCollision()
    {
        bool WallCheck = Physics.Linecast(transform.position, PlayerCam.transform.position, out RaycastHit CollisionInfo, 9);

        if (WallCheck)
        {
            Debug.DrawLine(transform.position, CollisionInfo.point, Color.red);

            PlayerCam.transform.position = CollisionInfo.point;
        }
        else
        {
            PlayerCam.transform.localPosition = Vector3.MoveTowards(PlayerCam.transform.localPosition, DefaultCamLocal, Time.deltaTime * 5);
        }

    }
    void ButtonInputs()
    {
        if(LockonButton)
        {
            if(!LockedOn)
            {
                LockonTarget = GetLockonTarget();

                if (LockonTarget != null)
                {
                    LockedOn = true;
                }
                else
                {
                    CamInput.x = ModelHolder.eulerAngles.y;
                }
            }
            else
            {
                LockonTarget = null;
                LockedOn = false;
            }
        }
        if(SwapTargetButton && LockedOn)
        {
            LockonTarget = GetLockonTarget();

            if (LockonTarget != null)
            {
                LockedOn = true;
            }
        }

        if(JumpButton)
        {
            Jump = true;
        }

        if(SprintButton && !LockedOn && OnGround && CCC.CurrentStamina >= SprintStaminaCost)
        {
            CurrentSpeed = RunSpeed;
            CCC.DropStamina(SprintStaminaCost);
        }
        else if(OnGround)
        {
            CurrentSpeed = WalkSpeed;
        }

        if(LightButton)
        {
            CCC.DoAttack = true;
        }
        else
        {
            CCC.DoAttack = false;
        }

        if (HeavyButton)
        {
            CCC.DoHeavyAttack = true;
        }
        else
        {
            CCC.DoHeavyAttack = false;
        }

        if (SpecialButton)
        {
            CCC.DoSpecialAttack = true;
        }
        else
        {
            CCC.DoSpecialAttack = false;
        }

        if(ReloadButton)
        {
            CCC.DoReload = true;
        }

        if(PauseButton)
        {
            if(!DidPause)
            {
                GC.PlayersTryingPause += 1;
                DidPause = true;
            }
        }
        else
        {
            if(DidPause)
            {
                GC.PlayersTryingPause -= 1;
                DidPause = false;
            }

        }
    }

    void ModelAnimation()
    {
        ModelHolder.position = transform.position;

        if(!LockedOn && !CCC.Stunned)
        {
            ModelHolder.transform.LookAt(transform.position + new Vector3(PlayerRB.velocity.x, 0, PlayerRB.velocity.z));
        }
        else if(CCC.Stunned)
        {
            ModelHolder.transform.LookAt(transform.position - new Vector3(PlayerRB.velocity.x, 0, PlayerRB.velocity.z));
        }
        else
        {
            ModelHolder.rotation = transform.rotation;
        }
    }

    void UIControl()
    {
        if(LockedOn)
        {
            CombatOverlay.SetActive(true);
        }
        else
        {
            CombatOverlay.SetActive(false);
        }
    }

    Transform GetLockonTarget()
    {
        Transform ReturnValue = LockonTarget;

        Plane[] CamPlanes = GeometryUtility.CalculateFrustumPlanes(PlayerCam);

        GameObject[] AllTargets = GameObject.FindGameObjectsWithTag("LockOnTarget");
        List<Transform> VisibleTargets = new List<Transform>();

        foreach(GameObject g in AllTargets)
        {
            Collider GCol = g.GetComponent<Collider>();

            if(GeometryUtility.TestPlanesAABB(CamPlanes, GCol.bounds))
            {
                bool TargetViewBlocked = Physics.Linecast(transform.position, g.transform.position, out RaycastHit ViewCheck);

                if(TargetViewBlocked && ViewCheck.transform == g.transform)
                {
                    TargetViewBlocked = false;
                }

                if(!TargetViewBlocked && g != gameObject && (LockonTarget == null || g != LockonTarget.gameObject) && !g.GetComponent<CharacterCombatControl>().Dead)
                {
                    VisibleTargets.Add(g.transform);
                }
            }
        }

        float Lastdis = Mathf.Infinity;

        foreach(Transform t in VisibleTargets)
        {
            float Dis = Vector3.Distance(transform.position, t.position);

            if(Dis < Lastdis && Dis < MaxTargetDistance)
            {
                ReturnValue = t;
                Lastdis = Dis;
            }
        }

        return ReturnValue;
    }

    bool WallCheck()
    {
        Collider[] Collisions = Physics.OverlapSphere(transform.position, 0.6f, ~IgnoreCollisions);
        if(Collisions.Length > 0)
        {
            int PlayerCount = 0;
            for (int i = 0; i < Collisions.Length; i++)
            {
                if(Collisions[i].transform == transform)
                {
                    PlayerCount += 1;
                }
            }

            if(Collisions.Length > PlayerCount)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        else
        {
            return false;
        }
    }
}
