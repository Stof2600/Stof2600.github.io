﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class InputDriver : MonoBehaviour
{
    public List<PlayerController> Players = new List<PlayerController>();
    public int AIPlayers;
    public int InactivePlayers;
    public bool P1ForceKeyboard;

    private void Start()
    {
        string[] ControllerNames = Input.GetJoystickNames();

        for (int i = 0; i < ControllerNames.Length; i++)
        {
            print("NAME:" + ControllerNames[i] + " INDEX:" + i);
        }

        if(Players.Count == 0)
        {
            PlayerController[] NewPlayers = FindObjectsOfType<PlayerController>();

            int LastPlayerOrder = 0;

            while(LastPlayerOrder < NewPlayers.Length)
            {
                foreach(PlayerController p in NewPlayers)
                {
                    if(p.PlayerOrder == LastPlayerOrder)
                    {
                        Players.Add(p);
                        LastPlayerOrder += 1;
                    }
                }
            }
        }

        SyncObject SO = FindObjectOfType<SyncObject>();

        if (SO != null)
        {
            for (int i = 0; i < Players.Count; i++)
            {
                if(SO.ActivePlayers[i] == 0)
                {
                    Players[i].gameObject.SetActive(false);
                    InactivePlayers += 1;
                }
                else
                {
                    if (SO.ActivePlayers[i] == 1)
                    {
                        Players[i].IsAI = false;
                        Players[i].GetComponent<CharacterCombatControl>().Team = SO.PlayerTeams[i];
                    }
                    else if (SO.ActivePlayers[i] == 2)
                    {
                        Players[i].IsAI = true;
                        Players[i].GetComponent<CharacterCombatControl>().Team = SO.PlayerTeams[i];
                    }
                }

            }

            if(SO.P1UseKeyboard || ControllerNames.Length < 1)
            {
                P1ForceKeyboard = true;
            }
            else
            {
                P1ForceKeyboard = false;
            }
        }

        foreach(PlayerController p in Players)
        {
            if(p.IsAI)
            {
                AIPlayers += 1;
            }
        }

        int LastPlayer = 1;

        for (int i = 0; i < Players.Count; i++)
        {
            if(Players[i].gameObject.activeSelf)
            {
                if(!Players[i].IsAI)
                {
                    UISetup UIS = Players[i].GetComponentInChildren<UISetup>();

                    UIS.PlayerCount = Players.Count - AIPlayers - InactivePlayers;
                    UIS.MyPlayer = LastPlayer;
                    LastPlayer += 1;

                    UIS.ResetUI();
                }

                FindObjectOfType<GameController>().TeamScores[i] = 0;
            }
        }
    }

    private void Update()
    {
        if(P1ForceKeyboard)
        {
            KeyBoardInputReader();

            if (Players.Count > 1 && Players[1] != null)
            {
                StickOneInputReader(1);
            }
            if (Players.Count > 2 && Players[2] != null)
            {
                StickTwoInputReader(2);
            }
            if (Players.Count > 3 && Players[3] != null)
            {
                StickThreeInputReader(3);
            }
        }
        else
        {
            StickOneInputReader(0);

            if (Players.Count > 1 && Players[1] != null)
            {
                StickTwoInputReader(1);
            }
            if (Players.Count > 2 && Players[2] != null)
            {
                StickThreeInputReader(2);
            }
            if (Players.Count > 3 && Players[3] != null)
            {
                StickFourInputReader(3);
            }
        }

    }

    void KeyBoardInputReader()
    {
        Players[0].ControllerInput = false;

        Players[0].MoveInput.x = Input.GetAxis("KBHorizontal");
        Players[0].MoveInput.y = Input.GetAxis("KBVertical");
        Players[0].MouseInput.x = Input.GetAxis("KBMouse X");
        Players[0].MouseInput.y = Input.GetAxis("KBMouse Y");

        if (Input.GetButtonDown("KBLockonButton"))
        {
            Players[0].LockonButton = true;
        }
        else
        {
            Players[0].LockonButton = false;
        }

        if (Input.GetButtonDown("KBSwapTarget"))
        {
            Players[0].SwapTargetButton = true;
        }
        else
        {
            Players[0].SwapTargetButton = false;
        }

        if (Input.GetButtonDown("KBReloadAmmo"))
        {
            Players[0].ReloadButton = true;
        }
        else
        {
            Players[0].ReloadButton = false;
        }

        if (Input.GetButtonDown("KBJump"))
        {
            Players[0].JumpButton = true;
        }
        else
        {
            Players[0].JumpButton = false;
        }

        if (Input.GetButton("KBSprint"))
        {
            Players[0].SprintButton = true;
        }
        else
        {
            Players[0].SprintButton = false;
        }

        if (Input.GetButtonDown("KBLightAttack"))
        {
            Players[0].LightButton = true;
        }
        else
        {
            Players[0].LightButton = false;
        }
        if (Input.GetButtonDown("KBHeavyAttack"))
        {
            Players[0].HeavyButton = true;
        }
        else
        {
            Players[0].HeavyButton = false;
        }
        if (Input.GetButtonDown("KBSpecialAttack"))
        {
            Players[0].SpecialButton = true;
        }
        else
        {
            Players[0].SpecialButton = false;
        }

        if (Input.GetButton("KBPauseGame"))
        {
            Players[0].PauseButton = true;
        }
        else
        {
            Players[0].PauseButton = false;
        }
        if (Input.GetButtonDown("KBQuickSettings"))
        {
            Players[0].SelectButton = true;
        }
        else
        {
            Players[0].SelectButton = false;
        }
    }
    void StickOneInputReader(int StickIndex)
    {
        if(Players[StickIndex].IsAI)
        {
            return;
        }

        Players[StickIndex].ControllerInput = true;

        Players[StickIndex].MoveInput.x = Input.GetAxis("P1Horizontal");
        Players[StickIndex].MoveInput.y = Input.GetAxis("P1Vertical");
        Players[StickIndex].MouseInput.x = Input.GetAxis("P1Mouse X");
        Players[StickIndex].MouseInput.y = Input.GetAxis("P1Mouse Y");

        if (Input.GetButtonDown("P1LockonButton"))
        {
            Players[StickIndex].LockonButton = true;
        }
        else
        {
            Players[StickIndex].LockonButton = false;
        }

        if (Input.GetButtonDown("P1SwapTarget"))
        {
            Players[StickIndex].SwapTargetButton = true;
        }
        else
        {
            Players[StickIndex].SwapTargetButton = false;
        }

        if (Input.GetButtonDown("P1ReloadAmmo"))
        {
            Players[StickIndex].ReloadButton = true;
        }
        else
        {
            Players[StickIndex].ReloadButton = false;
        }

        if (Input.GetButtonDown("P1Jump"))
        {
            Players[StickIndex].JumpButton = true;
        }
        else
        {
            Players[StickIndex].JumpButton = false;
        }

        if (Input.GetButton("P1Sprint"))
        {
            Players[StickIndex].SprintButton = true;
        }
        else
        {
            Players[StickIndex].SprintButton = false;
        }

        if (Input.GetButtonDown("P1LightAttack"))
        {
            Players[StickIndex].LightButton = true;
        }
        else
        {
            Players[StickIndex].LightButton = false;
        }
        if (Input.GetButtonDown("P1HeavyAttack"))
        {
            Players[StickIndex].HeavyButton = true;
        }
        else
        {
            Players[StickIndex].HeavyButton = false;
        }
        if (Input.GetButtonDown("P1SpecialAttack"))
        {
            Players[StickIndex].SpecialButton = true;
        }
        else
        {
            Players[StickIndex].SpecialButton = false;
        }

        if (Input.GetButton("P1PauseGame"))
        {
            Players[StickIndex].PauseButton = true;
        }
        else
        {
            Players[StickIndex].PauseButton = false;
        }
        if (Input.GetButtonDown("P1QuickSettings"))
        {
            Players[StickIndex].SelectButton = true;
        }
        else
        {
            Players[StickIndex].SelectButton = false;
        }
    }
    void StickTwoInputReader(int StickIndex)
    {
        if (Players[StickIndex].IsAI)
        {
            return;
        }

        Players[StickIndex].ControllerInput = true;

        Players[StickIndex].MoveInput.x = Input.GetAxis("P2Horizontal");
        Players[StickIndex].MoveInput.y = Input.GetAxis("P2Vertical");
        Players[StickIndex].MouseInput.x = Input.GetAxis("P2Mouse X");
        Players[StickIndex].MouseInput.y = Input.GetAxis("P2Mouse Y");

        if (Input.GetButtonDown("P2LockonButton"))
        {
            Players[StickIndex].LockonButton = true;
        }
        else
        {
            Players[StickIndex].LockonButton = false;
        }

        if (Input.GetButtonDown("P2SwapTarget"))
        {
            Players[StickIndex].SwapTargetButton = true;
        }
        else
        {
            Players[StickIndex].SwapTargetButton = false;
        }

        if (Input.GetButtonDown("P2ReloadAmmo"))
        {
            Players[StickIndex].ReloadButton = true;
        }
        else
        {
            Players[StickIndex].ReloadButton = false;
        }

        if (Input.GetButtonDown("P2Jump"))
        {
            Players[StickIndex].JumpButton = true;
        }
        else
        {
            Players[StickIndex].JumpButton = false;
        }

        if (Input.GetButton("P2Sprint"))
        {
            Players[StickIndex].SprintButton = true;
        }
        else
        {
            Players[StickIndex].SprintButton = false;
        }

        if (Input.GetButtonDown("P2LightAttack"))
        {
            Players[StickIndex].LightButton = true;
        }
        else
        {
            Players[StickIndex].LightButton = false;
        }
        if (Input.GetButtonDown("P2HeavyAttack"))
        {
            Players[StickIndex].HeavyButton = true;
        }
        else
        {
            Players[StickIndex].HeavyButton = false;
        }
        if (Input.GetButtonDown("P2SpecialAttack"))
        {
            Players[StickIndex].SpecialButton = true;
        }
        else
        {
            Players[StickIndex].SpecialButton = false;
        }

        if (Input.GetButton("P2PauseGame"))
        {
            Players[StickIndex].PauseButton = true;
        }
        else
        {
            Players[StickIndex].PauseButton = false;
        }
        if (Input.GetButtonDown("P2QuickSettings"))
        {
            Players[StickIndex].SelectButton = true;
        }
        else
        {
            Players[StickIndex].SelectButton = false;
        }
    }
    void StickThreeInputReader(int StickIndex)
    {
        if (Players[StickIndex].IsAI)
        {
            return;
        }

        Players[StickIndex].ControllerInput = true;

        Players[StickIndex].MoveInput.x = Input.GetAxis("P3Horizontal");
        Players[StickIndex].MoveInput.y = Input.GetAxis("P3Vertical");
        Players[StickIndex].MouseInput.x = Input.GetAxis("P3Mouse X");
        Players[StickIndex].MouseInput.y = Input.GetAxis("P3Mouse Y");

        if (Input.GetButtonDown("P3LockonButton"))
        {
            Players[StickIndex].LockonButton = true;
        }
        else
        {
            Players[StickIndex].LockonButton = false;
        }

        if (Input.GetButtonDown("P3SwapTarget"))
        {
            Players[StickIndex].SwapTargetButton = true;
        }
        else
        {
            Players[StickIndex].SwapTargetButton = false;
        }

        if (Input.GetButtonDown("P3ReloadAmmo"))
        {
            Players[StickIndex].ReloadButton = true;
        }
        else
        {
            Players[StickIndex].ReloadButton = false;
        }

        if (Input.GetButtonDown("P3Jump"))
        {
            Players[StickIndex].JumpButton = true;
        }
        else
        {
            Players[StickIndex].JumpButton = false;
        }

        if (Input.GetButton("P3Sprint"))
        {
            Players[StickIndex].SprintButton = true;
        }
        else
        {
            Players[StickIndex].SprintButton = false;
        }

        if (Input.GetButtonDown("P3LightAttack"))
        {
            Players[StickIndex].LightButton = true;
        }
        else
        {
            Players[StickIndex].LightButton = false;
        }
        if (Input.GetButtonDown("P3HeavyAttack"))
        {
            Players[StickIndex].HeavyButton = true;
        }
        else
        {
            Players[StickIndex].HeavyButton = false;
        }
        if (Input.GetButtonDown("P3SpecialAttack"))
        {
            Players[StickIndex].SpecialButton = true;
        }
        else
        {
            Players[StickIndex].SpecialButton = false;
        }

        if (Input.GetButton("P3PauseGame"))
        {
            Players[StickIndex].PauseButton = true;
        }
        else
        {
            Players[StickIndex].PauseButton = false;
        }
        if (Input.GetButtonDown("P3QuickSettings"))
        {
            Players[StickIndex].SelectButton = true;
        }
        else
        {
            Players[StickIndex].SelectButton = false;
        }
    }
    void StickFourInputReader(int StickIndex)
    {
        if (Players[StickIndex].IsAI)
        {
            return;
        }

        Players[StickIndex].ControllerInput = true;

        Players[StickIndex].MoveInput.x = Input.GetAxis("P4Horizontal");
        Players[StickIndex].MoveInput.y = Input.GetAxis("P4Vertical");
        Players[StickIndex].MouseInput.x = Input.GetAxis("P4Mouse X");
        Players[StickIndex].MouseInput.y = Input.GetAxis("P4Mouse Y");

        if (Input.GetButtonDown("P4LockonButton"))
        {
            Players[StickIndex].LockonButton = true;
        }
        else
        {
            Players[StickIndex].LockonButton = false;
        }

        if (Input.GetButtonDown("P4SwapTarget"))
        {
            Players[StickIndex].SwapTargetButton = true;
        }
        else
        {
            Players[StickIndex].SwapTargetButton = false;
        }

        if (Input.GetButtonDown("P4ReloadAmmo"))
        {
            Players[StickIndex].ReloadButton = true;
        }
        else
        {
            Players[StickIndex].ReloadButton = false;
        }

        if (Input.GetButtonDown("P4Jump"))
        {
            Players[StickIndex].JumpButton = true;
        }
        else
        {
            Players[StickIndex].JumpButton = false;
        }

        if (Input.GetButton("P4Sprint"))
        {
            Players[StickIndex].SprintButton = true;
        }
        else
        {
            Players[StickIndex].SprintButton = false;
        }

        if (Input.GetButtonDown("P4LightAttack"))
        {
            Players[StickIndex].LightButton = true;
        }
        else
        {
            Players[StickIndex].LightButton = false;
        }
        if (Input.GetButtonDown("P4HeavyAttack"))
        {
            Players[StickIndex].HeavyButton = true;
        }
        else
        {
            Players[StickIndex].HeavyButton = false;
        }
        if (Input.GetButtonDown("P4SpecialAttack"))
        {
            Players[StickIndex].SpecialButton = true;
        }
        else
        {
            Players[StickIndex].SpecialButton = false;
        }

        if (Input.GetButton("P4PauseGame"))
        {
            Players[StickIndex].PauseButton = true;
        }
        else
        {
            Players[StickIndex].PauseButton = false;
        }
        if (Input.GetButtonDown("P4QuickSettings"))
        {
            Players[StickIndex].SelectButton = true;
        }
        else
        {
            Players[StickIndex].SelectButton = false;
        }
    }
}
