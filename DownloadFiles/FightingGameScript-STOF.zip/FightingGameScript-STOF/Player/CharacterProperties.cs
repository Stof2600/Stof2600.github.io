﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CharacterProperties : MonoBehaviour
{
    public enum WeightClass
    {
        Heavy,
        Medium,
        Light
    }

    public WeightClass CharacterWeight;

    float CharacterHeight = 2;

    public int CharacterID;
    public List<GameObject> CharacterModels = new List<GameObject>();

    PlayerController PC;
    CharacterCombatControl CCC;
    CharacterAttackList CAL;

    Animator Anim;

    CapsuleCollider CapCol;

    // Start is called before the first frame update
    void Start()
    {
        PC = GetComponent<PlayerController>();
        CCC = GetComponent<CharacterCombatControl>();
        CAL = GetComponent<CharacterAttackList>();

        CapCol = GetComponent<CapsuleCollider>();

        Anim = CharacterModels[CharacterID].GetComponent<Animator>();

        SetStats();
        SetCollision();
    }

    private void Update()
    {
        AnimationController();
    }

    void AnimationController()
    {
        if(CCC.Dead)
        {
            Anim.SetLayerWeight(1, 0);
            Anim.SetBool("LockOnActive", false);

            Anim.SetFloat("LockOnTime", 0);
            Anim.SetBool("Dead", true);
            return;
        }
        else
        {
            Anim.SetBool("Dead", false);
        }

        if(PC.LockedOn || CCC.InAttack || CCC.DidBlock || CCC.Stunned)
        {
            Anim.SetLayerWeight(1, 1);

            Anim.SetBool("LockOnActive", true);
            Anim.SetInteger("BlockDir", (int)CCC.MyAttackDir);

            Anim.SetFloat("LockOnTime", 1);

            Anim.SetFloat("WalkY", PC.MoveInput.y);
            Anim.SetFloat("WalkX", PC.MoveInput.x);

            Anim.SetInteger("AmmoCount", CCC.CurrentAmmo);

            if (CCC.DidBlock)
            {
                Anim.SetBool("DidBlock", true);
            }
            else
            {
                Anim.SetBool("DidBlock", false);
            }

            Anim.SetBool("Stunned", CCC.Stunned);
            Anim.SetBool("Knockback", CCC.Knockback);

            if(CCC.DisplayDamage)
            {
                Anim.SetBool("Damage", true);
                CCC.DisplayDamage = false;
            }
            else
            {
                Anim.SetBool("Damage", false);
            }

            if(CCC.DoBash)
            {
                Anim.SetBool("InBash", true);
            }
            else if(Anim.GetBool("InBash") && CCC.OnGround)
            {
                Anim.SetBool("InBash", false);
            }

            if (CCC.CurrentAttack.Blocked && CCC.CurrentAttack.DidCollisionCheck)
            {
                Anim.SetFloat("AttackSpeed", -2);
            }
            else if(!CCC.CurrentAttack.DidCollisionCheck && CCC.CurrentAttack.Timer > 0)
            {
                Anim.SetFloat("AttackSpeed", 1);
            }

            if(CCC.LockMovement)
            {
                Anim.SetFloat("WalkY", 0);
                Anim.SetFloat("WalkX", 0);
            }
        }
        else
        {
            Anim.SetLayerWeight(1, 0);
            Anim.SetBool("LockOnActive", false);

            Anim.SetFloat("LockOnTime", 0);
        }

        if (CCC.InAttack && CCC.CurrentAttack.Timer <= 0)
        {
            Anim.Play(CCC.CurrentAttack.AttackName);
        }

        if(PC.OnGround && PC.MoveInput.magnitude > 0.1f)
        {
            Anim.SetBool("Walking", true);
            Anim.SetFloat("WalkSpeed", PC.VelMag);
        }
        else
        {
            Anim.SetBool("Walking", false);
        }

        Anim.SetBool("OnGround", PC.OnGround);
    }

    void SetStats()
    {
        switch(CharacterWeight)
        {
            case WeightClass.Heavy:
                CharacterHeight = 2;
                CCC.DefaultDmgMulti = 1.25f;
                CCC.SpeedMulti = 0.75f;
                CCC.BashForceMulti = 1.25f;
                CCC.MaxHealth = 125;
                CCC.MaxStamina = 50;
                break;
            case WeightClass.Medium:
                CharacterHeight = 1.8f;
                CCC.DefaultDmgMulti = 1f;
                CCC.SpeedMulti = 1f;
                CCC.BashForceMulti = 1f;
                CCC.MaxHealth = 100;
                CCC.MaxStamina = 75;
                break;
            case WeightClass.Light:
                CharacterHeight = 1.6f;
                CCC.DefaultDmgMulti = 0.75f;
                CCC.SpeedMulti = 1.25f;
                CCC.BashForceMulti = 0.75f;
                CCC.MaxHealth = 75;
                CCC.MaxStamina = 100;
                break;
        }

        CAL.CharacterID = CharacterID;
        CCC.CanRespawn = false;
        CCC.ForceRespawn = true;
    }

    void SetCollision()
    {
        CapCol.height = CharacterHeight;
    }
}
