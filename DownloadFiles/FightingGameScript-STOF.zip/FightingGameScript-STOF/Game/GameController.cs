﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine.UI;
using UnityEngine;

public class GameController : MonoBehaviour
{
    public bool TurfWarGameMode, DeathMatchGameMode;

    #region TurfWarValues
    [Header ("TURF WAR VALUES")]
    public float TWWinScore = 100;
    public int TWWinningTeam = -1;
    public float CurrentScore;
    public float VisualScore, LineMoveSpeed = 0.05f;
    public float lineMaxMove;
    public Transform LineHolder;
    public Transform[] AISpawns = new Transform[2];
    public GameObject WeakAI;

    [Range(0, 125)]
    public int AILimitPerTeam = 50;
    public int Team0AIs, Team1AIs;
    #endregion

    #region DeathMatchValues
    [Header ("DEATH MATCH VALUES")]
    public int DMWinScore = 100;
    public int[] TeamScores = { -1, -1, -1, -1};
    public int DMWinningTeam = -1;
    #endregion

    #region UIStuff
    [Header("UI")]
    public GameObject WinBlock;
    public Text WinTeamText;
    public GameObject PauseMenu;
    public GameObject PauseTimerBlock;
    public RectTransform PauseTimerFill;
    public bool Paused;
    public float PauseTimer;
    public int PlayersTryingPause;
    bool LockedPlayers, HitPause;
    #endregion

    #region EffectZoneSpawning
    [Header("EffectZone Spawning")]
    public bool DoZoneSpawns;
    public GameObject ZonePrefab;
    public Vector3[] ZoneSpawnPositions;
    public float ZoneSpawnTime = 15;
    public bool[] ZoneTaken;
    float ZoneTimer;
    #endregion

    float EndGameTimer = 20;
    int WT;

    // Start is called before the first frame update
    void Start()
    {
        Application.targetFrameRate = 60;
        EndGameTimer = 10;

        CurrentScore = 0;

        WinBlock.SetActive(false);

        if (!TurfWarGameMode)
        {
            LineHolder.gameObject.SetActive(false);

            
        }
        else
        {
            StartSpawnAIs();
        }

        ZoneTimer = ZoneSpawnTime;
        ZoneTaken = new bool[ZoneSpawnPositions.Length];
    }

    // Update is called once per frame
    void Update()
    {
        Application.targetFrameRate = 60;

        if(TWWinningTeam < 0 && DMWinningTeam < 0)
        {
            if (TurfWarGameMode)
            {
                TurfWarGame();
            }
            else
            {
                DeathMatchGame();
            }

            if(!Paused && DoZoneSpawns && ZoneSpawnPositions.Length > 0)
            {
                ZoneTimer -= Time.deltaTime;
                if(ZoneTimer <= 0)
                {
                    SpawnZone();
                }
            }
        }
        else
        {
            GameWin();
        }

        if(Paused)
        {
            PauseMenu.SetActive(true);
            Cursor.visible = true;
            Cursor.lockState = CursorLockMode.None;
            
            if(!LockedPlayers)
            {
                foreach (Rigidbody rb in FindObjectsOfType<Rigidbody>())
                {
                    rb.isKinematic = true;
                }
                LockedPlayers = true;
            }
        }
        else
        {
            PauseMenu.SetActive(false);

            if(LockedPlayers)
            {
                foreach (Rigidbody rb in FindObjectsOfType<Rigidbody>())
                {
                    rb.isKinematic = false;
                }

                Cursor.visible = false;
                Cursor.lockState = CursorLockMode.Locked;

                LockedPlayers = false;
            }
        }

        if(PlayersTryingPause > 0)
        {
            if(Paused && !HitPause)
            {
                Paused = false;
            }

            PauseTimer += Time.deltaTime;
            

            PauseTimerFill.localScale = new Vector3(PauseTimer / 1, 1, 1);

            if(PauseTimer >= 1)
            {
                Paused = true;
                HitPause = true;
                PauseTimerBlock.SetActive(false);
            }
            else
            {
                PauseTimerBlock.SetActive(true);
            }
        }
        else
        {
            PauseTimerBlock.SetActive(false);
            PauseTimer = 0;
            HitPause = false;
        }
    }

    void TurfWarGame()
    {
        if(CurrentScore > TWWinScore)
        {
            TWWinningTeam = 0;
            WT = TWWinningTeam;
        }
        else if(CurrentScore < -TWWinScore)
        {
            TWWinningTeam = 1;
            WT = TWWinningTeam;
        }

        if(VisualScore != CurrentScore)
        {
            VisualScore = Mathf.MoveTowards(VisualScore, CurrentScore, LineMoveSpeed);
        }

        float LineHolderPos = lineMaxMove * (VisualScore / TWWinScore);
        LineHolder.localPosition = new Vector3(LineHolder.localPosition.x, LineHolder.localPosition.y, LineHolderPos);

        if(Team0AIs < AILimitPerTeam)
        {
            SpawnWeakAI(0);
        }
        if (Team1AIs < AILimitPerTeam)
        {
            SpawnWeakAI(1);
        }
    }

    void DeathMatchGame()
    {
        for (int i = 0; i < TeamScores.Length; i++)
        {
            if(TeamScores[i] == DMWinScore)
            {
                DMWinningTeam = i;
                WT = DMWinningTeam;
            }
        }
    }

    void SpawnZone()
    {
        int R = Random.Range(0, ZoneSpawnPositions.Length);
        if(!ZoneTaken[R])
        {
            Vector3 Pos = ZoneSpawnPositions[R];

            GameObject NewZone = Instantiate(ZonePrefab, Pos, transform.rotation, transform);
            NewZone.GetComponent<EffectZone>().ZoneTakenSlot = R;
            ZoneTaken[R] = true;
        }


        ZoneTimer = ZoneSpawnTime;
    }

    void GameWin()
    {
        EndGameTimer -= Time.deltaTime;
        WinBlock.SetActive(true);
        WinTeamText.text = "TEAM " + WT + 1;

        switch(WT)
        {
            case 0:
                WinTeamText.color = new Color(0, 0, 1);
                break;
            case 1:
                WinTeamText.color = new Color(1, 0, 0);
                break;
            case 2:
                WinTeamText.color = new Color(0, 1, 0);
                break;
            case 3:
                WinTeamText.color = new Color(1, 1, 0);
                break;
        }

        if(EndGameTimer <= 0)
        {
            FindObjectOfType<SyncObject>().LoadScene(1);
        }
    }

    void StartSpawnAIs()
    {
        while(Team0AIs < AILimitPerTeam)
        {
            SpawnWeakAI(0);
        }
        while (Team1AIs < AILimitPerTeam)
        {
            SpawnWeakAI(1);
        }
    }
    void SpawnWeakAI(int Team)
    {
        if((Team == 0 && Team0AIs >= AILimitPerTeam) || (Team == 1 && Team1AIs >= AILimitPerTeam))
        {
            return;
        }

        GameObject NewAI = Instantiate(WeakAI, AISpawns[Team].position, AISpawns[Team].rotation);

        NewAI.GetComponent<SimpleAI>().MyTeam = Team;

        if(Team == 0)
        {
            Team0AIs += 1;
        }
        else if(Team == 1)
        {
            Team1AIs += 1;
        }
    }

    public void AddScore(int Amount, int Team)
    {
        //score math is flipped because of how death works

        if(TurfWarGameMode)
        {
            if(Team == 0)
            {
                CurrentScore += Amount;
            }
            else if(Team == 1)
            {
                CurrentScore -= Amount;
            }
        }
        else if(DeathMatchGameMode)
        {
            if(TeamScores[Team] < 0)
            {
                TeamScores[Team] += 1;
            }

            TeamScores[Team] += 1;
        }
    }

    public void RemoveActiveAI(int Team)
    {
        switch(Team)
        {
            case 0:
                Team0AIs -= 1;
                break;
            case 1:
                Team1AIs -= 1;
                break;
        }
    }

    public void ReturnToGame()
    {
        Paused = false;
    }
    public void QuitToMain()
    {
        FindObjectOfType<SyncObject>().LoadScene(1);
    }

    private void OnDrawGizmosSelected()
    {
        Gizmos.color = Color.red;

        foreach (Vector3 point in ZoneSpawnPositions)
        {
            Gizmos.DrawWireSphere(point, 5);
        }
    }
}
