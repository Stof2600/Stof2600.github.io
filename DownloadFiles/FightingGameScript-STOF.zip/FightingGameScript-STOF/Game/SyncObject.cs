﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine.SceneManagement;
using UnityEngine;

public class SyncObject : MonoBehaviour
{
    int CurrentScene;
    public int[] ActivePlayers = { 1, 0, 0, 0};
    public int ActiveAI;

    public bool P1UseKeyboard;
    public int[] PlayerTeams = { 0, 1, 2, 3 };
    bool HitNext, DidFirstLoad;
    
    void Start()
    {
        P1UseKeyboard = false;
        DontDestroyOnLoad(gameObject);

        HitNext = false;
        DidFirstLoad = false;
    }

    private void Update()
    {
        if(!HitNext && !DidFirstLoad && Input.GetKeyDown(KeyCode.Return))
        {
            HitNext = true;
        }

        if (HitNext && !DidFirstLoad)
        {
            DidFirstLoad = true;
            LoadScene(1);
        }
    }

    public void LoadScene(int SceneIndex)
    {
        CurrentScene = SceneIndex;
        SceneManager.LoadScene(SceneIndex);
    }
}
