﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RespawnPoint : MonoBehaviour
{
    public int Team;
    public bool CanUse;

    public List<Transform> PlayersConnected = new List<Transform>(); 

    private void Start()
    {
        CanUse = true;
    }

    private void FixedUpdate()
    {
        if(PlayersConnected.Count > 0)
        {
            PlayersConnected[0].GetComponent<CharacterCombatControl>().CanRespawn = true;

            if (!CanUse)
            {
                PlayersConnected.RemoveRange(0, PlayersConnected.Count - 1);
            }
            if(PlayersConnected.Count > 1)
            {
                PlayersConnected.RemoveRange(1, PlayersConnected.Count - 1);
            }
        }
    }

    private void OnTriggerStay(Collider other)
    {
        if(other.GetComponent<CharacterCombatControl>() && other.GetComponent<CharacterCombatControl>().Team != Team)
        {
            CanUse = false;
        }
    }

    private void OnTriggerExit(Collider other)
    {
        CanUse = true;
    }
}
