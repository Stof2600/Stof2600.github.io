﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BloodSplatter : MonoBehaviour
{
    public GameObject BloodSplatterPrefab;
    public float DetectionRadiusAdd = 0.5f;
    public float GrowAmount = 0.25f;
    public float MaxScale = 10;
    bool DidBypass;
    public float EndScale = 1, StartScale = 1, VisualScale = 1;
    float Step;

    // Start is called before the first frame update
    void Start()
    {
        gameObject.isStatic = true;
        StartCoroutine(WaitForCombine());

        if (EndScale > MaxScale)
        {
            EndScale = MaxScale;
        }

        VisualScale = StartScale;

        if (VisualScale < EndScale)
        {
            StartCoroutine(ChangeScale());
        }
    }

    IEnumerator WaitForCombine()
    {
        yield return new WaitForSeconds(0.5f);

        CheckForCombine();
    }

    public void CheckForCombine()
    {
        float DetectionRadius = DetectionRadiusAdd + transform.localScale.x / 2;

        List<Transform> CloseBlood = new List<Transform>();

        int Count = 0;

        foreach (Transform blood in transform.parent)
        {
            if (Vector3.Distance(transform.position, blood.position) <= DetectionRadius && blood.gameObject.isStatic && blood.gameObject != gameObject)
            {
                Count += 1;
                CloseBlood.Add(blood);

                if(blood.localScale.x > transform.localScale.x)
                {
                    blood.GetComponent<BloodSplatter>().CheckForCombine();
                    DidBypass = true;
                    return;
                }
            }
        }

        if(Count > 0 && !DidBypass)
        {
            Transform NewParent = transform.parent;
            GameObject NewBlood = Instantiate(BloodSplatterPrefab, transform.position, transform.rotation, NewParent);

            BloodSplatter NewBloodFX = NewBlood.GetComponent<BloodSplatter>();
            NewBloodFX.EndScale = transform.localScale.x;
            NewBloodFX.StartScale = transform.localScale.x;

            if (transform.localScale.x < MaxScale)
            {
                NewBloodFX.EndScale += GrowAmount;
            }

            for (int i = 0; i < Count; i++)
            {
                Destroy(CloseBlood[i].gameObject);
            }

            Destroy(gameObject);
        }
        else
        {
            return;
        }
    }

    IEnumerator ChangeScale()
    {
        yield return new WaitForSeconds(0.1f);

        Step += 0.05f;
        VisualScale = Mathf.Lerp(StartScale, EndScale, Step);

        transform.localScale = new Vector3(VisualScale, VisualScale, VisualScale);

        if (VisualScale != EndScale)
        {
            StartCoroutine(ChangeScale());
        }
        else
        {
            CheckForCombine();
        }
    }
}
