﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BloodEffect : MonoBehaviour
{

    //www.reddit.com/r/Unity3D/comments/13qdh49/gates_of_damnations_new_blood_splatter_system/
    //reference

    public ParticleSystem PSystem;
    public List<ParticleCollisionEvent> ColEvents = new List<ParticleCollisionEvent>();

    public GameObject BloodSplatter;
    Transform BloodParent;

    public LayerMask BloodLayer;

    Quaternion NewRotation;

    void Start()
    {
        PSystem = GetComponent<ParticleSystem>();
        BloodParent = FindObjectOfType<BloodHolder>().transform;
    }

    private void OnParticleCollision(GameObject other)
    {
        int p = PSystem.GetCollisionEvents(other, ColEvents);

        int i = 0;

        while(i < p)
        {
            Quaternion Rot = Quaternion.LookRotation(ColEvents[i].normal);
            Vector3 Pos = ColEvents[i].intersection + ColEvents[i].normal * 0.05f;
            Instantiate(BloodSplatter, Pos, Rot, BloodParent);
            i++;
        }
    }
}
