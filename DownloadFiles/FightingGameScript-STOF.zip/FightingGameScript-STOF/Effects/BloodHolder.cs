﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BloodHolder : MonoBehaviour
{
    List<Transform> Children = new List<Transform>();

    private void Update()
    {
        if(transform.childCount > 500)
        {
            print("DidDelete" + transform.childCount.ToString());
            Destroy(transform.GetChild(0).gameObject);
        }
    }
}
