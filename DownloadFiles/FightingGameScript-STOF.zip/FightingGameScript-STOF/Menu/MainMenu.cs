﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine.SceneManagement;
using UnityEngine.UI;
using UnityEngine;

public class MainMenu : MonoBehaviour
{
    SyncObject SO;

    public bool ControllerMenuOpen, MapMenuOpen;
    public GameObject ControllerMenu, MapMenu;
    public ControllerInputUI[] ControllerUIs = new ControllerInputUI[4];

    int TWSelected;
    public int[] TWSceneNumbers;
    public Sprite[] TWMapImages;
    public Image[] TWMapScroll;

    public Text AICountDisplay;

    // Start is called before the first frame update
    void Start()
    {
        SO = FindObjectOfType<SyncObject>();
        if(SO == null)
        {
            SceneManager.LoadScene(0);
        }

        ControllerMenuOpen = false;
    }

    private void Update()
    {
        if(ControllerMenuOpen)
        {
            ControllerMenu.SetActive(true);
            UpdateControllerMenu();
        }
        else
        {
            ControllerMenu.SetActive(false);
        }

        if(MapMenuOpen)
        {
            MapMenu.SetActive(true);
            UpdateMapMenu();
        }
        else
        {
            MapMenu.SetActive(false);
        }
    }

    void UpdateControllerMenu()
    {
        int StartingIndex = 0;

        if(ControllerUIs[0].AllowKeyboard)
        {
            if(!ControllerUIs[0].Active)
            {
                ControllerUIs[0].Active = true;
                ControllerUIs[0].UsingKeyboard = true;
                ControllerUIs[0].StatusImage.color = Color.green;

                SO.ActivePlayers[0] = 1;

                ChangeAICount(0);
            }

            if(ControllerUIs[0].UsingKeyboard)
            {
                StartingIndex = 1;
                ControllerUIs[0].StatusText.text = "KEYBOARD\nA : SWAP";

                if(Input.GetKeyDown(KeyCode.A) || Input.GetKeyDown(KeyCode.D))
                {
                    ControllerUIs[0].UsingKeyboard = false;
                }
            }
            else
            {
                ControllerUIs[0].StatusText.text = "CONTROLLER\nA : SWAP";

                if (Input.GetKeyDown(KeyCode.A) || Input.GetKeyDown(KeyCode.D) || Input.GetButton("P1Jump"))
                {
                    ControllerUIs[0].UsingKeyboard = true;
                }
            }

            ControllerUIs[0].SelectedTeam = 0;
            ControllerUIs[0].PlayerText.color = Color.blue;
        }

        for (int i = StartingIndex; i < ControllerUIs.Length; i++)
        {
            string ControllerButton = "joystick " + (1 + i) + " button 0";
            string TeamButton = "joystick " + (1 + i) + " button 7";

            if (ControllerUIs[0].UsingKeyboard)
            {
                ControllerButton = "joystick " + (1  * i) + " button 0";
                TeamButton = "joystick " + (1 * i) + " button 7";
            }

            if(!ControllerUIs[i].AllowKeyboard)
            {
                if (ControllerUIs[i].Active)
                {
                    ControllerUIs[i].StatusImage.color = Color.green;
                    ControllerUIs[i].StatusText.text = "CONTROLLER\nA : QUIT";

                    if (Input.GetKeyDown(ControllerButton))
                    {
                        ControllerUIs[i].Active = false;
                        SO.ActivePlayers[i] = 0;
                        ChangeAICount(0);
                    }
                    if(Input.GetKeyDown(TeamButton))
                    {
                        ControllerUIs[i].SelectedTeam += 1;

                        if(ControllerUIs[i].SelectedTeam > 3)
                        {
                            ControllerUIs[i].SelectedTeam = 0;
                        }
                    }
                }
                else
                {
                    ControllerUIs[i].StatusImage.color = Color.grey;

                    ControllerUIs[i].StatusText.text = "CONTROLLER\nA : JOIN";

                    if (Input.GetKeyDown(ControllerButton))
                    {
                        ControllerUIs[i].Active = true;
                        SO.ActivePlayers[i] = 1;
                        ChangeAICount(0);
                    }
                }
            }

            switch(ControllerUIs[i].SelectedTeam)
            {
                case 0:
                    ControllerUIs[i].PlayerText.color = Color.blue;
                    break;
                case 1:
                    ControllerUIs[i].PlayerText.color = Color.red;
                    break;
                case 2:
                    ControllerUIs[i].PlayerText.color = Color.green;
                    break;
                case 3:
                    ControllerUIs[i].PlayerText.color = Color.yellow;
                    break;
            }
        }
    }

    void UpdateMapMenu()
    {
        TWMapScroll[1].sprite = TWMapImages[TWSelected];

        if (TWSelected == 0)
        {
            TWMapScroll[0].sprite = TWMapImages[TWMapImages.Length - 1];
        }
        else
        {
            TWMapScroll[0].sprite = TWMapImages[TWSelected - 1];
        }
        if(TWSelected >= TWMapImages.Length - 1)
        {
            TWMapScroll[2].sprite = TWMapImages[0];
        }
        else
        {
            TWMapScroll[2].sprite = TWMapImages[TWSelected + 1];
        }
    }

    public void OpenControllerMenu()
    {
        ControllerMenuOpen = true;
    }
    public void OpenMapMenu()
    {
        MapMenuOpen = true;
        ControllerMenuOpen = false;
    }

    public void ChangeTWSelected(int AddValue)
    {
        TWSelected += AddValue;

        if(TWSelected < 0)
        {
            TWSelected = TWMapImages.Length - 1;
        }
        else if(TWSelected >= TWMapImages.Length)
        {
            TWSelected = 0;
        }
    }
    public void LoadTWScene()
    {
        CallLoadScene(TWSceneNumbers[TWSelected]);
    }

    public void CallLoadScene(int SceneIndex)
    {
        int TeamCheck = 0;
        bool PassedCheck = false;

        if(ControllerUIs[1].Active || ControllerUIs[2].Active || ControllerUIs[3].Active)
        {
            for (int i = 0; i < ControllerUIs.Length; i++)
            {
                SO.PlayerTeams[i] = ControllerUIs[i].SelectedTeam;

                if (ControllerUIs[i].Active && ControllerUIs[i].SelectedTeam != TeamCheck)
                {
                    PassedCheck = true;
                }
            }
        }
        else
        {
            PassedCheck = true;
        }

        if(SO.ActiveAI > 0)
        {
            PassedCheck = true;
        }

        if(!PassedCheck)
        {
            print("FAILED TEAM CHECK");
            return;
        }

        if(ControllerUIs[0].AllowKeyboard && ControllerUIs[0].UsingKeyboard)
        {
            SO.P1UseKeyboard = true;
        }

        for (int i = 0; i < ControllerUIs.Length; i++)
        {
            if(SO.ActiveAI > 0 && SO.ActivePlayers[i] == 0)
            {
                SO.ActivePlayers[i] = 2;
                SO.ActiveAI -= 1;
            }
        }

        SO.LoadScene(SceneIndex);
    }

    public void ChangeAICount(int Amount)
    {
        SO.ActiveAI += Amount;

        int ActivePlayers = 0;

        foreach(ControllerInputUI c in ControllerUIs)
        {
            if(c.Active)
            {
                ActivePlayers += 1;
            }
        }

        if(SO.ActiveAI < 0)
        {
            SO.ActiveAI = 0;
        }
        else if(SO.ActiveAI > 4 - ActivePlayers)
        {
            SO.ActiveAI = 4 - ActivePlayers;
        }

        if(ControllerUIs[0].Active && !ControllerUIs[1].Active && !ControllerUIs[2].Active && !ControllerUIs[3].Active && SO.ActiveAI < 1)
        {
            SO.ActiveAI = 1;
        }

        AICountDisplay.text = "AI PLAYERS\n" + SO.ActiveAI;
    }


    public void CloseGame()
    {
        print("CLOSED GAME");
        Application.Quit();
    }
}

[System.Serializable]
public class ControllerInputUI
{
    public bool Active;
    public bool AllowKeyboard, UsingKeyboard;
    public Text PlayerText, StatusText;
    public Image StatusImage;
    public int SelectedTeam;
}

