using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ProjectileMove : MonoBehaviour
{
    public Vector3 MoveDir;
    public float MoveSpeed;
    public bool PlayerProjectile;

    public GameObject BreakEffect;

    private void Start()
    {
        StartCoroutine(DespawnTimer());
    }

    // Update is called once per frame
    void Update()
    {
        transform.position += MoveDir * MoveSpeed * Time.deltaTime;
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        HealthScript HS = collision.GetComponent<HealthScript>();

        if(PlayerProjectile && !collision.GetComponent<PlayerMovement>() && HS != null)
        {
            if (BreakEffect != null)
            {
                Instantiate(BreakEffect, transform.position, transform.rotation);
            }

            HS.TakeDamage();
            Destroy(gameObject);
        }
        else if(!PlayerProjectile && collision.GetComponent<PlayerMovement>() && HS != null)
        {
            if (BreakEffect != null)
            {
                Instantiate(BreakEffect, transform.position, transform.rotation);
            }

            HS.TakeDamage();
            Destroy(gameObject);
        }
    }

    IEnumerator DespawnTimer()
    {
        yield return new WaitForSeconds(2);

        Destroy(gameObject);
    }
}
