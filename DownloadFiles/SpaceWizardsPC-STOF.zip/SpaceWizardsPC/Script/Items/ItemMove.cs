using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ItemMove : MonoBehaviour
{
    public enum ItemType
    {
        LifeUp,
        SlowTime,
        FireRateChange
        
    }

    public Vector3 MoveDir;
    public bool Activate;

    public ItemType Type;

    // Update is called once per frame
    void FixedUpdate()
    {
        if(FindObjectOfType<GameController>().Score < 2000 && Type != ItemType.LifeUp)
        {
            Destroy(gameObject);
        }

        transform.position += MoveDir;

        if(Activate)
        {
            switch (Type)
            {
                case ItemType.LifeUp:
                    FindObjectOfType<GameController>().PlayerLives += 1;
                    Destroy(gameObject);
                    break;
                case ItemType.SlowTime:
                    FindObjectOfType<GameController>().SlowedTime = true;
                    Destroy(gameObject);
                    break;
                case ItemType.FireRateChange:
                    FindObjectOfType<GameController>().PlayerFireRateMulti += 0.05f;
                    Destroy(gameObject);
                    break;
            }
        }
    }
}
