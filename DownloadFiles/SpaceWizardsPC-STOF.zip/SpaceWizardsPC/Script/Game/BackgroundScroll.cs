using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BackgroundScroll : MonoBehaviour
{
    public Transform Seg1, Seg2;
    public Transform ShownSeg;
    int CurrentShown;

    public float ScrollSpeed = 5f;
    EnemySpawning ES;

    // Start is called before the first frame update
    void Start()
    {
        ES = FindObjectOfType<EnemySpawning>();

        ShownSeg = Seg1;
        CurrentShown = 1;
    }

    // Update is called once per frame
    void FixedUpdate()
    {
        float ScrollChanged = (-ScrollSpeed / 100) - (ES.SpawnTimeModifier / 100);
        Seg1.localPosition += new Vector3(0, ScrollChanged, 0);
        Seg2.localPosition += new Vector3(0, ScrollChanged, 0);

        if (ShownSeg.localPosition.y < -13)
        {
            SwapSeg();
        }
    }

    void SwapSeg()
    {
        if(CurrentShown == 1)
        {
            ShownSeg = Seg2;
            Seg1.localPosition = Seg2.localPosition + new Vector3(0, 16, 0);
            CurrentShown = 2;
        }
        else
        {
            ShownSeg = Seg1;
            Seg2.localPosition = Seg1.localPosition + new Vector3(0, 16, 0);
            CurrentShown = 1;
        }
    }
}
