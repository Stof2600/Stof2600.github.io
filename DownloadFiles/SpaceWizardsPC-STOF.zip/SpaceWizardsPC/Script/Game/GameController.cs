using System.Collections;
using System.Collections.Generic;
using UnityEngine.SceneManagement;
using UnityEngine.UI;
using UnityEngine;

public class GameController : MonoBehaviour
{
    public bool SpawnedP1, SpawnedP2;
    public GameObject P1Prefab, P2Prefab, EnemyPlacerPrefab;
    public Vector3 P1Spawn, P2Spawn, EnemyPlacerSpawn;
    public Transform GameField;

    public int Score;
    public int VisualScore;
    public Text ScoreText;

    public int PlayerLives;
    public Image[] LifeIcons;
    public Sprite ActiveLifeIcon, InActiveLifeIcon;

    public GameObject[] P1Health, P2Health;
    public int P1H, P2H;

    public Text P1Status, P2Status;

    public int ExtraSpawnerCount, ExtraSpawnerPlaced;

    public GameObject TitleCard;

    float DeathTimer, DeathCheck;
    public GameObject DeathCard;
    public Text EndScore;

    public bool SlowedTime;
    float SlowTimer, SlowTimerMax = 3;
    public GameObject SlowEffect;

    public float PlayerFireRateMulti;

    bool AudioActive;
    AudioListener AL;

    // Start is called before the first frame update
    void Start()
    {
        AL = FindObjectOfType<AudioListener>();
        AudioActive = true;

        PlayerLives = 4;
        DeathTimer = 0;
        DeathCard.SetActive(false);

        ExtraSpawnerPlaced = 0;

        SlowTimer = SlowTimerMax;
        SlowEffect.SetActive(false);
    }

    // Update is called once per frame
    void Update()
    {
        UpdateUI();

        if(TitleCard.activeSelf)
        {
            if(SpawnedP1 || SpawnedP2)
            {
                TitleCard.SetActive(false);
            }
        }

        if(Input.GetKeyDown(KeyCode.LeftShift) && !SpawnedP1)
        {
            SpawnPlayer(1);
        }
        else if(P1H <= 0)
        {
            SpawnedP1 = false;
        }
        else if(P1H > 0)
        {
            SpawnedP1 = true;
        }
        if(Input.GetKeyDown(KeyCode.Slash) && !SpawnedP2)
        {
            SpawnPlayer(2);
        }
        else if(P2H <= 0)
        {
            SpawnedP2 = false;
        }
        else if (P2H > 0)
        {
            SpawnedP2 = true;
        }

        if(PlayerLives > 10)
        {
            PlayerLives = 10;
        }

        if(!SpawnedP1 && !SpawnedP2 && PlayerLives <= 0)
        {
            DeathCheck -= Time.deltaTime;
        }
        else
        {
            DeathCheck = 0.2f;
        }

        if(DeathCheck <= 0)
        {
            DeathTimer += Time.deltaTime;
            DeathCard.SetActive(true);
            EndScore.text = "SCORE: " + Score.ToString("000000000");

            if(DeathTimer >= 4)
            {
                SceneManager.LoadScene(0);
            }
        }
        else
        {
            DeathTimer = 0;
            DeathCard.SetActive(false);
        }

        ExtraSpawnerCount = Score / 4000;
        if(ExtraSpawnerCount > ExtraSpawnerPlaced)
        {
            Instantiate(EnemyPlacerPrefab, EnemyPlacerSpawn, transform.rotation, GameField);
            ExtraSpawnerPlaced += 1;
        }

        if(SlowedTime)
        {
            SlowTime();
        }

        if(PlayerFireRateMulti > 0.4f)
        {
            PlayerFireRateMulti = 0.4f;
        }

        if(Input.GetKeyDown(KeyCode.Space))
        {
            if(AudioActive)
            {
                AL.enabled = false;
                AudioActive = false;
            }
            else
            {
                AL.enabled = true;
                AudioActive = true;
            }
        }
        if(Input.GetKeyDown(KeyCode.Escape))
        {
            Application.Quit();
        }
    }

    void SlowTime()
    {
        SlowTimer -= Time.deltaTime;
        Time.timeScale = 0.5f;
        SlowEffect.SetActive(true);

        if(SlowTimer <= 0)
        {
            Time.timeScale = 1f;

            SlowedTime = false;
            SlowTimer = SlowTimerMax;
            SlowEffect.SetActive(false);
        }
    }

    void UpdateUI()
    {
        if(VisualScore < Score)
        {
            VisualScore += 1;
        }

        ScoreText.text = "SCORE\n" + VisualScore.ToString("000000000");

        for(int i = 0; i < LifeIcons.Length; i++)
        {
            if(i < PlayerLives)
            {
                LifeIcons[i].sprite = ActiveLifeIcon;
            }
            else
            {
                LifeIcons[i].sprite = InActiveLifeIcon;
            }
        }

        for (int i = 0; i < P1Health.Length; i++)
        {
            if (i < P1H)
            {
                P1Health[i].SetActive(true);
            }
            else
            {
                P1Health[i].SetActive(false);
            }
        }
        for (int i = 0; i < P2Health.Length; i++)
        {
            if (i < P2H)
            {
                P2Health[i].SetActive(true);
            }
            else
            {
                P2Health[i].SetActive(false);
            }
        }

        if(SpawnedP1)
        {
            P1Status.text = "PLAYER 1\nACTIVE";
        }
        else
        {
            P1Status.text = "PLAYER 1\nL-SHIFT\nSTART";
        }

        if (SpawnedP2)
        {
            P2Status.text = "PLAYER 2\nACTIVE";
        }
        else
        {
            P2Status.text = "PLAYER 2\nSLASH\nSTART";
        }
    }

    public void AddScore(int Amount)
    {
        Score += Amount;
        if(Score > 999999999)
        {
            Score = 999999999;
        }
    }

    void SpawnPlayer(int Player)
    {
        if(PlayerLives > 0)
        {
            PlayerLives -= 1;

            if (Player == 1)
            {
                Instantiate(P1Prefab, P1Spawn, transform.rotation, GameField);
                SpawnedP1 = true;
            }
            else
            {
                Instantiate(P2Prefab, P2Spawn, transform.rotation, GameField);
                SpawnedP2 = true;
            }
        }
    }
}
