using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class HealthScript : MonoBehaviour
{
    public int Health;
    public int ScoreOnKill;
    public GameObject DeathEffect;

    public bool DoesItemDrop;
    public int DropChance = 5;
    public GameObject[] ItemDrops;

    public AudioClip PlayerHitSound;
    public bool IFrames;

    private void Update()
    {
        if(Health <= 0)
        {
            if(DeathEffect != null)
            {
                GameObject Effect = Instantiate(DeathEffect, transform.position, transform.rotation);

                if(Effect.GetComponentInChildren<TextMesh>())
                {
                    Effect.GetComponentInChildren<TextMesh>().text = "+" + ScoreOnKill;
                }
            }
            if(DoesItemDrop)
            {
                int R = Random.Range(0, 10);
                if(R > DropChance)
                {
                    int Item = Random.Range(0, ItemDrops.Length);

                    Instantiate(ItemDrops[Item], transform.position, transform.rotation);
                }
            }

            Destroy(gameObject);
        }
    }

    public void TakeDamage()
    {
        if(IFrames)
        {
            return;
        }

        Health -= 1;

        if(ScoreOnKill > 0 && Health <= 0)
        {
            FindObjectOfType<GameController>().AddScore(ScoreOnKill);
        }

        if(GetComponent<PlayerMovement>() && GetComponent<AudioSource>() && Health > 0)
        {
            GetComponent<AudioSource>().clip = PlayerHitSound;
            GetComponent<AudioSource>().Play();
        }
    }
}
