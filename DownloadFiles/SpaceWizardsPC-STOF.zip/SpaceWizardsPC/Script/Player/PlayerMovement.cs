using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerMovement : MonoBehaviour
{
    public int Player;
    public float XLimit, YLimit;
    public float InFireSpeed = 4, NormalSpeed = 5;
    float Speed;
    public Vector3 InputDir;

    public GameObject ProjectilePrefab;
    public float FireCoolDown;

    float FireTime;
    bool CanFire;

    public Sprite[] IdleSprites = new Sprite[4];
    public Sprite[] FireSprites = new Sprite[4];
    public SpriteRenderer SR;
    int CurrentFrame;
    bool FireAnim;
    float SpriteTime;
    float MaxSpriteTime = 0.2f;

    float SpawnTime;

    GameController GC;
    HealthScript HS;

    public AudioClip PickUpSound;

    private void Start()
    {
        SR = GetComponent<SpriteRenderer>();
        GC = FindObjectOfType<GameController>();
        HS = GetComponent<HealthScript>();

        SpawnTime = 2;
        HS.IFrames = true;
    }

    private void Update()
    {
        if(Player == 0)
        {
            P1Input();
            GC.P1H = HS.Health;
        }
        else
        {
            P2Input();
            GC.P2H = HS.Health;
        }

        Movement();

        if(FireTime < (FireCoolDown - GC.PlayerFireRateMulti))
        {
            CanFire = false;
            FireTime += Time.deltaTime;
        }
        else
        {
            CanFire = true;
        }

        SpriteAnim();

        if(SpawnTime > 0)
        {
            SpawnTime -= Time.deltaTime;
        }
        else
        {
            HS.IFrames = false;
        }
    }

    void Movement()
    {
        if(!GC.SlowedTime)
        {
            transform.position += InputDir * Speed * Time.deltaTime;
        }
        else
        {
            transform.position += (InputDir * Speed * Time.deltaTime) * 2;
        }

        if(transform.localPosition.y > YLimit)
        {
            transform.localPosition = new Vector3(transform.localPosition.x, YLimit, 0);
        }
        else if(transform.localPosition.y < -YLimit)
        {
            transform.localPosition = new Vector3(transform.localPosition.x, -YLimit, 0);
        }

        if(transform.localPosition.x > XLimit)
        {
            transform.localPosition = new Vector3(XLimit, transform.localPosition.y, 0);
        }
        else if(transform.localPosition.x < -XLimit)
        {
            transform.localPosition = new Vector3(-XLimit, transform.localPosition.y, 0);
        }
    }
    void Fire()
    {
        GameObject NewProj = Instantiate(ProjectilePrefab, transform.position + new Vector3(0, 0, 1), transform.rotation);
        NewProj.GetComponent<ProjectileMove>().PlayerProjectile = true;

        CanFire = false;
        FireTime = 0;
    }

    void P1Input()
    {
        if(Input.GetKey(KeyCode.A))
        {
            InputDir.x = -1;
        }
        else if(Input.GetKey(KeyCode.D))
        {
            InputDir.x = 1;
        }
        else
        {
            InputDir.x = 0;
        }

        if (Input.GetKey(KeyCode.S))
        {
            InputDir.y = -1;
        }
        else if (Input.GetKey(KeyCode.W))
        {
            InputDir.y = 1;
        }
        else
        {
            InputDir.y = 0;
        }

        if(Input.GetKey(KeyCode.LeftShift))
        {
            Speed = InFireSpeed;

            if(!FireAnim)
            {
                FireAnim = true;
                CurrentFrame = 0;
                SpriteTime = 0;
            }

            if(CanFire && CurrentFrame > 0)
            {
                Fire();
            }
        }
        else
        {
            Speed = NormalSpeed;
            FireAnim = false;
        }
    }
    void P2Input()
    {
        if (Input.GetKey(KeyCode.J))
        {
            InputDir.x = -1;
        }
        else if (Input.GetKey(KeyCode.L))
        {
            InputDir.x = 1;
        }
        else
        {
            InputDir.x = 0;
        }

        if (Input.GetKey(KeyCode.K))
        {
            InputDir.y = -1;
        }
        else if (Input.GetKey(KeyCode.I))
        {
            InputDir.y = 1;
        }
        else
        {
            InputDir.y = 0;
        }

        if (Input.GetKey(KeyCode.Slash))
        {
            Speed = InFireSpeed;

            if (!FireAnim)
            {
                FireAnim = true;
                CurrentFrame = 0;
                SpriteTime = 0;
            }

            if (CanFire && CurrentFrame > 0)
            {
                Fire();
            }
        }
        else
        {
            Speed = NormalSpeed;
            FireAnim = false;
        }
    }

    void SpriteAnim()
    {
        SpriteTime += Time.deltaTime;

        if(SpriteTime >= MaxSpriteTime)
        {
            CurrentFrame += 1;
            if(CurrentFrame >= IdleSprites.Length)
            {
                if(FireAnim)
                {
                    CurrentFrame = 1;
                }
                else
                {
                    CurrentFrame = 0;
                }
            }

            SpriteTime = 0;
        }

        if(!FireAnim)
        {
            SR.sprite = IdleSprites[CurrentFrame];
        }
        else
        {
            SR.sprite = FireSprites[CurrentFrame];
        }
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if(collision.GetComponent<EnemyMovement>())
        {
            HS.TakeDamage();
        }
        if(collision.GetComponent<ItemMove>())
        {
            collision.GetComponent<ItemMove>().Activate = true;
            GetComponent<AudioSource>().clip = PickUpSound;
            GetComponent<AudioSource>().Play();
        }
    }
}
