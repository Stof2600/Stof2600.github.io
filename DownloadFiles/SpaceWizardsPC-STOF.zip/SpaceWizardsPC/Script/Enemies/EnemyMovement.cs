using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyMovement : MonoBehaviour
{
    public Vector3 MoveSpeed;

    public bool FlipOnXEdge;
    float XLimit = 4.5f, TopLimit = 3.7f, BottomLimit = 5;
    public bool NoFire;

    public GameObject Projectile;
    public float FireTimerMax, FireTimerMin;
    float FireTimer;
    float FireTime;
    bool DoFire, DidFire;

    public Sprite[] IdleSprites;
    public Sprite[] FireSprites;
    public int FireFrame;
    public float MaxSpriteTime = 0.2f;
    int CurrentFrame;
    float SpriteTime;
    SpriteRenderer SR;

    private void Start()
    {
        SR = GetComponent<SpriteRenderer>();
        MoveSpeed.y *= -1;
    }

    void Update()
    {
        if(transform.position.y > TopLimit)
        {
            transform.localPosition += new Vector3(0, -0.5f, 0) * Time.deltaTime;
        }
        else if(transform.position.y < -BottomLimit)
        {
            Destroy(gameObject);
        }

        transform.localPosition += MoveSpeed * Time.deltaTime;

        if(FlipOnXEdge && (transform.localPosition.x > XLimit || transform.localPosition.x < -XLimit))
        {
            MoveSpeed.x *= -1;
        }

        if (!NoFire)
        {
            if (FireTime <= FireTimer)
            {
                FireTime += Time.deltaTime;
            }
            else
            {
                DoFire = true;
                CurrentFrame = 0;
                SpriteTime = 0;
                FireTime = 0;
                FireTimer = Random.Range(FireTimerMin, FireTimerMax);
            }

            if (DoFire && !DidFire && CurrentFrame == FireFrame)
            {
                Fire();
            }
            else if (DoFire && CurrentFrame == FireSprites.Length)
            {
                DoFire = false;
                DidFire = false;
                CurrentFrame = 0;
                SpriteTime = 0;
                FireTime = 0;
            }
        }
        
        SpriteAnim();
    }

    void Fire()
    {
        Instantiate(Projectile, transform.position, transform.rotation);
        DidFire = true;
    }

    void SpriteAnim()
    {
        SpriteTime += Time.deltaTime;

        if(SpriteTime >= MaxSpriteTime)
        {
            CurrentFrame += 1;
            if(CurrentFrame >= IdleSprites.Length && !DoFire)
            {
                CurrentFrame = 0;
            }

            SpriteTime = 0;
        }

        if(DoFire && CurrentFrame < FireSprites.Length)
        {
            SR.sprite = FireSprites[CurrentFrame];
        }
        else if(!DoFire)
        {
            SR.sprite = IdleSprites[CurrentFrame];
        }
    }
}
