using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemySpawning : MonoBehaviour
{
    GameController GC;

    float XLimit = 4;

    public float EnemySpawnTimer;
    public float SpawnTimeModifier;
    float SpawnTime;

    public GameObject[] Enemies;

    bool SpawnedRight;
    int StartingScore;

    private void Start()
    {
        GC = FindObjectOfType<GameController>();
        StartingScore = GC.Score;
    }

    // Update is called once per frame
    void Update()
    {
        if(GC.SpawnedP1 || GC.SpawnedP2)
        {
            SpawnTimeModifier = (float)(GC.Score - StartingScore) / 1000;
            if(SpawnTimeModifier > EnemySpawnTimer / 1.5f)
            {
                SpawnTimeModifier = EnemySpawnTimer / 1.5f;
            }

            SpawnTime += Time.deltaTime;

            if (SpawnTime >= EnemySpawnTimer - SpawnTimeModifier)
            {
                SpawnEnemy();
                SpawnTime = 0;
            }
        }
    }

    void SpawnEnemy()
    {
        float NewX = 0;

        if(SpawnedRight)
        {
            NewX = Random.Range(-XLimit, 0);
        }
        else
        {
            NewX = Random.Range(0, XLimit);
        }

        transform.localPosition = new Vector3(NewX, 5.5f, 0);

        if(NewX >= 0)
        {
            SpawnedRight = true;
        }
        else
        {
            SpawnedRight = false;
        }

        float R = Random.Range(0, 116);
        if(R <= 60)
        {
            Instantiate(Enemies[0], transform.position, transform.rotation, transform.parent);
        }
        else if (R > 60 && R <= 80)
        {
            Instantiate(Enemies[1], transform.position, transform.rotation, transform.parent);
        }
        else if (R > 80 && R <= 100)
        {
            Instantiate(Enemies[2], transform.position, transform.rotation, transform.parent);
        }
        else if (R > 100)
        {
            Instantiate(Enemies[3], transform.position, transform.rotation, transform.parent);
        }
    }
}
