	STAR WIZARDS (V0.1)
	             SD2A

	Project made by:

Stef Schouten
Levi Lamerichs

	
Controls:

P1: 
w, a, s, d : movement
Lshift: fire
Lcontrol: bomb

P2:
arrow keys: move
slash / : fire
dot . : bomb

FULL PROJECT LINK:
https://github.com/Stof2600/StarWizards

(some assets not in final game, those are for the mission mode which isn't ready for release)