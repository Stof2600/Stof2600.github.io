﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BulletController : MonoBehaviour
{
    public AmmoTypes AmmoType;

    public GameObject Projectile, Shell;
    public float ProjectileVelocity; //in meters per second
    public bool DoFireProjectile, FiredProjectile;

    bool HitObject;

    Vector3 ProjectileStart;
    Rigidbody PRB;

    private void FixedUpdate()
    {
        if(DoFireProjectile && !FiredProjectile)
        {
            FireProjectile();
        }
        else if(FiredProjectile)
        {
            ProjectileCollision();
        }
    }

    void FireProjectile()
    {
        ProjectileStart = Projectile.transform.position;
        Projectile.transform.position = Projectile.transform.position + Projectile.transform.up;
        PRB = Projectile.AddComponent<Rigidbody>();
        Projectile.transform.parent = null;

        PRB.AddForce(Projectile.transform.up * ProjectileVelocity);
        DoFireProjectile = false;
        FiredProjectile = true;
    }

    void ProjectileCollision()
    {
        RaycastHit Hit;
        Vector3 Dir = Projectile.transform.position - ProjectileStart;

        Debug.DrawRay(ProjectileStart, Dir, color: Color.red);

        if (Physics.Raycast(ProjectileStart, Dir, out Hit) && !HitObject)
        {

            if (Hit.transform.GetComponent<AITarget>())
            {
                Hit.transform.GetComponent<AITarget>().Die();
            }

            if (Hit.transform.GetComponent<Rigidbody>())
            {
                Rigidbody HitRB = Hit.transform.GetComponent<Rigidbody>();

                HitRB.velocity = PRB.velocity / 2;
            }

            if(Hit.transform.gameObject.layer != 30 && Hit.transform.gameObject.layer != 29)
            {
                print(PRB.velocity);
                PRB.velocity = Vector3.zero;
                PRB.constraints = RigidbodyConstraints.FreezeAll;
                PRB.isKinematic = true;

                Projectile.transform.position = Hit.point;
                Projectile.transform.SetParent(Hit.transform, true);
                HitObject = true;

                print(Hit.transform.name + "||" + Dir);
            }
        }
    }

    private void OnTriggerEnter(Collider other)
    {
        if(other.gameObject.layer == 30)
        {
            WeaponController WC = other.GetComponentInParent<WeaponController>();

            if(other.CompareTag("BoltBulletConnector") && AmmoType == WC.UsedAmmo)
            {
                if(!WC.HasBullet && WC.BoltOpen && !FiredProjectile)
                {
                    WC.SetBullet(GetComponent<BulletController>());
                }
            }
        }
        else if (other.GetComponent<MagazineController>())
        {
            MagazineController MC = other.GetComponent<MagazineController>();
            if (MC.Bullets.Count < MC.BulletPoints.Length && !FiredProjectile && !MC.Bullets.Contains(gameObject))
            {
                transform.SetParent(null);
                MC.Bullets.Add(gameObject);
            }
        }
    }
    private void OnTriggerExit(Collider other)
    {
        if (other.gameObject.layer == 30)
        {
            WeaponController WC = other.GetComponentInParent<WeaponController>();

            if (other.CompareTag("BoltBulletConnector") && AmmoType == WC.UsedAmmo)
            {
                if (!WC.HasBullet && WC.BoltOpen && !FiredProjectile)
                {
                    GetComponent<Collider>().enabled = false;
                    WC.SetBullet(GetComponent<BulletController>());
                }
            }
        }
    }
}
