﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public enum FireTypes
{
    SingleShot,
    SemiAuto,
    FullAuto
}

public enum AmmoTypes
{
    NineMilli,
    ThreePointBritish,

}

public class WeaponController : MonoBehaviour
{
    public bool CanFire, DoFire;
    public bool BoltClosed, BoltOpen, HasBullet;
    public bool RequiresRotation;
    public bool CanEjectMagazine, DoMagEject;
    public bool HasMagazine;

    public FireTypes FireType;
    public AmmoTypes UsedAmmo;

    public float EjectPower = 30;

    public Transform Bolt, BulletHolder, MagHolder, ClipHolder;
    public Transform Hammer;


    public MagazineController CurrentMag;
    public BulletController CurrentBullet;
    public ClipController CurrentClip;

    public Transform EjectDir;
    public Vector3 BoltMinPos, BoltMaxPos;
    public Quaternion BoltMaxRot, BoltMinRot;

    Vector3 HammerPosClosed;
    Quaternion HammerRotClosed;
    public Vector3 HammerPosOpen;
    public Quaternion HammerRotOpen;

    public GameObject FireEffect, ActiveEffect;
    public Transform EffectPoint;
    float EffectTime;

    public bool BoltPosClosed, BoltRotClosed, BoltPosOpen, BoltRotOpen;
    bool CanEject;

    // Start is called before the first frame update
    void Start()
    {
        BoltMinPos = Bolt.localPosition;
        BoltMinRot = Bolt.localRotation;

        if(Hammer != null)
        {
            HammerPosClosed = Hammer.localPosition;
            HammerRotClosed = Hammer.localRotation;

            AnimateHammer(false);
        }
    }

    // Update is called once per frame
    void Update()
    {
        if(HasBullet)
        {
            HoldBullet();
        }
        if(CurrentMag != null)
        {
            HoldMagazine();
        }

        if(CanFire && DoFire)
        {
            if (Hammer != null)
            {
                AnimateHammer(false);
            }

            FireWeapon();
        }
        else if(!CanFire && DoFire)
        {
            if(Hammer != null)
            {
                AnimateHammer(false);
            }

            DoFire = false;
        }

        if(HasBullet && BoltClosed && !CurrentBullet.FiredProjectile)
        {
            CanFire = true;
        }
        else
        {
            CanFire = false;
        }

        if (HasBullet && BoltOpen && CanEject)
        {
            EjectBullet();
        }

        if(HasMagazine && CanEjectMagazine && DoMagEject)
        {
            EjectMagazine();
        }

        if(EffectTime <= 0)
        {
            Destroy(ActiveEffect);
        }
        else
        {
            EffectTime -= Time.deltaTime;
        }

        BoltState();

        if(CurrentClip != null)
        {
            HoldClip();

            if(!BoltPosOpen)
            {
                EjectClip();
            }
        }
    }

    void FireWeapon()
    {
        CurrentBullet.DoFireProjectile = true;

        if (FireType == FireTypes.SemiAuto)
        {
            Bolt.localPosition = BoltMaxPos - new Vector3(0, 0, 0.1f);
        }

        if(FireEffect != null && EffectPoint != null)
        {
            EffectTime = 5;
            if(ActiveEffect == null)
            {
                ActiveEffect = Instantiate(FireEffect, EffectPoint.position, EffectPoint.rotation);
            }
            else
            {
                Destroy(ActiveEffect);
                ActiveEffect = Instantiate(FireEffect, EffectPoint.position, EffectPoint.rotation);
            }
        }
    }

    void BoltState()
    {  
        if (RequiresRotation)
        {
            Bolt.localRotation = new Quaternion(BoltMinRot.x, BoltMinRot.y, Bolt.localRotation.z, Bolt.localRotation.w);

            if (!BoltRotClosed)
            {
                Bolt.localPosition = new Vector3(BoltMinPos.x, BoltMinPos.y, Bolt.localPosition.z);
            }
            else if (BoltRotClosed)
            {
                Bolt.localPosition = BoltMinPos;
                Bolt.localPosition = new Vector3(BoltMinPos.x, BoltMinPos.y, Bolt.localPosition.z + 0.0001f);
            }

            if (Bolt.localRotation.z > BoltMaxRot.z)
            {
                Bolt.localRotation = new Quaternion(0, 0, BoltMaxRot.z, BoltMaxRot.w);
                BoltRotClosed = false;
                BoltRotOpen = true;
            }
            else if (Bolt.localRotation.z < BoltMinRot.z)
            {
                Bolt.localRotation = new Quaternion(0, 0, BoltMinRot.z, BoltMinRot.w);
                BoltRotClosed = true;
                BoltRotOpen = false;
            }

            if (Bolt.localPosition.z < BoltMinPos.z)
            {
                BoltPosClosed = false;
            }
            if (Bolt.localPosition.z > BoltMaxPos.z)
            {
                BoltPosOpen = false;
            }
            if (Bolt.localRotation.z > BoltMinRot.z)
            {
                BoltRotClosed = false;
            }
            if (Bolt.localRotation.z < BoltMaxRot.z)
            {
                BoltRotOpen = false;
            }

            if(BoltPosOpen || !BoltPosClosed)
            {
                Bolt.localRotation = BoltMaxRot;
            }
        }
        else
        {
            Bolt.localRotation = new Quaternion(BoltMaxRot.x, BoltMaxRot.y, BoltMaxRot.z, BoltMaxRot.w);
            Bolt.localPosition = new Vector3(BoltMaxPos.x, BoltMaxPos.y, Bolt.localPosition.z);
            BoltRotClosed = true;
            BoltRotOpen = true;
        }

        if(Bolt.localPosition.z <= BoltMaxPos.z)
        {
            Bolt.localPosition = BoltMaxPos;
            BoltPosClosed = false;
            BoltPosOpen = true;
        }
        else if (Bolt.localPosition.z >= BoltMinPos.z)
        {
            Bolt.localPosition = BoltMinPos;
            BoltPosClosed = true;
            BoltPosOpen = false;
        }

        if(BoltPosClosed && BoltRotClosed)
        {
            BoltClosed = true;
            BoltOpen = false;
        }
        else if(BoltPosOpen && BoltRotOpen)
        {
            BoltClosed = false;
            BoltOpen = true;

            if (Hammer != null)
            {
                AnimateHammer(true);
            }
        }

        if(BoltClosed)
        {
            CanEject = true;
        }
        else if(!BoltClosed && CurrentBullet == null)
        {
            CanEject = false;
        }

        if(FireType == FireTypes.SemiAuto)
        {
            Rigidbody BoltRB = Bolt.GetComponent<Rigidbody>();

            if(Bolt.localPosition.z < BoltMinPos.z)
            {
                Bolt.localPosition += new Vector3(0, 0, 0.05f);
            }
            else if(Bolt.localPosition.z >= BoltMinPos.z)
            {
                Bolt.localPosition += new Vector3(0, 0, 0.0001f);
            }
        }
    }

    public void SetBullet(BulletController NewBullet)
    {
        CurrentBullet = NewBullet;

        if (CurrentBullet.GetComponentInParent<MagazineController>())
        {
            MagazineController MC = CurrentBullet.GetComponentInParent<MagazineController>();

            MC.Bullets.Remove(CurrentBullet.gameObject);
        }

        CurrentBullet.transform.SetParent(BulletHolder);

        Rigidbody BulletRB = CurrentBullet.GetComponent<Rigidbody>();
        CurrentBullet.GetComponent<Collider>().enabled = false;
        BulletRB.isKinematic = true;

        HasBullet = true;
    }
    void HoldBullet()
    {
        CurrentBullet.transform.position = BulletHolder.position;
        CurrentBullet.transform.rotation = BulletHolder.rotation;
    }
    void EjectBullet()
    {
        Rigidbody BulletRB = CurrentBullet.GetComponent<Rigidbody>();
        Collider BulletCol = CurrentBullet.GetComponent<Collider>();

        CurrentBullet.transform.SetParent(null);

        BulletRB.isKinematic = false;

        BulletRB.AddForce(EjectDir.up + EjectDir.right * EjectPower * 10);

        BulletCol.enabled = true;
        BulletCol.isTrigger = false;

        HasBullet = false;
        CurrentBullet = null;
    }

    public void SetMagazine(MagazineController NewMag)
    {
        MagHolder.localScale = new Vector3(1, 1, 1);
        CurrentMag = NewMag;

        Rigidbody MagRB = CurrentMag.GetComponent<Rigidbody>();

        Collider MagCol = CurrentMag.GetComponentInChildren<MeshCollider>();

        MagCol.enabled = false;
        CurrentMag.transform.SetParent(MagHolder);
        MagRB.isKinematic = true;

        HasMagazine = true;
        CurrentMag.InWeapon = true;
    }
    void HoldMagazine()
    {
        CurrentMag.transform.position = MagHolder.position;
        CurrentMag.transform.rotation = MagHolder.rotation;
    }
    void EjectMagazine()
    {
        MagHolder.localScale = new Vector3(1, 1, 1);

        Rigidbody MagRB = CurrentMag.GetComponent<Rigidbody>();

        Collider MagCol = CurrentMag.GetComponentInChildren<MeshCollider>();

        CurrentMag.transform.SetParent(null);
        StartCoroutine(DisableMagwel());

        MagRB.isKinematic = false;
        HasMagazine = false;
        CurrentMag.InWeapon = false;

        MagCol.enabled = true;
        MagRB.AddForce(-CurrentMag.transform.up * EjectPower);

        CurrentMag = null;
        DoMagEject = false;
    }

    public void SetClip(ClipController NewClip)
    {
        CurrentClip = NewClip;

        Rigidbody ClipRB = CurrentClip.GetComponent<Rigidbody>();

        Collider ClipCol = CurrentClip.GetComponentInChildren<MeshCollider>();

        CurrentClip.transform.position = ClipHolder.transform.position;
        CurrentClip.transform.rotation = ClipHolder.transform.rotation;

        ClipCol.enabled = false;
        CurrentClip.transform.SetParent(ClipHolder);
        ClipRB.isKinematic = true;
    }
    void HoldClip()
    {
        CurrentClip.transform.position = ClipHolder.transform.position;
        CurrentClip.transform.rotation = ClipHolder.transform.rotation;
    }
    void EjectClip()
    {
        Rigidbody ClipRB = CurrentClip.GetComponent<Rigidbody>();
        Collider ClipCol = CurrentClip.GetComponent<Collider>();

        CurrentClip.transform.SetParent(null);

        ClipRB.isKinematic = false;

        ClipRB.AddForce(EjectDir.up + EjectDir.right * EjectPower * 10);

        ClipCol.enabled = true;
        ClipCol.isTrigger = false;

        CurrentClip = null;
    }

    void AnimateHammer(bool Open)
    {
        if(Open)
        {
            Hammer.localPosition = HammerPosOpen;
            Hammer.localRotation = HammerRotOpen;
        }
        else if(!Open)
        {
            Hammer.localPosition = HammerPosClosed;
            Hammer.localRotation = HammerRotClosed;
        }
    }

    IEnumerator DisableMagwel()
    {
        MagHolder.gameObject.SetActive(false);

        yield return new WaitForSeconds(0.5f);

        MagHolder.gameObject.SetActive(true);
    }

    private void OnCollisionStay(Collision collision)
    {
        Bolt.GetComponent<Rigidbody>().isKinematic = false;
    }
    private void OnCollisionExit(Collision collision)
    {
        Bolt.GetComponent<Rigidbody>().isKinematic = true; ;
    }
}
