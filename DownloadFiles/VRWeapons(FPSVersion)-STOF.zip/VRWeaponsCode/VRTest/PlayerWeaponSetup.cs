﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerWeaponSetup : MonoBehaviour
{

    public Transform WeaponSlot, AimSlot;
    public GameObject CrossHair;
    public TextMesh StatText;

    Transform Cam;
    Transform CurrentWeapon;

    List<MagazineController> Mags = new List<MagazineController>();
    List<MagazineController> PickupMags = new List<MagazineController>();

    // Start is called before the first frame update
    void Start()
    {
        Cam = GetComponentInChildren<Camera>().transform;
    }

    // Update is called once per frame
    void Update()
    {
        if(CurrentWeapon == null)
        {
            CheckForWeaponPickup();
        }
        else
        {
            HoldWeapon();
            if(Input.GetKeyDown(KeyCode.Q))
            {
                CurrentWeapon = null;
            }
        }

        if(Input.GetKeyDown(KeyCode.E) && PickupMags.Count > 0)
        {
            PickupMagazines();
        }
        if(StatText != null)
        {
            UpdateText();
        }
    }

    void CheckForWeaponPickup()
    {
        RaycastHit Hit;

        if(Physics.Raycast(Cam.position, Cam.forward, out Hit, 2f))
        {
            if(Hit.transform.GetComponent<Interactable>() && Hit.transform.GetComponent<WeaponController>() && Input.GetKeyDown(KeyCode.E))
            {
                CurrentWeapon = Hit.transform;
                CurrentWeapon.GetComponent<Rigidbody>().isKinematic = true;
                foreach(Collider col in CurrentWeapon.GetComponentsInChildren<Collider>())
                {
                    col.isTrigger = true;
                }
            }
        }
    }
    void HoldWeapon()
    {
        if(!Input.GetKey(KeyCode.Mouse1))
        {
            CurrentWeapon.position = WeaponSlot.position;
            CurrentWeapon.rotation = WeaponSlot.rotation;

            CrossHair.SetActive(true);
        }
        else
        {
            CurrentWeapon.position = AimSlot.position;
            CurrentWeapon.rotation = AimSlot.rotation;

            CrossHair.SetActive(false);
        }

        if (Input.GetKeyDown(KeyCode.F))
        {
            PullSlide(CurrentWeapon.GetComponent<WeaponController>());
        }
        else if (CurrentWeapon.GetComponent<WeaponController>().FireType == FireTypes.SingleShot && !CurrentWeapon.GetComponent<WeaponController>().BoltClosed)
        {
            WeaponController Weapon = CurrentWeapon.GetComponent<WeaponController>();
            if(Weapon.BoltPosClosed)
            {
                Weapon.Bolt.localRotation = new Quaternion(Weapon.BoltMinRot.x, Weapon.BoltMinRot.y, Weapon.BoltMinRot.z - 0.01f, Weapon.BoltMinRot.w);
            }
            else
            {
                Weapon.Bolt.localPosition += new Vector3(0, 0, 0.01f);
            }
        }
        if (Input.GetKeyDown(KeyCode.R) && Mags.Count > 0 && !CurrentWeapon.GetComponent<WeaponController>().HasMagazine)
        {
            ReloadWeapon(CurrentWeapon.GetComponent<WeaponController>(), Mags[0]);
            Mags.Remove(Mags[0]);
        }
        else if(Input.GetKeyDown(KeyCode.R) && CurrentWeapon.GetComponent<WeaponController>().HasMagazine)
        {
            CurrentWeapon.GetComponent<WeaponController>().DoMagEject = true;
        }
        if(Input.GetKeyDown(KeyCode.Mouse0))
        {
            CurrentWeapon.GetComponent<WeaponController>().DoFire = true;
        }
    }

    void PickupMagazines()
    {
        for(int i = 0; PickupMags.Count + 1 > Mags.Count; i++)
        {
            Mags.Add(PickupMags[i]);
            PickupMags.Remove(PickupMags[i]);

            Mags[i].gameObject.SetActive(false);
        }
    }

    void PullSlide(WeaponController Weapon)
    {
        Weapon.Bolt.localRotation = Weapon.BoltMaxRot;
        Weapon.Bolt.localPosition = Weapon.BoltMaxPos;
    }
    void ReloadWeapon(WeaponController Weapon, MagazineController Magazine)
    {
        if(Magazine.UsedAmmo == Weapon.UsedAmmo)
        {
            Magazine.transform.position = transform.position;
            Magazine.gameObject.SetActive(true);
            Weapon.SetMagazine(Magazine);
        }
        else
        {
            for (int i = 0; i < Mags.Count; i++)
            {
                if(Mags[i].UsedAmmo == Weapon.UsedAmmo)
                {
                    ReloadWeapon(Weapon, Mags[i]);
                    break;
                }
            }
        }
    }

    void UpdateText()
    {
        if(CurrentWeapon != null)
        {
            bool MagazineLoaded;
            bool SlidePulled;
            MagazineLoaded = CurrentWeapon.GetComponent<WeaponController>().HasMagazine;
            SlidePulled = CurrentWeapon.GetComponent<WeaponController>().HasBullet;
            StatText.text = "STATS\n" + "MagazineLoaded: " + MagazineLoaded + "\nSlidePulled: " + SlidePulled + "\nMags: " + Mags.Count +"\nCrosshair can mis\nmouse 2 for good aim";
        }
        else
        {
            StatText.text = "STATS\nNO WEAPON";
        }
    }

    private void OnTriggerStay(Collider other)
    {
        if(other.GetComponent<MagazineController>() && !PickupMags.Contains(other.GetComponent<MagazineController>()) && !other.GetComponent<MagazineController>().InWeapon)
        {
            PickupMags.Add(other.GetComponent<MagazineController>());
        }

        if(other.gameObject.layer == 4)
        {
            transform.position = new Vector3(0, 1.5f, 0);
        }
    }
    private void OnTriggerExit(Collider other)
    {
        if (other.GetComponent<MagazineController>())
        {
            PickupMags.Remove(other.GetComponent<MagazineController>());
        }
    }
}
