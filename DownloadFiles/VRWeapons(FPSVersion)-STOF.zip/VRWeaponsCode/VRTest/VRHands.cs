﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class VRHands : MonoBehaviour
{

    public bool CanGrab, DoGrab, Interact;
    public GameObject CurrentGrabObject;
    public GameObject GrabObject;

    Vector3 BoltOffset;

    public Material CanGrabMat;
    public Material DefaultMat;

    private void FixedUpdate()
    {
        if(CanGrab && DoGrab && CurrentGrabObject == null)
        {
            PickUpObject(GrabObject);
        }

        if(CurrentGrabObject != null)
        {
            HoldObject();

            if(!DoGrab)
            {
                DropObject();
            }
        }

        if(GrabObject == null)
        {
            CanGrab = false;
        }
    }

    public void PickUpObject(GameObject obj)
    {
        CurrentGrabObject = GrabObject;
        Rigidbody ObjRB = CurrentGrabObject.GetComponent<Rigidbody>();

        if(ObjRB != null)
        {
            ObjRB.isKinematic = true;
        }

        CurrentGrabObject.GetComponent<Interactable>().InHand = true;
        GetComponent<Collider>().enabled = false;
    }
    void HoldObject()
    {
        CurrentGrabObject.transform.position = transform.position + BoltOffset;
        CurrentGrabObject.transform.rotation = transform.rotation;

        GrabObject = null;

        if(CurrentGrabObject.GetComponent<WeaponController>())
        {
            WeaponController Weapon = CurrentGrabObject.GetComponent<WeaponController>();

            if(Interact)
            {
                Weapon.DoFire = true;
                Interact = false;
            }
        }
        if(CurrentGrabObject.GetComponent<MagazineController>())
        {
            if(CurrentGrabObject.GetComponent<MagazineController>().InWeapon)
            {
                DropObject();
            }
        }
    }
    public void DropObject()
    {
        Rigidbody ObjRB = CurrentGrabObject.GetComponent<Rigidbody>();
        CurrentGrabObject.GetComponent<Interactable>().InHand = false;

        if (ObjRB != null)
        {
            ObjRB.isKinematic = false;
        }

        CurrentGrabObject = null;
        GrabObject = null;

        GetComponent<Collider>().enabled = true;
    }

    private void OnTriggerStay(Collider other)
    {
        if(other.GetComponent<Interactable>() && !other.GetComponent<Interactable>().InHand)
        {
            GetComponent<MeshRenderer>().material = CanGrabMat;

            CanGrab = true;
            GrabObject = other.gameObject;

            if(other.CompareTag("BoltInteractable"))
            {
                BoltOffset = other.transform.position - transform.position;
            }
            else
            {
                BoltOffset = Vector3.zero;
            }
        }
    }
    private void OnTriggerExit(Collider other)
    {
        GetComponentInParent<VRHandInput>().UpdateMaterials();

        if (other.gameObject.layer == 29)
        {
            CanGrab = false;
            GrabObject = null;
        }
    }
}
