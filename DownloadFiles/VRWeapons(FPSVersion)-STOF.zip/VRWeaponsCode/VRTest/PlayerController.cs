﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public enum MovementType
{
    Walking,
    Sprinting,
    Crouching,
    Sliding
}

public class PlayerController : MonoBehaviour
{

    Rigidbody RB;

    public Collider PlayerModel;

    Transform Camera;
    Transform ClosestWall;

    Vector3 MoveDir, LookDir;
    Vector3 RBVel;

    public PhysicMaterial WalkingFriction, SlidingFriction;

    MovementType CurrentMove;

    public float WalkingMaxSpeed = 5, SprintingMaxSpeed = 15, CrouchingMaxSpeed = 1;

    public bool Grounded;

    float MaxSpeed, CurrentSpeed;
    float MoveSpeed = 15, CameraSensi = 3, JumpForce = 35;
    float MoveMultiplyer = 1f;
    float CameraAngle;
    float WallRunMaxSpeed;

    bool Jump, WallRun;
    bool CanWallRun, WallRunning;

    // Start is called before the first frame update
    void Start()
    {
        RB = GetComponent<Rigidbody>();

        CurrentMove = MovementType.Walking;
        Camera = GameObject.FindObjectOfType<Camera>().transform;
        //PlayerModel = GetComponentInChildren<Collider>();

        MaxSpeed = WalkingMaxSpeed;

        Cursor.lockState = CursorLockMode.Locked;
        Cursor.visible = false;
    }

    // Update is called once per frame
    void Update()
    {
        PlayerInput();
        PlayerMovement();
        MovementChecks();
        UpdateValues();
    }

    void PlayerMovement()
    {
        RBVel = RB.velocity;

        if(RBVel.z < MaxSpeed && RBVel.x < MaxSpeed && RBVel.z > -MaxSpeed && RBVel.x > -MaxSpeed && !WallRunning)
        {
            RB.AddForce(transform.forward * MoveDir.z * MoveSpeed);
            RB.AddForce(transform.right * MoveDir.x * MoveSpeed);
        }

        if(Grounded && Jump)
        {
            RB.AddForce(transform.up * JumpForce * 2);
            Grounded = false;
        }

        if(!Grounded && CanWallRun && WallRun && ClosestWall != null)
        {
            RB.useGravity = false;
           
            if(!WallRunning)
            {
                RB.velocity = new Vector3(RBVel.x, 0, RBVel.y);
                WallRunning = true;
            }
            if(RBVel.z < WallRunMaxSpeed && RBVel.x < WallRunMaxSpeed && RBVel.z > -WallRunMaxSpeed && RBVel.x > -WallRunMaxSpeed)
            {
                RB.AddForce(transform.forward * MoveSpeed);
            }
        }
        else
        {
            RB.useGravity = true;
            WallRunMaxSpeed = CurrentSpeed;
            WallRunning = false;
        }

        transform.Rotate(transform.up * LookDir.x * CameraSensi);
        Camera.localRotation = new Quaternion(CameraAngle, 0, 0, Camera.localRotation.w);
    }

    void PlayerInput()
    {
        if(Input.GetKey(KeyCode.W))
        {
            MoveDir.z = 1;
        }
        else if(Input.GetKey(KeyCode.S))
        {
            MoveDir.z = -1;
        }
        else
        {
            MoveDir.z = 0;
        }

        if (Input.GetKey(KeyCode.D))
        {
            MoveDir.x = 1;
        }
        else if (Input.GetKey(KeyCode.A))
        {
            MoveDir.x = -1;
        }
        else
        {
            MoveDir.x = 0;
        }

        if(Input.GetKey(KeyCode.Space))
        {
            Jump = true;
            WallRun = true;
        }
        else
        {
            Jump = false;
            WallRun = false;
        }

        LookDir.x = Input.GetAxis("Mouse X");
        LookDir.y = Input.GetAxis("Mouse Y");

        CameraAngle = Camera.localRotation.x - LookDir.y * 0.1f;
        CameraAngle = Mathf.Clamp(CameraAngle, -0.5f, 0.5f);
    }

    void MovementChecks()
    {
        RaycastHit Hit;
        RaycastHit WallR;
        RaycastHit WallL;

        CurrentSpeed = RBVel.magnitude;

        if (Physics.Raycast(transform.position, -transform.up, out Hit, 1.1f))
        {
            Debug.DrawLine(transform.position, Hit.point);
            Grounded = true;
        }
        else
        {
            Grounded = false;
        }

        if (Physics.Raycast(transform.position, transform.right, out WallR, 1.5f))
        {
            Debug.DrawLine(transform.position, WallR.point);
            CanWallRun = true;

            ClosestWall = WallR.transform;
        }
        else if (Physics.Raycast(transform.position, -transform.right, out WallL, 1.5f))
        {
            Debug.DrawLine(transform.position, WallL.point);
            CanWallRun = true;

            ClosestWall = WallL.transform;
        }
        else
        {
            CanWallRun = false;

            ClosestWall = null;
        }

        if (Input.GetKey(KeyCode.LeftControl))
        {
            if(CurrentMove == MovementType.Walking)
            {
                CurrentMove = MovementType.Crouching;
            }
            else
            {
                CurrentMove = MovementType.Sliding;
            }
        }
        else if(Input.GetKey(KeyCode.LeftShift))
        {
            CurrentMove = MovementType.Sprinting;
        }
        else if(Grounded)
        {
            CurrentMove = MovementType.Walking;
        }
    }

    void UpdateValues()
    {
        if(CurrentMove == MovementType.Walking)
        {
            MaxSpeed = WalkingMaxSpeed;

            Camera.localPosition = new Vector3(0, 0.7f, 0);
            PlayerModel.transform.localScale = new Vector3(1, 1, 1);

            PlayerModel.material = WalkingFriction;
        }
        else if(CurrentMove == MovementType.Sprinting)
        {
            MaxSpeed = SprintingMaxSpeed;

            Camera.localPosition = new Vector3(0, 0.7f, 0);
            PlayerModel.transform.localScale = new Vector3(1, 1, 1);

            PlayerModel.material = WalkingFriction;
        }
        else if(CurrentMove == MovementType.Crouching || CurrentMove == MovementType.Sliding)
        {
            MaxSpeed = CrouchingMaxSpeed;

            Camera.localPosition = new Vector3(0, 0.3f, 0);
            PlayerModel.transform.localScale = new Vector3(1, 0.5f, 1);

            if(CurrentMove == MovementType.Sliding)
            {
                PlayerModel.material = SlidingFriction;
            }
            else
            {
                PlayerModel.material = WalkingFriction;
            }
        }
    }
}
