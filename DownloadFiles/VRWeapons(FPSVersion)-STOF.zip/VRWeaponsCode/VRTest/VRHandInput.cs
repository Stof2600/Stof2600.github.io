﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class VRHandInput : MonoBehaviour
{
    public List<VRHands> Hands = new List<VRHands>();
    public Material ActiveMat, DefaultMat;
    public Transform Camera;
    public float NormalMoveSpeed, SlowMoveSpeed;
    float MoveSpeed;
    public int CurrentHand;

    // Start is called before the first frame update
    void Start()
    {
        CurrentHand = 0;
        Hands[CurrentHand].GetComponent<MeshRenderer>().material = ActiveMat;
    }

    // Update is called once per frame
    void Update()
    {
        if (Input.GetKey(KeyCode.Space))
        {
            if(Hands[CurrentHand].CanGrab)
            {
                Hands[CurrentHand].DoGrab = true;
            }
        }
        if (Input.GetKey(KeyCode.LeftAlt))
        {
            Hands[CurrentHand].DoGrab = false;
        }

        OpenMovement();

        if (Input.GetKeyDown(KeyCode.Return))
        {
            Hands[CurrentHand].GetComponent<MeshRenderer>().material = DefaultMat;
            CurrentHand += 1;

            if(CurrentHand > Hands.Count - 1)
            {
                CurrentHand = 0;
            }
            Hands[CurrentHand].GetComponent<MeshRenderer>().material = ActiveMat;
        }
        if(Input.GetKey(KeyCode.Backspace))
        {
            MoveSpeed = SlowMoveSpeed;
        }
        else
        {
            MoveSpeed = NormalMoveSpeed;
        }
    }

    void OpenMovement()
    {
        Transform MoveHand = Hands[CurrentHand].transform;

        if (Input.GetKey(KeyCode.RightShift))
        {
            if (Input.GetKey(KeyCode.W))
            {
                MoveHand.position += Camera.forward * MoveSpeed;
            }
            else if (Input.GetKey(KeyCode.S))
            {
                MoveHand.position += Camera.forward * -MoveSpeed;
            }

            if (Input.GetKey(KeyCode.A))
            {
                MoveHand.position += transform.right * -MoveSpeed;
            }
            else if (Input.GetKey(KeyCode.D))
            {
                MoveHand.position += transform.right * MoveSpeed;
            }

            if (Input.GetKey(KeyCode.Z))
            {
                MoveHand.position += transform.up * MoveSpeed;
            }
            else if (Input.GetKey(KeyCode.X))
            {
                MoveHand.position += transform.up * -MoveSpeed;
            }


            if (Input.GetKey(KeyCode.UpArrow))
            {
                MoveHand.Rotate(MoveHand.right * MoveSpeed * 10);
            }
            else if (Input.GetKey(KeyCode.DownArrow))
            {
                MoveHand.Rotate(MoveHand.right * -MoveSpeed * 10);
            }

            if (Input.GetKey(KeyCode.RightArrow))
            {
                MoveHand.Rotate(MoveHand.up * MoveSpeed * 10);
            }
            else if (Input.GetKey(KeyCode.LeftArrow))
            {
                MoveHand.Rotate(MoveHand.up * -MoveSpeed * 10);
            }

        }
        else
        {
            if (Input.GetKey(KeyCode.W))
            {
                transform.position += transform.forward * MoveSpeed;
            }
            else if (Input.GetKey(KeyCode.S))
            {
                transform.position += transform.forward * -MoveSpeed;
            }

            if (Input.GetKey(KeyCode.A))
            {
                transform.Rotate(transform.up * -MoveSpeed * 10);
            }
            else if (Input.GetKey(KeyCode.D))
            {
                transform.Rotate(transform.up * MoveSpeed * 10);
            }

            if (Input.GetKey(KeyCode.UpArrow))
            {
                Camera.Rotate(transform.right * -MoveSpeed * 10);
            }
            else if (Input.GetKey(KeyCode.DownArrow))
            {
                Camera.Rotate(transform.right * MoveSpeed * 10);
            }
        }

        if (Hands[CurrentHand].CurrentGrabObject != null)
        {
            if (Input.GetKeyDown(KeyCode.Tab))
            {
                Hands[CurrentHand].Interact = true;
            }
        }
    }

    public void UpdateMaterials()
    {
        Hands[CurrentHand].GetComponent<MeshRenderer>().material = ActiveMat;
    }
}
