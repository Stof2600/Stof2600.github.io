﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ClipController : MonoBehaviour
{
    public GameObject AmmoPrefab;
    public Transform BulletInteractable;
    public Transform[] BulletPoints;
    bool Loaded;

    // Start is called before the first frame update
    void Start()
    {
        for (int i = 0; i < BulletPoints.Length; i++)
        {
            Transform t = BulletPoints[i];
            GameObject NewBullet;

            NewBullet = Instantiate(AmmoPrefab, t.position, t.rotation);

            NewBullet.GetComponent<Rigidbody>().isKinematic = true;
            NewBullet.transform.SetParent(t);
        }

        BulletInteractable.GetComponent<Collider>().enabled = false;
        Loaded = true;
    }

    private void OnTriggerEnter(Collider other)
    {
        if (other.gameObject.layer == 30)
        {
            WeaponController WC = other.GetComponentInParent<WeaponController>();

            if (other.CompareTag("ClipConnector") && Loaded && WC.BoltOpen)
            {
                if (WC.CurrentClip == null)
                {
                    BulletInteractable.GetComponent<Collider>().enabled = true;
                    WC.SetClip(GetComponent<ClipController>());
                }
            }
        }
    }
}
