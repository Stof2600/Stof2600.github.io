﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AmmoSpawner : MonoBehaviour
{
    public GameObject ItemToSpawn;
    public Transform SpawnPosition;
    GameObject CurrentItem;

    // Update is called once per frame
    void FixedUpdate()
    {
        if (CurrentItem == null)
        {
            CurrentItem = Instantiate(ItemToSpawn, SpawnPosition.position, SpawnPosition.rotation);
            CurrentItem.GetComponent<MagazineController>().StartLoaded = true;
        }
        else
        {

            float Dis = Vector3.Distance(SpawnPosition.position, CurrentItem.transform.position);

            if (Dis > 0.3f || !CurrentItem.activeSelf)
            {
                CurrentItem = null;
            }
        }
    }
}
