﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MagazineController : MonoBehaviour
{

    public AmmoTypes UsedAmmo;

    public Transform[] BulletPoints;
    public List<GameObject> Bullets = new List<GameObject>();
    public GameObject AmmoPrefab;
    public bool StartLoaded;

    public bool InWeapon;

    // Start is called before the first frame update
    void Start()
    {
        if(StartLoaded)
        {
            for(int i = 0; i < BulletPoints.Length; i++)
            {
                Transform t = BulletPoints[i];
                GameObject NewBullet;

                NewBullet = Instantiate(AmmoPrefab, t.position, t.rotation);

                if(i != 0)
                {
                    NewBullet.GetComponent<Collider>().enabled = false;
                }
                else
                {
                    NewBullet.GetComponent<Collider>().isTrigger = true;
                }

                NewBullet.GetComponent<Rigidbody>().isKinematic = true;
                NewBullet.transform.SetParent(t);

                Bullets.Add(NewBullet);
            }
        }

        print(transform.name + "] Bullets:" + Bullets.Count + "|| Points: " + BulletPoints.Length);
    }

    // Update is called once per frame
    void Update()
    {
        if(Bullets.Count >= 0)
        {
            for (int i = 0; i < Bullets.Count; i++)
            {
                Bullets[i].transform.rotation = BulletPoints[i].rotation;
                Bullets[i].transform.position = BulletPoints[i].position;
                Bullets[i].transform.SetParent(BulletPoints[i]);

                if (i != 0)
                {
                    Bullets[i].GetComponent<Collider>().enabled = false;
                }
                else
                {
                    Bullets[i].GetComponent<Collider>().enabled = true;
                    Bullets[i].GetComponent<Collider>().isTrigger = true;
                }

                Bullets[i].GetComponent<Rigidbody>().isKinematic = true;
            }
        }
    }

    private void OnTriggerEnter(Collider other)
    {
        if (other.gameObject.layer == 30)
        {
            WeaponController WC = other.GetComponentInParent<WeaponController>();

            if (other.CompareTag("MagazineConnector") && UsedAmmo == WC.UsedAmmo)
            {
                if (WC.CurrentMag == null)
                {
                    WC.SetMagazine(GetComponent<MagazineController>());
                }
            }
        }
    }
}
