﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class HangingTargetScript : MonoBehaviour
{
    public LineRenderer Rope;
    public Transform Hangpoint;
    public Transform RopeTarget;

    // Update is called once per frame
    void Update()
    {
        Rope.SetPosition(0, Hangpoint.position);
        Rope.SetPosition(1, RopeTarget.position);
    }
}
