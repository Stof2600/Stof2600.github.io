﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine.AI;
using UnityEngine;

public class AISpawner : MonoBehaviour
{

    public int SpawnAmount = 5;
    public GameObject EnemyPrefab;

    // Start is called before the first frame update
    void Start()
    {
        for(int i = 0; i < SpawnAmount; i++)
        {
            GameObject Enemy = Instantiate(EnemyPrefab, transform.position, transform.rotation);

            Enemy.transform.localScale = new Vector3(Random.Range(1, 1.8f), Random.Range(1, 1.8f), Random.Range(1, 1.8f));
            Enemy.GetComponent<NavMeshAgent>().speed = Random.Range(3.5f, 7.1f);
        }
    }
}
