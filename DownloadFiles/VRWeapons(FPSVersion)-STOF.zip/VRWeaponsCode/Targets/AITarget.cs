﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine.AI;
using UnityEngine;

public class AITarget : MonoBehaviour
{

    NavMeshAgent Agent;
    Vector3 StartPos, TargetPos;
    public Vector3 MaxRange, MinRange;

    // Start is called before the first frame update
    void Start()
    {
        Agent = GetComponent<NavMeshAgent>();
        StartPos = transform.position;
    }

    // Update is called once per frame
    void Update()
    {

        float Dis = Vector3.Distance(transform.position, TargetPos);


        if (TargetPos == Vector3.zero || Dis < 3)
        {
            TargetPos = StartPos + new Vector3(Random.Range(MinRange.x, MaxRange.x), StartPos.y, Random.Range(MinRange.z, MaxRange.z));
        }

        Agent.destination = TargetPos;
    }

    public void Die()
    {
        Agent.enabled = false;
        gameObject.AddComponent<Rigidbody>();
        gameObject.GetComponent<Rigidbody>().AddForce(transform.up * 500);
        gameObject.GetComponent<Rigidbody>().MoveRotation(new Quaternion(45, 0, 45, transform.rotation.w));
        GetComponent<AITarget>().enabled = false;
    }
}
