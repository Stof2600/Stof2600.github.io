Controls are displayed on screen
Play the game in full screen or you can't read the text

Reloading can be a bit broken at times

This is the first person shooter version for weapons supposed to be used in VR so expect some problems
Check the code to see all the VR parts

alt+f4 to close the game