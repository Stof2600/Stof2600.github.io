If you play the game on PC make sure to check the [KEYBOARD CONTROLS] button on the main menu.
You can play the game without but its not recommended

The APK file is to instal the game on android phones.
This only works via USB with developer mode & USB debuging turned on in your phone setting

CONTROLS------------------------------------------------------------------------------------:

keyboard controls list:
-arrow keys (left/rigth): steering
-arrow keys (up/down): acceleration
-space: drifting
-menu selection: use mouse

mobile controls list:
-Slider bar: steering
-buttons (brake/gas): acceleration
-buttons (drift): drifting
-menu selection: use touch controls

drifting controls (on both PC and mobile):
Works mostly the same as Mario kart DS

-the drift start direction depends on the direction you are steering in
-hitting the drift button without steering doesn't do anything
-steering away from the start direction will slow down your turning
-steering into the start direction will speed up your turning

-for dirft boost: follow steps
1.steer completely into the start direction
2.wait a bit
3.steer completely into the other direction
4. wait a bit
5.repeat 3 times
6.if sparks at vehicle wheel light up orange instead of blue you have a drift boost (if sparks dont change repeat steps)

-stop drifting to acitvate the boost
