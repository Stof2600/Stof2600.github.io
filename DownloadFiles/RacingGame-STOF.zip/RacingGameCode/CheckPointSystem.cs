using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CheckPointSystem : MonoBehaviour
{
    public GameObject FinishLine;
    public List<GameObject> Checkpoints = new List<GameObject>();
}
