using System.Collections;
using System.Collections.Generic;
using UnityEngine.UI;
using UnityEngine;

public class TouchInput : MonoBehaviour
{

    public bool TouchActive;
    public GameObject TouchInputMenu;

    public Slider XinputSlider;
    public CheckButtonHeld GasButton, BrakeButton, DriftButton, SliderCheck;

    public bool SpeedUp, Brake, Drift;

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        if(!TouchActive)
        {
            TouchInputMenu.SetActive(false);
        }
        else
        {
            TouchInputMenu.SetActive(true);
        }

        if(GasButton.isPressed)
        {
            SpeedUp = true;
        }
        else
        {
            SpeedUp = false;
        }

        if (BrakeButton.isPressed)
        {
            Brake = true;
        }
        else
        {
            Brake = false;
        }

        if (DriftButton.isPressed)
        {
            Drift = true;
        }
        else
        {
            Drift = false;
        }

        if(!SliderCheck.isPressed)
        {
            XinputSlider.value = 0;
        }
    }
}
