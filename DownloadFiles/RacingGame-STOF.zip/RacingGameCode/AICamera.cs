using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AICamera : MonoBehaviour
{
    public Transform FollowObject;
    public Vector3 CamOffset;

    // Update is called once per frame
    void Update()
    {
        transform.position = FollowObject.position + CamOffset;
    }
}
