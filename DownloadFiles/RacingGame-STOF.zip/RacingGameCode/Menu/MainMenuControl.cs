using System.Collections;
using System.Collections.Generic;
using UnityEngine.SceneManagement;
using UnityEngine.UI;
using UnityEngine;

public class MainMenuControl : MonoBehaviour
{
    public GameObject Layer1, Layer2, Layer3;

    public int CurrentMenu;

    public Transform ModelTransform;

    public CarSelector CS;
    public SyncObject SO;

    public Slider SpeedStatBar, AccelStatBar, TurnStatBar, DriftStatBar;
    public GameObject KYBRDCheckMark;

    public Image CarSelectBackground;
    public Sprite Img1, Img2;

    // Start is called before the first frame update
    void Start()
    {

        if (SO == null)
        {
            SO = FindObjectOfType<SyncObject>();
        }

        Layer1.SetActive(true);
        Layer2.SetActive(false);
        Layer3.SetActive(false);


        CarUp();
        CarDown();

        if (!SO.KeyboardInput)
        {
            SO.KeyboardInput = false;
            KYBRDCheckMark.SetActive(false);
        }
        else
        {
            SO.KeyboardInput = true;
            KYBRDCheckMark.SetActive(true);
        }

        CS.Car = SO.PlayerCar;
    }

    // Update is called once per frame
    void FixedUpdate()
    {
        if(SO == null)
        {
            SO = FindObjectOfType<SyncObject>();

            if (!SO.KeyboardInput)
            {
                SO.KeyboardInput = false;
                KYBRDCheckMark.SetActive(false);
            }
            else
            {
                SO.KeyboardInput = true;
                KYBRDCheckMark.SetActive(true);
            }
        }

        if(CurrentMenu == 0)
        {
            Layer1.SetActive(true);
            Layer2.SetActive(false);
            Layer3.SetActive(false);
        }
        else if (CurrentMenu == 1)
        {
            Layer1.SetActive(false);
            Layer2.SetActive(true);
            Layer3.SetActive(false);
        }
        else if (CurrentMenu == 2)
        {
            Layer1.SetActive(false);
            Layer2.SetActive(false);
            Layer3.SetActive(true);
        }

        ModelTransform.localEulerAngles += new Vector3(0, 0.25f, 0);

        SO.PlayerCar = CS.Car;
    }

    public void UpdateCarStats()
    {
        SpeedStatBar.value = CS.CurrentStats[0] - 15;
        AccelStatBar.value = CS.CurrentStats[1] - 2;
        TurnStatBar.value = CS.CurrentStats[6] - 0.2f;
        DriftStatBar.value = CS.CurrentStats[4] - 0.2f;
    }

    public void MenuUp()
    {
        CurrentMenu += 1;

        int R = Random.Range(0, 2);

        if (R == 0)
        {
            CarSelectBackground.sprite = Img1;
        }
        else
        {
            CarSelectBackground.sprite = Img2;
        }
    }
    public void MenuDown()
    {
        CurrentMenu -= 1;

        int R = Random.Range(0, 2);

        if (R == 0)
        {
            CarSelectBackground.sprite = Img1;
        }
        else
        {
            CarSelectBackground.sprite = Img2;
        }
    }

    public void CarUp()
    {
        CS.Car += 1;

        if(CS.Car > 3)
        {
            CS.Car = 0;
        }

        CS.SetCar();
        UpdateCarStats();
    }
    public void CarDown()
    {
        CS.Car -= 1;

        if(CS.Car < 0)
        {
            CS.Car = 3;
        }

        CS.SetCar();
        UpdateCarStats();
    }

    public void OpenScene(int sceneID)
    {
        SceneManager.LoadScene(sceneID);
    }

    public void SetKeyboard()
    {
        if(!SO.KeyboardInput)
        {
            SO.KeyboardInput = true;
            KYBRDCheckMark.SetActive(true);
        }
        else
        {
            SO.KeyboardInput = false;
            KYBRDCheckMark.SetActive(false);
        }
    }

    public void QuitGame()
    {
        Application.Quit();
        Debug.Log("QUIT THE GAME");
    }
}
