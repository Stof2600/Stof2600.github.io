using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SyncObject : MonoBehaviour
{
    public int PlayerCar;
    public bool KeyboardInput;

    // Start is called before the first frame update
    void Start()
    {
        DontDestroyOnLoad(gameObject);
        if(FindObjectOfType<SyncObject>() && FindObjectOfType<SyncObject>().gameObject != gameObject)
        {
            Destroy(gameObject);
        }
    }
}
