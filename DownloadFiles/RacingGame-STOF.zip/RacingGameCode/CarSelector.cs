using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CarSelector : MonoBehaviour
{
    PlayerController PC;

    public int Car;
    public GameObject[] CarModels = new GameObject[4];

    public bool MenuUse;

    /*stats:
    0-max speed
    1-accel
    2-brake speed
    3-min drift speed
    4-drift contr
    5-boostspeed
    6-turn speed
    7-drift turn
    */
    public float[] Car0Stats = new float[8];
    public float[] Car1Stats = new float[8];
    public float[] Car2Stats = new float[8];
    public float[] Car3Stats = new float[8];

    public float[] CurrentStats = new float[8];

    // Start is called before the first frame update
    void Start()
    {
        if(!MenuUse && FindObjectOfType<SyncObject>())
        {
            Car = FindObjectOfType<SyncObject>().PlayerCar;
        }

        PC = GetComponent<PlayerController>();


        foreach(GameObject g in CarModels)
        {
            g.SetActive(false);
        }

        SetCar();
    }

    public void SetCar()
    {
        foreach (GameObject g in CarModels)
        {
            g.SetActive(false);
        }

        CarModels[Car].SetActive(true);

        if(!MenuUse)
        {
            if (Car == 0)
            {
                PC.MaxSpeed = Car0Stats[0];
                PC.Accelaration = Car0Stats[1];
                PC.BrakeSpeed = Car0Stats[2];
                PC.MinDriftSpeed = Car0Stats[3];
                PC.DriftControl = Car0Stats[4];
                PC.BoostSpeed = Car0Stats[5];
                PC.RotateSpeed = Car0Stats[6];
                PC.DriftRotate = Car0Stats[7];
            }
            else if (Car == 1)
            {
                PC.MaxSpeed = Car1Stats[0];
                PC.Accelaration = Car1Stats[1];
                PC.BrakeSpeed = Car1Stats[2];
                PC.MinDriftSpeed = Car1Stats[3];
                PC.DriftControl = Car1Stats[4];
                PC.BoostSpeed = Car1Stats[5];
                PC.RotateSpeed = Car1Stats[6];
                PC.DriftRotate = Car1Stats[7];
            }
            else if (Car == 2)
            {
                PC.MaxSpeed = Car2Stats[0];
                PC.Accelaration = Car2Stats[1];
                PC.BrakeSpeed = Car2Stats[2];
                PC.MinDriftSpeed = Car2Stats[3];
                PC.DriftControl = Car2Stats[4];
                PC.BoostSpeed = Car2Stats[5];
                PC.RotateSpeed = Car2Stats[6];
                PC.DriftRotate = Car2Stats[7];
            }
            else if (Car == 3)
            {
                PC.MaxSpeed = Car3Stats[0];
                PC.Accelaration = Car3Stats[1];
                PC.BrakeSpeed = Car3Stats[2];
                PC.MinDriftSpeed = Car3Stats[3];
                PC.DriftControl = Car3Stats[4];
                PC.BoostSpeed = Car3Stats[5];
                PC.RotateSpeed = Car3Stats[6];
                PC.DriftRotate = Car3Stats[7];
            }
        }
        else
        {
            if (Car == 0)
            {
                CurrentStats[0] = Car0Stats[0];
                CurrentStats[1] = Car0Stats[1];
                CurrentStats[2] = Car0Stats[2];
                CurrentStats[3] = Car0Stats[3];
                CurrentStats[4] = Car0Stats[4];
                CurrentStats[5] = Car0Stats[5];
                CurrentStats[6] = Car0Stats[6];
                CurrentStats[7] = Car0Stats[7];
            }
            else if (Car == 1)
            {
                CurrentStats[0] = Car1Stats[0];
                CurrentStats[1] = Car1Stats[1];
                CurrentStats[2] = Car1Stats[2];
                CurrentStats[3] = Car1Stats[3];
                CurrentStats[4] = Car1Stats[4];
                CurrentStats[5] = Car1Stats[5];
                CurrentStats[6] = Car1Stats[6];
                CurrentStats[7] = Car1Stats[7];
            }
            else if (Car == 2)
            {
                CurrentStats[0] = Car2Stats[0];
                CurrentStats[1] = Car2Stats[1];
                CurrentStats[2] = Car2Stats[2];
                CurrentStats[3] = Car2Stats[3];
                CurrentStats[4] = Car2Stats[4];
                CurrentStats[5] = Car2Stats[5];
                CurrentStats[6] = Car2Stats[6];
                CurrentStats[7] = Car2Stats[7];
            }
            else if (Car == 3)
            {
                CurrentStats[0] = Car3Stats[0];
                CurrentStats[1] = Car3Stats[1];
                CurrentStats[2] = Car3Stats[2];
                CurrentStats[3] = Car3Stats[3];
                CurrentStats[4] = Car3Stats[4];
                CurrentStats[5] = Car3Stats[5];
                CurrentStats[6] = Car3Stats[6];
                CurrentStats[7] = Car3Stats[7];
            }
        }
    }
}
