using System.Collections;
using System.Collections.Generic;
using UnityEngine.SceneManagement;
using UnityEngine.UI;
using UnityEngine;

public class PlayerHud : MonoBehaviour
{

    PlayerController PC;

    public List<PlayerController> AIPC = new List<PlayerController>();
    List<PlayerController> Players = new List<PlayerController>();

    List<PlayerController> PlayersSorted = new List<PlayerController>();

    public Text LapText, TimeText, PlaceText;

    bool CountTime;

    int LastLap;
    int LastPlace;

    float ActiveTime;
    float Minute, Second, MilliSec;

    public Text LT1, LT2, LT3;
    float LapActiveTime;
    float LapM, LapS, LapMS;

    public Text CountdownText;
    float CountdownTime;

    public GameObject ExitButton;

    int HighestScore;

    // Start is called before the first frame update
    void Start()
    {
        foreach(PlayerController player in FindObjectsOfType<PlayerController>())
        {
            if(!player.AIPlayer)
            {
                PC = player;
            }
            else
            {
                AIPC.Add(player);
            }

            Players.Add(player);
        }

        LastLap = PC.CurrentLap;
        CountTime = true;

        LT1.gameObject.SetActive(false);
        LT2.gameObject.SetActive(false);
        LT3.gameObject.SetActive(false);

        ExitButton.SetActive(false);

        CountdownTime = 4;

        CheckPlacement();
    }

    // Update is called once per frame
    void Update()
    {
        if(!PC.InStart)
        {
            if (CountTime)
            {
                ActiveTime += Time.deltaTime;
                Second = (int)ActiveTime;

                MilliSec = (ActiveTime * 100) - (Second * 100);

                if (Minute < 99)
                {
                    Minute = (int)ActiveTime / 60;
                    Second = Second - (Minute * 60);
                }
                else if (Minute >= 99)
                {
                    if (Second >= 99)
                    {
                        Second = 99;
                        MilliSec = 99;
                    }
                }

                LapActiveTime += Time.deltaTime;
                LapS = (int)LapActiveTime;

                LapMS = (LapActiveTime * 100) - (LapS * 100);

                if (LapM < 99)
                {
                    LapM = (int)LapActiveTime / 60;
                    LapS = LapS - (LapM * 60);
                }
                else if (LapM >= 99)
                {
                    if (LapS >= 99)
                    {
                        LapS = 99;
                        LapMS = 99;
                    }
                }

                TimeText.text = Minute.ToString("00") + ":" + Second.ToString("00") + ":" + MilliSec.ToString("00");

                if (LastLap < PC.CurrentLap)
                {
                    switch (LastLap)
                    {
                        case 1:
                            LT1.text = LapM.ToString("00") + ":" + LapS.ToString("00") + ":" + LapMS.ToString("00");
                            LT1.gameObject.SetActive(true);
                            break;
                        case 2:
                            LT2.text = LapM.ToString("00") + ":" + LapS.ToString("00") + ":" + LapMS.ToString("00");
                            LT2.gameObject.SetActive(true);
                            break;
                        case 3:
                            LT3.text = LapM.ToString("00") + ":" + LapS.ToString("00") + ":" + LapMS.ToString("00");
                            LT3.gameObject.SetActive(true);
                            CountTime = false;
                            break;
                    }

                    LapActiveTime = 0;

                    LastLap = PC.CurrentLap;
                }

                LapText.text = PC.CurrentLap.ToString() + "/3";

                if(!PC.AIPlayer)
                {
                    UpdatePlacement();
                }
            }
            else
            {
                LapText.text = "FIN";
                ExitButton.SetActive(true);

                PC.AIPlayer = true;
            }
        }
        else
        {
            CountdownTime -= Time.deltaTime;

            float T = (int)CountdownTime;

            CountdownText.text = T.ToString();

            if(T <= 0)
            {
                CountdownText.gameObject.SetActive(false);
                PC.InStart = false;

                foreach(PlayerController AI in AIPC)
                {
                    AI.InStart = false;
                }
            }

            CheckPlacement();
        }

        switch (PC.PlayerPlacement)
        {
            case 1:
                PlaceText.text = "1st";
                PlaceText.color = new Color(1, 1, 0);
                print("1");
                break;
            case 2:
                PlaceText.text = "2nd";
                PlaceText.color = new Color(0.9245283f, 0.9245283f, 0.9245283f);
                print("2");
                break;
            case 3:
                PlaceText.text = "3rd";
                PlaceText.color = new Color(0.5188679f, 0.3139032f, 0);
                print("3");
                break;
            case 4:
                PlaceText.text = "4th";
                PlaceText.color = new Color(0, 0, 0);
                break;
            case 5:
                PlaceText.text = "5th";
                PlaceText.color = new Color(0, 0, 0);
                break;
            case 6:
                PlaceText.text = "6th";
                PlaceText.color = new Color(0, 0, 0);
                break;
            case 7:
                PlaceText.text = "7th";
                PlaceText.color = new Color(0, 0, 0);
                break;
            case 8:
                PlaceText.text = "8th";
                PlaceText.color = new Color(0, 0, 0);
                break;
            default:
                PlaceText.text = "???";
                PlaceText.color = new Color(0, 0, 0);
                break;
        }
    }

    void CheckPlacement()
    {
        float ShortDis = 999;
        float LastDis = 1000;
        int Ticks = 0;


        foreach(PlayerController p in Players)
        {
            if(p.DistanceToCheckpoint < ShortDis && ShortDis < LastDis)
            {
                LastDis = ShortDis;
                ShortDis = p.DistanceToCheckpoint;
                p.PlayerPlacement = Players.Count - Ticks;
                Ticks += 1;

                if(!PlayersSorted.Contains(p))
                {
                    PlayersSorted.Add(p);
                }
            }
        }

        if(!PlayersSorted.Contains(PC))
        {
            PC.PlayerPlacement = Players.Count - Ticks;
            Ticks += 1;
            PlayersSorted.Add(PC);
        }
    }
    void UpdatePlacement()
    {
        for(int i = 0; i < PlayersSorted.Count; i++)
        {
            if(i < PlayersSorted.Count - 1 && PlayersSorted[i].ScorePoints > PlayersSorted[i + 1].ScorePoints)
            {
                PlayerController P1, P2;
                P1 = PlayersSorted[i];
                P2 = PlayersSorted[i + 1];

                P1.PlayerPlacement -= 1;
                P2.PlayerPlacement += 1;

                PlayersSorted[i] = P2;
                PlayersSorted[i + 1] = P1;
            }

            if(i < PlayersSorted.Count - 1 && PlayersSorted[i].ScorePoints == PlayersSorted[i + 1].ScorePoints && PlayersSorted[i].DistanceToCheckpoint < PlayersSorted[i + 1].DistanceToCheckpoint)
            {
                PlayerController P1, P2;
                P1 = PlayersSorted[i];
                P2 = PlayersSorted[i + 1];

                P1.PlayerPlacement -= 1;
                P2.PlayerPlacement += 1;

                PlayersSorted[i] = P2;
                PlayersSorted[i + 1] = P1;
            }
        }
    }

    public void ToMainMenu()
    {
        SceneManager.LoadScene(0);
    }
}
