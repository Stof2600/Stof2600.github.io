using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerController : MonoBehaviour
{
    public float MaxSpeed = 18, CurrentSpeed, Accelaration = 3, BrakeSpeed = 7f, MinDriftSpeed = 3, DriftControl = 0.7f;
    public float BoostSpeed = 30;
    public Transform CameraPos;
    public float CameraSpeed = 3;
    public float RotateSpeed = 0.35f, DriftRotate = 0.55f;
    public bool UseKeyboard, AIPlayer;

    GameObject LastCheckpoint, NextCheckpoint;
    public int CurrentCP;
    public int CurrentLap;
    public int PlayerPlacement;
    bool CountLap;

    float BoostTime = 0;

    public Vector3 CameraOffset, MaxCameraFloat;
    CheckPointSystem CPS;
    Camera PlayerCam;
    Rigidbody RB;

    TouchInput TI;

    public Transform Model;

    public Sprite RedFire, BlueFire;
    public SpriteRenderer Effect1, Effect2;
    public float DriftExtraRot = 5;
    float DriftRotMulti;
    public GameObject DriftEffect;

    float X, Y;
    bool Drifting, HalfDriftTap;
    float DriftDir;
    int DriftTaps;

    public float AIMaxOffset = 4, AISlowDownMax = 1.3f, AIColRadius = 2;
    public bool TestRun;
    public bool InStart;

    int CheckpointLayer = 1 << 6;

    public float DistanceToCheckpoint;
    public int ScorePoints;
    public PlayerController CarFront, CarBack;

    CarSelector CS;

    // Start is called before the first frame update
    void Start()
    {
        InStart = true;

        CurrentCP = 0;
        CurrentLap = 1;
        CountLap = false;

        CPS = FindObjectOfType<CheckPointSystem>();

        TI = FindObjectOfType<TouchInput>();
        PlayerCam = GetComponentInChildren<Camera>();
        RB = GetComponent<Rigidbody>();

        RB.constraints = RigidbodyConstraints.FreezeRotationX | RigidbodyConstraints.FreezeRotationZ;

        PlayerCam.transform.SetParent(null, true);
        Drifting = false; 
        
        if(AIPlayer)
        {
            PlayerCam.enabled = false;
            PlayerCam.gameObject.SetActive(false);

            CS = GetComponent<CarSelector>();

            if(!TestRun)
            {
                CS.Car = Random.Range(0, 4);
                CS.SetCar();
            }
        }

        if(CPS != null)
        {
            CheckPointControl();
        }

        if(!TestRun && FindObjectOfType<SyncObject>())
        {
            UseKeyboard = FindObjectOfType<SyncObject>().KeyboardInput;
        }

        DriftEffect.SetActive(false);
    }

    // Update is called once per frame
    void Update()
    {
        if(AIPlayer)
        {
            AIInput();
        }
        else if(!UseKeyboard)
        {
            ReadTouchInput();
        }
        else
        {
            ReadKeyboardInput();
        }

        if (!InStart)
        {
            PlayerMovement();
        }

        DistanceToCheckpoint = Vector3.Distance(transform.position, NextCheckpoint.transform.position);
    }

    void PlayerMovement()
    {
        Vector3 CamMagnitude = CameraPos.position - PlayerCam.transform.position;
        BoostTime -= Time.deltaTime;

        if(CamMagnitude.magnitude > MaxCameraFloat.magnitude)
        {
            //print("OutsiddeRadius");
            PlayerCam.transform.position = Vector3.MoveTowards(PlayerCam.transform.position, CameraPos.position, Time.deltaTime * CameraSpeed * 5);
        }

        PlayerCam.transform.position = Vector3.MoveTowards(PlayerCam.transform.position, CameraPos.position, Time.deltaTime * CameraSpeed);
        PlayerCam.transform.LookAt(transform.position + CameraOffset);

        if(FloorCheck())
        {
            //print("ONROAD");
            if (Y >= 1 && CurrentSpeed < MaxSpeed)
            {
                CurrentSpeed += Time.deltaTime * Accelaration;
            }
            else if (Y == -1)
            {
                CurrentSpeed -= Time.deltaTime * BrakeSpeed;
            }
            if (CurrentSpeed > MaxSpeed && BoostTime <= 0)
            {
                CurrentSpeed = MaxSpeed;
            }
            else if (CurrentSpeed < 0)
            {
                CurrentSpeed = 0;
            }
        }
        else
        {
            //print("OFFROAD");
            if (Y >= 1 && CurrentSpeed < MaxSpeed / 3)
            {
                CurrentSpeed += Time.deltaTime * Accelaration;
            }
            else if (Y == -1)
            {
                CurrentSpeed -= Time.deltaTime * BrakeSpeed;
            }
            if (CurrentSpeed > MaxSpeed / 3 && BoostTime <= 0)
            {
                CurrentSpeed = MaxSpeed / 3;
            }
            else if (CurrentSpeed < 0)
            {
                CurrentSpeed = 0;
            }
        }

        if (CurrentSpeed > BoostSpeed && BoostTime > 0)
        {
            CurrentSpeed = BoostSpeed;
        }
        else if(CurrentSpeed < BoostSpeed && BoostTime > 0)
        {
            CurrentSpeed += 1;
        }

        if (CurrentSpeed > 0 && WallCheck())
        {
            //print("HitWall");
            CurrentSpeed = 0;
        }

        if(!Drifting)
        {
            DriftRotMulti -= Time.deltaTime;
            Vector3 DriftRot = new Vector3(transform.rotation.x, transform.rotation.y + (DriftExtraRot * DriftDir * DriftRotMulti), transform.rotation.z);
            Model.transform.localEulerAngles = DriftRot;

            if (DriftTaps > 2)
            {
                BoostTime = 2;
            }

            DriftEffect.SetActive(false);
            if(CurrentSpeed > 0)
            {
                transform.Rotate(transform.up * X * RotateSpeed);
            }
            else
            {
                transform.Rotate(transform.up * (X * RotateSpeed) / 2);
            }
            
            RB.velocity = transform.forward * CurrentSpeed + transform.up * RB.velocity.y;
            DriftDir = 0;
            DriftTaps = 0;
        }
        else
        {
            DriftRotMulti += Time.deltaTime;
            Vector3 DriftRot = new Vector3(transform.rotation.x, transform.rotation.y + (DriftExtraRot * DriftDir * DriftRotMulti), transform.rotation.z);
            Model.transform.localEulerAngles = DriftRot;
            DriftEffect.SetActive(true);

            if ((X == 0 && DriftDir == 0) || CurrentSpeed <= MinDriftSpeed)
            {
                Drifting = false;
            }
            else if(DriftDir == 0)
            {
                if (X > 0)
                {
                    DriftDir = DriftControl;
                }
                else if (X < 0)
                {
                    DriftDir = -DriftControl;
                }
            }
            else
            {
                X = X + DriftDir;

                if ((DriftDir > 0 && X < 0.05f) || (DriftDir < 0 && X > -0.1f))
                {
                    if(DriftDir > 0)
                    {
                        X = 0.05f + DriftDir * 0.25f;
                    }
                    else
                    {
                        X = -0.05f + DriftDir * 0.25f;
                    }
                    HalfDriftTap = true;
                }

                if(HalfDriftTap && DriftDir > 0 && X > 0.5f)
                {
                    HalfDriftTap = false;
                    DriftTaps += 1;
                }
                if (HalfDriftTap && DriftDir < 0 && X < -0.5f)
                {
                    HalfDriftTap = false;
                    DriftTaps += 1;
                }

                if(DriftTaps > 2)
                {
                    Effect1.sprite = RedFire;
                    Effect2.sprite = RedFire;
                }
                else
                {
                    Effect1.sprite = BlueFire;
                    Effect2.sprite = BlueFire;
                }

                transform.Rotate(transform.up * X * RotateSpeed);
                RB.velocity = transform.forward * CurrentSpeed + transform.up * RB.velocity.y;

            }
        }

        if(DriftRotMulti > 1)
        {
            DriftRotMulti = 1;
        }
        else if(DriftRotMulti < 0)
        {
            DriftRotMulti = 0;
        }
    }

    void ReadKeyboardInput()
    {
        X = Input.GetAxis("Horizontal");
        Y = Input.GetAxis("Vertical");

        if(Input.GetKey(KeyCode.Space))
        {
            Drifting = true;
        }
        else
        {
            Drifting = false;
        }
    }
    void ReadTouchInput()
    {
        TI.TouchActive = true;
        X = TI.XinputSlider.value;
        
        if(TI.SpeedUp)
        {
            Y = 1;
        }
        else if(TI.Brake)
        {
            Y = -1;
        }
        else
        {
            Y = 0;
        }

        if (TI.Drift)
        {
            Drifting = true;
        }
        else
        {
            Drifting = false;
        }
    }

    void AIInput()
    {
        if(CPS == null)
        {
            CPS = FindObjectOfType<CheckPointSystem>();
        }

        float RaycastRange = Vector3.Distance(transform.position, NextCheckpoint.transform.position);

        float YIn = 1;
        bool TurnAway = false;
        Transform OtherCar = null;
        bool CPHit = Physics.Raycast(transform.position, transform.forward, out RaycastHit HitInfo, RaycastRange, CheckpointLayer, QueryTriggerInteraction.UseGlobal);

        Debug.DrawRay(transform.position, transform.forward * RaycastRange, Color.green);

        Collider[] Col = Physics.OverlapSphere(transform.position, AIColRadius);

        Vector3 CPDir = transform.InverseTransformVector((transform.position - NextCheckpoint.transform.position).normalized);

        foreach (Collider c in Col)
        {
            if(c.gameObject != gameObject && c.GetComponent<PlayerController>() && CurrentSpeed > 0)
            {
                TurnAway = true;
                OtherCar = c.transform;
            }
        }

        if (WallCheck())
        {
            YIn = 0;
        }

        float CheckpointDistance = Vector3.Distance(HitInfo.point, NextCheckpoint.transform.position);
        

        if (TurnAway && FloorCheck())
        {
            Vector3 EnenmyDir = transform.InverseTransformVector((transform.position - OtherCar.position).normalized);

            Debug.DrawRay(transform.position, CPDir * 1000, Color.blue);

            if (EnenmyDir.x < 0)
            {
                X = -0.1f;
                Drifting = false;
            }
            else if (EnenmyDir.x > 0)
            {
                X = 0.1f;
                Drifting = false;
            }

            //print(CPDir);
        }
        else
        {
            //print(transform.name + "-DIR: " + CPDir.x);

            Debug.DrawRay(transform.position, CPDir * 1000, Color.blue);

            if (CPDir.x < 0)
            {
                X = 1;

                if(CPDir.x < -AIMaxOffset && CS.Car != 0 && CS.Car != 2 && FloorCheck())
                {
                    Drifting = true;
                }
                else
                {
                    Drifting = false;

                    if(CS.Car == 0 && CPDir.x < -AIMaxOffset && FloorCheck() && CurrentSpeed > MaxSpeed/AISlowDownMax)
                    {
                        YIn = -1f;
                    }
                }
            }
            else if (CPDir.x > 0)
            {
                X = -1;

                if (CPDir.x > AIMaxOffset && CS.Car != 0 && CS.Car != 2 && FloorCheck())
                {
                    Drifting = true;
                }
                else
                {
                    Drifting = false;

                    if (CS.Car == 0 && CPDir.x > AIMaxOffset && FloorCheck() && CurrentSpeed > MaxSpeed / AISlowDownMax)
                    {
                        YIn = -1f;
                    }
                }
            }
            else
            {
                X = 0;

                Drifting = false;
            }
        }

        //if()

        Y = YIn;
    }

    void CheckPointControl()
    {
        if (CurrentCP > CPS.Checkpoints.Count - 1)
        {
            CurrentCP = 0;
            CountLap = true;
        }

        if(CurrentCP == 0)
        {
            NextCheckpoint = CPS.FinishLine;
            LastCheckpoint = CPS.Checkpoints[CPS.Checkpoints.Count - 1];
        }
        else if(CurrentCP == 1)
        {
            NextCheckpoint = CPS.Checkpoints[CurrentCP - 1];
            LastCheckpoint = CPS.FinishLine;

            if(CountLap)
            {
                CurrentLap += 1;
                CountLap = false;
            }
        }
        else
        {
            NextCheckpoint = CPS.Checkpoints[CurrentCP - 1];
            LastCheckpoint = CPS.Checkpoints[CurrentCP];
        }
    }

    bool WallCheck()
    {
        float Length = (GetComponent<BoxCollider>().size.z / 2) + 0.1f;
        bool WallHit = Physics.Raycast(transform.position, transform.forward, out RaycastHit HitInfo, Length, ~CheckpointLayer);

        if(WallHit)
        {
            print("Hit wall: " + HitInfo.transform.name);
        }


        return WallHit;
    }

    bool FloorCheck()
    {
        float Dis = (GetComponent<BoxCollider>().size.y / 2) + 0.1f;
        bool HitFloor = Physics.Raycast(transform.position, -transform.up, Dis);

        return HitFloor;
    }

    private void OnTriggerEnter(Collider other)
    {
        //print("ANYTHING");

        if(CPS.Checkpoints.Contains(other.gameObject) || other.gameObject == CPS.FinishLine)
        {
            //print("HITCP");

            if (other.gameObject == NextCheckpoint)
            {
                CurrentCP += 1;
                ScorePoints += 1;
            }

            CheckPointControl();
        }
    }

    private void OnDrawGizmos()
    {
        Gizmos.DrawWireSphere(transform.position, AIColRadius);
    }
}
